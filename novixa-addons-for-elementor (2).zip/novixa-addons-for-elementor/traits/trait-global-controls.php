<?php
/**
 * Reusable groups of Elementor controls shared by more than one widget.
 * Keeping these as a trait (rather than copy/pasting) means every
 * module stays visually + behaviourally consistent.
 *
 * @package Novixa_Addons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! trait_exists( 'Novixa_Addons_Global_Controls' ) ) {

	/**
	 * Trait Novixa_Addons_Global_Controls
	 */
	trait Novixa_Addons_Global_Controls {

		/**
		 * Standard responsive text-alignment CHOOSE control, reused
		 * identically across every text-based widget's Style tab.
		 *
		 * @param string $id        Control id.
		 * @param string $selector  CSS selector the alignment applies to.
		 */
		protected function register_alignment_control( $id, $selector ) {
			$this->add_responsive_control(
				$id,
				array(
					'label'     => __( 'Alignment', 'novixa-addons-for-elementor' ),
					'type'      => \Elementor\Controls_Manager::CHOOSE,
					'options'   => array(
						'left'    => array(
							'title' => __( 'Left', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-left',
						),
						'center'  => array(
							'title' => __( 'Center', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-center',
						),
						'right'   => array(
							'title' => __( 'Right', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-right',
						),
						'justify' => array(
							'title' => __( 'Justified', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-justify',
						),
					),
					'selectors' => array(
						$selector => 'text-align: {{VALUE}};',
					),
				)
			);
		}

		/**
		 * Standard Blend Mode select, reused across widget style panels.
		 *
		 * @param string $id       Control id.
		 * @param string $selector CSS selector the blend mode applies to.
		 */
		protected function register_blend_mode_control( $id, $selector ) {
			$this->add_control(
				$id,
				array(
					'label'     => __( 'Blend Mode', 'novixa-addons-for-elementor' ),
					'type'      => \Elementor\Controls_Manager::SELECT,
					'options'   => array(
						''            => __( 'Normal', 'novixa-addons-for-elementor' ),
						'multiply'    => 'Multiply',
						'screen'      => 'Screen',
						'overlay'     => 'Overlay',
						'darken'      => 'Darken',
						'lighten'     => 'Lighten',
						'color-dodge' => 'Color Dodge',
						'saturation'  => 'Saturation',
						'color'       => 'Color',
						'difference'  => 'Difference',
						'exclusion'   => 'Exclusion',
						'hue'         => 'Hue',
						'luminosity'  => 'Luminosity',
					),
					'selectors' => array(
						$selector => 'mix-blend-mode: {{VALUE}};',
					),
					'separator' => 'before',
				)
			);
		}

		/**
		 * Standard "Advanced > Visibility" section: Hide On Desktop /
		 * Tablet / Mobile switchers, reused by any widget that opts in
		 * via `register_visibility_controls()`. This replicates
		 * Elementor Pro's device-visibility feature with plain CSS
		 * classes (see .novixa-addons-hidden-* rules in frontend.css)
		 * since this plugin has no dependency on Elementor Pro.
		 *
		 * The controls only set flags read by each widget's render()
		 * via Novixa_Addons_Widget_Base::get_visibility_classes() - they
		 * don't use 'selectors', because a plain control can't emit
		 * per-breakpoint @media CSS on its own.
		 */
		protected function register_visibility_controls() {
			$this->start_controls_section(
				'novixa_section_visibility',
				array(
					'label' => __( 'Visibility', 'novixa-addons-for-elementor' ),
					'tab'   => \Elementor\Controls_Manager::TAB_ADVANCED,
				)
			);

			$this->add_control(
				'novixa_hide_desktop',
				array(
					'label'        => __( 'Hide On Desktop', 'novixa-addons-for-elementor' ),
					'type'         => \Elementor\Controls_Manager::SWITCHER,
					'label_on'     => __( 'Hide', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'Show', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => '',
				)
			);

			$this->add_control(
				'novixa_hide_tablet',
				array(
					'label'        => __( 'Hide On Tablet', 'novixa-addons-for-elementor' ),
					'type'         => \Elementor\Controls_Manager::SWITCHER,
					'label_on'     => __( 'Hide', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'Show', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => '',
				)
			);

			$this->add_control(
				'novixa_hide_mobile',
				array(
					'label'        => __( 'Hide On Mobile', 'novixa-addons-for-elementor' ),
					'type'         => \Elementor\Controls_Manager::SWITCHER,
					'label_on'     => __( 'Hide', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'Show', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => '',
					'description'  => __( 'These hide the widget with CSS only (it is still present in the page markup).', 'novixa-addons-for-elementor' ),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Standard "Advanced > Spacing" style section, reused by any
		 * widget that opts in via `register_spacing_controls()`.
		 */
		protected function register_spacing_controls() {
			$this->start_controls_section(
				'novixa_section_spacing',
				array(
					'label' => __( 'Spacing', 'novixa-addons-for-elementor' ),
					'tab'   => \Elementor\Controls_Manager::TAB_ADVANCED,
				)
			);

			$this->add_responsive_control(
				'novixa_margin',
				array(
					'label'      => __( 'Margin', 'novixa-addons-for-elementor' ),
					'type'       => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', 'em', '%' ),
					'selectors'  => array(
						'{{WRAPPER}}' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->end_controls_section();
		}
	}
}
