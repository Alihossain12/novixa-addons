<?php
/**
 * Feature Card widget.
 *
 * A card built around one feature/service: an icon badge, a title, a
 * short description, and a call-to-action button. The button can
 * either sit inline underneath the description, or — the signature
 * look this widget is built for — overlap the card's bottom-right
 * corner, sitting half on/half off the edge the way a lot of modern
 * "service card" designs style their CTA.
 *
 * @package Novixa_Addons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Icons_Manager;

if ( ! class_exists( 'Novixa_Addons_Widget_Feature_Card' ) ) {

	/**
	 * Class Novixa_Addons_Widget_Feature_Card
	 */
	class Novixa_Addons_Widget_Feature_Card extends Novixa_Addons_Widget_Base {

		use Novixa_Addons_Global_Controls;

		/**
		 * Unique widget name registered with Elementor.
		 *
		 * @return string
		 */
		public function get_name() {
			return 'novixa-addons-feature-card';
		}

		/**
		 * Panel label.
		 *
		 * @return string
		 */
		public function get_title() {
			return __( 'Feature Card - Novixa', 'novixa-addons-for-elementor' );
		}

		/**
		 * Panel icon.
		 *
		 * @return string
		 */
		public function get_icon() {
			return 'eicon-icon-box';
		}

		/**
		 * Panel search keywords.
		 *
		 * @return array
		 */
		public function get_keywords() {
			return array_merge( $this->get_base_keywords(), array( 'feature', 'card', 'service', 'icon box', 'cta', 'button', 'call to action' ) );
		}

		/**
		 * Script dependency.
		 *
		 * @return array
		 */
		public function get_script_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Style dependency.
		 *
		 * @return array
		 */
		public function get_style_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Register all controls.
		 */
		protected function register_controls() {
			$this->register_content_controls();
			$this->register_card_style_controls();
			$this->register_icon_style_controls();
			$this->register_title_style_controls();
			$this->register_description_style_controls();
			$this->register_button_style_controls();
		}

		/**
		 * Content tab.
		 */
		protected function register_content_controls() {
			$this->start_controls_section(
				'novixa_section_feature_card_content',
				array(
					'label' => __( 'Feature Card', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_icon',
				array(
					'label'       => __( 'Icon', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::ICONS,
					'default'     => array(
						'value'   => 'fas fa-home',
						'library' => 'fa-solid',
					),
					'skin'        => 'inline',
					'label_block' => false,
				)
			);

			$this->add_control(
				'novixa_title',
				array(
					'label'       => __( 'Title', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( 'Skilled, experienced craftsmanship', 'novixa-addons-for-elementor' ),
					'label_block' => true,
				)
			);

			$this->add_control(
				'novixa_title_tag',
				array(
					'label'   => __( 'Title HTML Tag', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'h3',
					'options' => array(
						'h1'   => 'H1',
						'h2'   => 'H2',
						'h3'   => 'H3',
						'h4'   => 'H4',
						'h5'   => 'H5',
						'h6'   => 'H6',
						'div'  => 'div',
						'span' => 'span',
						'p'    => 'p',
					),
				)
			);

			$this->add_control(
				'novixa_description',
				array(
					'label'       => __( 'Description', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXTAREA,
					'default'     => __( 'Our experienced team takes pride in delivering precise, high-quality workmanship on every project, from small repairs work.', 'novixa-addons-for-elementor' ),
					'label_block' => true,
					'rows'        => 4,
				)
			);

			$this->add_control(
				'novixa_button_heading',
				array(
					'label'     => __( 'Button', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::HEADING,
					'separator' => 'before',
				)
			);

			$this->add_control(
				'novixa_button_text',
				array(
					'label'       => __( 'Button Text', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( 'Contact Us', 'novixa-addons-for-elementor' ),
					'label_block' => false,
				)
			);

			$this->add_control(
				'novixa_button_link',
				array(
					'label'         => __( 'Link', 'novixa-addons-for-elementor' ),
					'type'          => Controls_Manager::URL,
					'placeholder'   => __( 'https://your-link.com', 'novixa-addons-for-elementor' ),
					'show_external' => true,
					'default'       => array(
						'url' => '',
					),
				)
			);

			$this->add_control(
				'novixa_show_button_icon',
				array(
					'label'        => __( 'Show Button Icon', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'yes',
				)
			);

			$this->add_control(
				'novixa_button_icon',
				array(
					'label'       => __( 'Button Icon', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::ICONS,
					'default'     => array(
						'value'   => 'fas fa-arrow-right',
						'library' => 'fa-solid',
					),
					'skin'        => 'inline',
					'label_block' => false,
					'condition'   => array(
						'novixa_show_button_icon' => 'yes',
					),
				)
			);

			$this->add_control(
				'novixa_button_position',
				array(
					'label'       => __( 'Button Position', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::SELECT,
					'default'     => 'overlap',
					'options'     => array(
						'overlap' => __( 'Overlap Bottom-Right Corner', 'novixa-addons-for-elementor' ),
						'inline'  => __( 'Inline (below description)', 'novixa-addons-for-elementor' ),
					),
					'description' => __( 'Overlap pins the button to the card\'s bottom-right corner, sitting fully inside the card, like a floating CTA.', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_content_alignment',
				array(
					'label'     => __( 'Alignment', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::CHOOSE,
					'separator' => 'before',
					'options'   => array(
						'left'   => array(
							'title' => __( 'Left', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-left',
						),
						'center' => array(
							'title' => __( 'Center', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-center',
						),
						'right'  => array(
							'title' => __( 'Right', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-right',
						),
					),
					'default'   => 'left',
					'toggle'    => true,
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'feature-card' ) => 'text-align: {{VALUE}};',
					),
					'description' => __( 'Aligns the icon, title, description and the inline button together. Has no effect on the button while it\'s set to "Overlap Bottom-Right Corner", since that mode pins it to a fixed corner.', 'novixa-addons-for-elementor' ),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Card styling.
		 */
		protected function register_card_style_controls() {
			$this->start_controls_section(
				'novixa_section_card_style',
				array(
					'label' => __( 'Card', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_control(
				'novixa_card_bg_color',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#141414',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'feature-card' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_card_padding',
				array(
					'label'      => __( 'Padding', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', 'em', '%' ),
					'default'    => array(
						'top'      => 32,
						'right'    => 32,
						'bottom'   => 32,
						'left'     => 32,
						'unit'     => 'px',
						'isLinked' => false,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'feature-card' ) => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_control(
				'novixa_card_border_radius',
				array(
					'label'      => __( 'Border Radius', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', '%' ),
					'default'    => array(
						'top'      => 22,
						'right'    => 22,
						'bottom'   => 22,
						'left'     => 22,
						'unit'     => 'px',
						'isLinked' => true,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'feature-card' ) => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_card_min_height',
				array(
					'label'       => __( 'Minimum Height', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::SLIDER,
					'size_units'  => array( 'px', 'vh' ),
					'range'       => array(
						'px' => array(
							'min' => 100,
							'max' => 700,
						),
						'vh' => array(
							'min' => 10,
							'max' => 100,
						),
					),
					'default'     => array(
						'unit' => 'px',
						'size' => 320,
					),
					'description' => __( 'Keeps the card tall and spacious (like the reference design) even when the description is short. Set to 0 to size the card by its content only.', 'novixa-addons-for-elementor' ),
					'selectors'   => array(
						'{{WRAPPER}} .' . $this->bem( 'feature-card' ) => 'min-height: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Border::get_type(),
				array(
					'name'     => 'novixa_card_border',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'feature-card' ),
				)
			);

			$this->add_group_control(
				Group_Control_Box_Shadow::get_type(),
				array(
					'name'     => 'novixa_card_shadow',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'feature-card' ),
					'fields_options' => array(
						'box_shadow_type' => array(
							'default' => 'yes',
						),
						'box_shadow'      => array(
							'default' => array(
								'horizontal' => 0,
								'vertical'   => 20,
								'blur'       => 40,
								'spread'     => 0,
								'color'      => 'rgba(0,0,0,0.18)',
							),
						),
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Icon badge styling.
		 */
		protected function register_icon_style_controls() {
			$this->start_controls_section(
				'novixa_section_icon_style',
				array(
					'label' => __( 'Icon', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_control(
				'novixa_icon_color',
				array(
					'label'     => __( 'Icon Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#ffffff',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'feature-card', 'icon' ) . ' i'   => 'color: {{VALUE}};',
						'{{WRAPPER}} .' . $this->bem( 'feature-card', 'icon' ) . ' svg' => 'fill: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_icon_bg_color',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#f4511e',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'feature-card', 'icon' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_icon_size',
				array(
					'label'     => __( 'Icon Size', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 10,
							'max' => 80,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 24,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'feature-card', 'icon' ) . ' i'   => 'font-size: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .' . $this->bem( 'feature-card', 'icon' ) . ' svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_icon_box_size',
				array(
					'label'     => __( 'Wrapper Size', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 30,
							'max' => 150,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 56,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'feature-card', 'icon' ) => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_control(
				'novixa_icon_border_radius',
				array(
					'label'      => __( 'Border Radius', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', '%' ),
					'default'    => array(
						'top'      => 16,
						'right'    => 16,
						'bottom'   => 16,
						'left'     => 16,
						'unit'     => 'px',
						'isLinked' => true,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'feature-card', 'icon' ) => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_icon_spacing',
				array(
					'label'     => __( 'Spacing (below icon)', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array( 'max' => 80 ),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 22,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'feature-card', 'icon' ) => 'margin-bottom: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Title styling.
		 */
		protected function register_title_style_controls() {
			$this->start_controls_section(
				'novixa_section_title_style',
				array(
					'label' => __( 'Title', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_control(
				'novixa_title_color',
				array(
					'label'     => __( 'Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#ffffff',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'feature-card', 'title' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'     => 'novixa_title_typography',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'feature-card', 'title' ),
				)
			);

			$this->add_responsive_control(
				'novixa_title_spacing',
				array(
					'label'     => __( 'Spacing (below title)', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array( 'max' => 60 ),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 14,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'feature-card', 'title' ) => 'margin-bottom: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Description styling.
		 */
		protected function register_description_style_controls() {
			$this->start_controls_section(
				'novixa_section_description_style',
				array(
					'label' => __( 'Description', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_control(
				'novixa_description_color',
				array(
					'label'     => __( 'Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#c7c7c7',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'feature-card', 'description' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'     => 'novixa_description_typography',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'feature-card', 'description' ),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Button styling.
		 */
		protected function register_button_style_controls() {
			$this->start_controls_section(
				'novixa_section_button_style',
				array(
					'label' => __( 'Button', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->start_controls_tabs( 'novixa_button_style_tabs' );

			$this->start_controls_tab(
				'novixa_button_style_normal',
				array( 'label' => __( 'Normal', 'novixa-addons-for-elementor' ) )
			);

			$this->add_control(
				'novixa_button_bg_color',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#f4511e',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'feature-card', 'button' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_button_text_color',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#141414',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'feature-card', 'button' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'novixa_button_style_hover',
				array( 'label' => __( 'Hover', 'novixa-addons-for-elementor' ) )
			);

			$this->add_control(
				'novixa_button_bg_color_hover',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'feature-card', 'button' ) . ':hover' => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_button_text_color_hover',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'feature-card', 'button' ) . ':hover' => 'color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_tab();

			$this->end_controls_tabs();

			$this->add_group_control(
				Group_Control_Border::get_type(),
				array(
					'name'      => 'novixa_button_border',
					'selector'  => '{{WRAPPER}} .' . $this->bem( 'feature-card', 'button' ),
					'separator' => 'before',
				)
			);

			$this->add_responsive_control(
				'novixa_button_padding',
				array(
					'label'      => __( 'Padding', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', 'em', '%' ),
					'default'    => array(
						'top'      => 12,
						'right'    => 24,
						'bottom'   => 12,
						'left'     => 24,
						'unit'     => 'px',
						'isLinked' => false,
					),
					'separator'  => 'before',
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'feature-card', 'button' ) => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_control(
				'novixa_button_border_radius',
				array(
					'label'      => __( 'Border Radius', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', '%' ),
					'default'    => array(
						'top'      => 50,
						'right'    => 50,
						'bottom'   => 50,
						'left'     => 50,
						'unit'     => 'px',
						'isLinked' => true,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'feature-card', 'button' ) => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_button_font_size',
				array(
					'label'     => __( 'Font Size', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 10,
							'max' => 30,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 15,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'feature-card', 'button' ) => 'font-size: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_button_icon_spacing',
				array(
					'label'     => __( 'Icon Spacing', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array( 'max' => 40 ),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 10,
					),
					'condition' => array(
						'novixa_show_button_icon' => 'yes',
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'feature-card', 'button' ) => 'gap: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_button_spacing_top',
				array(
					'label'     => __( 'Top Spacing', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 0,
							'max' => 80,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 24,
					),
					'separator' => 'before',
					'condition' => array(
						'novixa_button_position' => 'inline',
					),
					'description' => __( 'Space between the description and the button when the button sits inline below the content.', 'novixa-addons-for-elementor' ),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'feature-card', 'button' ) => 'margin-top: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_control(
				'novixa_button_position_heading',
				array(
					'label'     => __( 'Overlap Position', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::HEADING,
					'separator' => 'before',
					'condition' => array(
						'novixa_button_position' => 'overlap',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_button_offset_right',
				array(
					'label'     => __( 'Right Offset', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 0,
							'max' => 60,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 20,
					),
					'condition' => array(
						'novixa_button_position' => 'overlap',
					),
					'description' => __( 'Distance from the card\'s right edge. The button stays fully inside the card - it will never spill past the edge.', 'novixa-addons-for-elementor' ),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'feature-card', 'button' ) => 'right: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_button_offset_bottom',
				array(
					'label'     => __( 'Bottom Offset', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 0,
							'max' => 60,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 20,
					),
					'condition' => array(
						'novixa_button_position' => 'overlap',
					),
					'description' => __( 'Distance from the card\'s bottom edge. The button stays fully inside the card - it will never spill past the edge.', 'novixa-addons-for-elementor' ),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'feature-card', 'button' ) => 'bottom: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Front-end render.
		 */
		protected function render() {
			$settings = $this->get_settings_for_display();

			$wrapper_class = $this->bem( 'feature-card' );
			if ( 'overlap' === $settings['novixa_button_position'] ) {
				$wrapper_class .= ' ' . $this->bem( 'feature-card', '', 'overlap-button' );
			}

			printf( '<div class="%1$s">', esc_attr( $wrapper_class ) );

			printf( '<div class="%1$s">', esc_attr( $this->bem( 'feature-card', 'icon' ) ) );
			Icons_Manager::render_icon( $settings['novixa_icon'], array( 'aria-hidden' => 'true' ) );
			echo '</div>';

			printf( '<div class="%1$s">', esc_attr( $this->bem( 'feature-card', 'body' ) ) );

			if ( '' !== $settings['novixa_title'] ) {
				$title_tag = ! empty( $settings['novixa_title_tag'] ) ? $settings['novixa_title_tag'] : 'h3';
				printf( '<%1$s class="%2$s">%3$s</%1$s>', esc_attr( $title_tag ), esc_attr( $this->bem( 'feature-card', 'title' ) ), esc_html( $settings['novixa_title'] ) );
			}

			if ( '' !== $settings['novixa_description'] ) {
				printf( '<div class="%1$s">%2$s</div>', esc_attr( $this->bem( 'feature-card', 'description' ) ), esc_html( $settings['novixa_description'] ) );
			}

			echo '</div>'; // .novixa-addons-feature-card__body

			if ( '' !== $settings['novixa_button_text'] ) {
				$has_link = ! empty( $settings['novixa_button_link']['url'] );
				$tag      = $has_link ? 'a' : 'div';

				if ( $has_link ) {
					$this->add_link_attributes( 'novixa_feature_card_button', $settings['novixa_button_link'] );
				}

				$this->add_render_attribute( 'novixa_feature_card_button', 'class', $this->bem( 'feature-card', 'button' ) );

				printf( '<%1$s %2$s>', esc_html( $tag ), $this->get_render_attribute_string( 'novixa_feature_card_button' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

				echo '<span>' . esc_html( $settings['novixa_button_text'] ) . '</span>';

				if ( 'yes' === $settings['novixa_show_button_icon'] ) {
					Icons_Manager::render_icon( $settings['novixa_button_icon'], array( 'aria-hidden' => 'true' ) );
				}

				echo '</' . esc_attr( $tag ) . '>';
			}

			echo '</div>'; // .novixa-addons-feature-card
		}
	}
}
