<?php
/**
 * Image Caption Card widget — a background image with a caption
 * overlaid directly on it (bottom-left by default, with a dark
 * gradient scrim behind the text for readability), plus an optional
 * accent bar under the image.
 *
 * @package Novixa_Addons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Border;
use Elementor\Icons_Manager;
use Elementor\Utils;

if ( ! class_exists( 'Novixa_Addons_Widget_Image_Caption_Card' ) ) {

	/**
	 * Class Novixa_Addons_Widget_Image_Caption_Card
	 */
	class Novixa_Addons_Widget_Image_Caption_Card extends Novixa_Addons_Widget_Base {

		/**
		 * Unique widget name registered with Elementor.
		 *
		 * @return string
		 */
		public function get_name() {
			return 'novixa-addons-image-caption-card';
		}

		/**
		 * Panel label.
		 *
		 * @return string
		 */
		public function get_title() {
			return __( 'Image Caption Card - Novixa', 'novixa-addons-for-elementor' );
		}

		/**
		 * Panel icon.
		 *
		 * @return string
		 */
		public function get_icon() {
			return 'eicon-image-box';
		}

		/**
		 * Panel search keywords.
		 *
		 * @return array
		 */
		public function get_keywords() {
			return array_merge( $this->get_base_keywords(), array( 'image', 'card', 'caption', 'overlay', 'photo' ) );
		}

		/**
		 * Style dependency.
		 *
		 * @return array
		 */
		public function get_style_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Register all controls.
		 */
		protected function register_controls() {
			$this->register_content_controls();
			$this->register_card_style_controls();
			$this->register_overlay_style_controls();
			$this->register_caption_style_controls();
			$this->register_description_style_controls();
			$this->register_button_style_controls();
			$this->register_accent_style_controls();
		}

		/**
		 * Content tab.
		 */
		protected function register_content_controls() {
			$this->start_controls_section(
				'novixa_section_content',
				array(
					'label' => __( 'Image Caption Card', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_image',
				array(
					'label'   => __( 'Choose Image', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::MEDIA,
					'default' => array(
						'url' => \Elementor\Utils::get_placeholder_image_src(),
					),
				)
			);

			$this->add_group_control(
				Group_Control_Image_Size::get_type(),
				array(
					'name'    => 'novixa_image_size',
					'default' => 'large',
				)
			);

			$this->add_control(
				'novixa_caption',
				array(
					'label'       => __( 'Caption', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( 'Marketing', 'novixa-addons-for-elementor' ),
					'label_block' => true,
					'dynamic'     => array( 'active' => true ),
				)
			);

			$this->add_control(
				'novixa_html_tag',
				array(
					'label'   => __( 'Caption HTML Tag', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::SELECT,
					'options' => array(
						'h2'   => 'H2',
						'h3'   => 'H3',
						'h4'   => 'H4',
						'h5'   => 'H5',
						'h6'   => 'H6',
						'div'  => 'div',
						'span' => 'span',
						'p'    => 'p',
					),
					'default' => 'h3',
				)
			);

			$this->add_control(
				'novixa_show_description',
				array(
					'label'        => __( 'Show Description', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'yes',
					'description'  => __( 'Turn this on to use the card as a Call to Action — caption + description + button.', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_description',
				array(
					'label'     => __( 'Description', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::TEXTAREA,
					'default'   => __( 'Strategizing targeted campaigns to maximize reach and drive customer engagement.', 'novixa-addons-for-elementor' ),
					'dynamic'   => array( 'active' => true ),
					'condition' => array(
						'novixa_show_description' => 'yes',
					),
				)
			);

			$this->add_control(
				'novixa_show_button',
				array(
					'label'        => __( 'Show Button', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'yes',
					'description'  => __( 'When on, the button becomes the clickable element instead of the whole card (avoids a link nested inside a link).', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_button_text',
				array(
					'label'       => __( 'Button Text', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( 'Learn More', 'novixa-addons-for-elementor' ),
					'label_block' => true,
					'dynamic'     => array( 'active' => true ),
					'condition'   => array(
						'novixa_show_button' => 'yes',
					),
				)
			);

			$this->add_control(
				'novixa_button_link',
				array(
					'label'         => __( 'Button Link', 'novixa-addons-for-elementor' ),
					'type'          => Controls_Manager::URL,
					'placeholder'   => __( 'https://your-link.com', 'novixa-addons-for-elementor' ),
					'show_external' => true,
					'default'       => array(
						'url' => '',
					),
					'condition'     => array(
						'novixa_show_button' => 'yes',
					),
				)
			);

			$this->add_control(
				'novixa_show_button_icon',
				array(
					'label'        => __( 'Show Button Icon', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'yes',
					'condition'    => array(
						'novixa_show_button' => 'yes',
					),
				)
			);

			$this->add_control(
				'novixa_button_icon',
				array(
					'label'     => __( 'Button Icon', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::ICONS,
					'default'   => array(
						'value'   => 'fas fa-arrow-right',
						'library' => 'fa-solid',
					),
					'condition' => array(
						'novixa_show_button'      => 'yes',
						'novixa_show_button_icon' => 'yes',
					),
				)
			);

			$this->add_control(
				'novixa_link',
				array(
					'label'         => __( 'Card Link', 'novixa-addons-for-elementor' ),
					'type'          => Controls_Manager::URL,
					'placeholder'   => __( 'https://your-link.com', 'novixa-addons-for-elementor' ),
					'show_external' => true,
					'default'       => array(
						'url' => '',
					),
					'description'   => __( 'Ignored when "Show Button" is on — the button becomes the link instead.', 'novixa-addons-for-elementor' ),
					'condition'     => array(
						'novixa_show_button!' => 'yes',
					),
				)
			);

			$this->add_control(
				'novixa_caption_position',
				array(
					'label'   => __( 'Caption Position', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::CHOOSE,
					'default' => 'bottom-left',
					'options' => array(
						'top-left'      => array(
							'title' => __( 'Top Left', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-v-align-top',
						),
						'center'        => array(
							'title' => __( 'Center', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-v-align-middle',
						),
						'bottom-left'   => array(
							'title' => __( 'Bottom Left', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-v-align-bottom',
						),
					),
					'prefix_class' => 'novixa-addons-image-caption-card__position-',
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > the card itself (image container).
		 */
		protected function register_card_style_controls() {
			$this->start_controls_section(
				'novixa_section_card_style',
				array(
					'label' => __( 'Card', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_responsive_control(
				'novixa_card_height',
				array(
					'label'     => __( 'Height', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 200,
							'max' => 900,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 460,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'image-caption-card', 'media' ) => 'height: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_card_radius',
				array(
					'label'      => __( 'Border Radius', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', '%' ),
					'default'    => array(
						'top'      => 24,
						'right'    => 24,
						'bottom'   => 24,
						'left'     => 24,
						'unit'     => 'px',
						'isLinked' => true,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'image-caption-card', 'media' ) => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}; overflow: hidden;',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Box_Shadow::get_type(),
				array(
					'name'     => 'novixa_card_shadow',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'image-caption-card', 'media' ),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > the readability scrim behind the caption.
		 */
		protected function register_overlay_style_controls() {
			$this->start_controls_section(
				'novixa_section_overlay_style',
				array(
					'label' => __( 'Overlay', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_control(
				'novixa_show_overlay',
				array(
					'label'        => __( 'Show Overlay', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'yes',
				)
			);

			$this->add_control(
				'novixa_overlay_color',
				array(
					'label'     => __( 'Overlay Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => 'rgba(10, 10, 30, 0.55)',
					'condition' => array(
						'novixa_show_overlay' => 'yes',
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'image-caption-card', 'overlay' ) => '--novixa-overlay-color: {{VALUE}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_overlay_height',
				array(
					'label'     => __( 'Overlay Height', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'%' => array(
							'min' => 10,
							'max' => 100,
						),
					),
					'default'   => array(
						'unit' => '%',
						'size' => 55,
					),
					'condition' => array(
						'novixa_show_overlay' => 'yes',
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'image-caption-card', 'overlay' ) => '--novixa-overlay-height: {{SIZE}}%;',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > the caption text.
		 */
		protected function register_caption_style_controls() {
			$this->start_controls_section(
				'novixa_section_caption_style',
				array(
					'label' => __( 'Caption', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_control(
				'novixa_caption_color',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#ffffff',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'image-caption-card', 'caption' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'           => 'novixa_caption_typography',
					'selector'       => '{{WRAPPER}} .' . $this->bem( 'image-caption-card', 'caption' ),
					'fields_options' => array(
						'font_family' => array(
							'default' => 'Playfair Display',
						),
						'font_weight' => array(
							'default' => '600',
						),
						'font_style'  => array(
							'default' => 'italic',
						),
						'font_size'   => array(
							'default' => array(
								'unit' => 'px',
								'size' => 28,
							),
						),
					),
				)
			);

			$this->add_responsive_control(
				'novixa_caption_padding',
				array(
					'label'      => __( 'Padding', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', 'em', '%' ),
					'default'    => array(
						'top'      => 24,
						'right'    => 24,
						'bottom'   => 24,
						'left'     => 24,
						'unit'     => 'px',
						'isLinked' => true,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'image-caption-card', 'content' ) => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > the CTA description text.
		 */
		protected function register_description_style_controls() {
			$this->start_controls_section(
				'novixa_section_description_style',
				array(
					'label'     => __( 'Description', 'novixa-addons-for-elementor' ),
					'tab'       => Controls_Manager::TAB_STYLE,
					'condition' => array(
						'novixa_show_description' => 'yes',
					),
				)
			);

			$this->add_control(
				'novixa_description_color',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => 'rgba(255, 255, 255, 0.85)',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'image-caption-card', 'description' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'           => 'novixa_description_typography',
					'selector'       => '{{WRAPPER}} .' . $this->bem( 'image-caption-card', 'description' ),
					'fields_options' => array(
						'font_size'   => array(
							'default' => array(
								'unit' => 'px',
								'size' => 14,
							),
						),
						'line_height' => array(
							'default' => array(
								'unit' => 'em',
								'size' => 1.6,
							),
						),
					),
				)
			);

			$this->add_responsive_control(
				'novixa_description_spacing_top',
				array(
					'label'     => __( 'Spacing Top', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 0,
							'max' => 40,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 8,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'image-caption-card', 'description' ) => 'margin-top: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > the CTA button.
		 */
		protected function register_button_style_controls() {
			$this->start_controls_section(
				'novixa_section_button_style',
				array(
					'label'     => __( 'Button', 'novixa-addons-for-elementor' ),
					'tab'       => Controls_Manager::TAB_STYLE,
					'condition' => array(
						'novixa_show_button' => 'yes',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'           => 'novixa_button_typography',
					'selector'       => '{{WRAPPER}} .' . $this->bem( 'image-caption-card', 'button' ),
					'fields_options' => array(
						'font_weight' => array(
							'default' => '600',
						),
						'font_size'   => array(
							'default' => array(
								'unit' => 'px',
								'size' => 14,
							),
						),
					),
				)
			);

			$this->add_responsive_control(
				'novixa_button_padding',
				array(
					'label'      => __( 'Padding', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', 'em' ),
					'default'    => array(
						'top'      => 12,
						'right'    => 22,
						'bottom'   => 12,
						'left'     => 22,
						'unit'     => 'px',
						'isLinked' => false,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'image-caption-card', 'button' ) => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_button_spacing_top',
				array(
					'label'     => __( 'Spacing Top', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 0,
							'max' => 60,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 16,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'image-caption-card', 'button' ) => 'margin-top: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_button_border_radius',
				array(
					'label'      => __( 'Border Radius', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', '%' ),
					'default'    => array(
						'top'      => 6,
						'right'    => 6,
						'bottom'   => 6,
						'left'     => 6,
						'unit'     => 'px',
						'isLinked' => true,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'image-caption-card', 'button' ) => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->start_controls_tabs( 'novixa_button_state_tabs' );

			$this->start_controls_tab(
				'novixa_button_state_normal',
				array(
					'label' => __( 'Normal', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_button_bg_color',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#ffffff',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'image-caption-card', 'button' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_button_text_color',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#1a1a2e',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'image-caption-card', 'button' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Border::get_type(),
				array(
					'name'     => 'novixa_button_border',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'image-caption-card', 'button' ),
				)
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'novixa_button_state_hover',
				array(
					'label' => __( 'Hover', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_button_bg_color_hover',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'image-caption-card', 'button' ) . ':hover' => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_button_text_color_hover',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'image-caption-card', 'button' ) . ':hover' => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_button_border_color_hover',
				array(
					'label'     => __( 'Border Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'condition' => array(
						'novixa_button_border_border!' => '',
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'image-caption-card', 'button' ) . ':hover' => 'border-color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_tab();

			$this->end_controls_tabs();

			$this->end_controls_section();
		}

		/**
		 * Style tab > the accent bar under the card.
		 */
		protected function register_accent_style_controls() {
			$this->start_controls_section(
				'novixa_section_accent_style',
				array(
					'label' => __( 'Accent Bar', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_control(
				'novixa_show_accent',
				array(
					'label'        => __( 'Show Accent Bar', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => '',
				)
			);

			$this->add_control(
				'novixa_accent_color',
				array(
					'label'     => __( 'Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#c9a86a',
					'condition' => array(
						'novixa_show_accent' => 'yes',
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'image-caption-card', 'accent' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_accent_height',
				array(
					'label'     => __( 'Height', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 1,
							'max' => 20,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 4,
					),
					'condition' => array(
						'novixa_show_accent' => 'yes',
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'image-caption-card', 'accent' ) => 'height: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_accent_width',
				array(
					'label'     => __( 'Width', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'size_units' => array( '%', 'px' ),
					'range'     => array(
						'%'  => array(
							'min' => 20,
							'max' => 120,
						),
						'px' => array(
							'min' => 20,
							'max' => 800,
						),
					),
					'default'   => array(
						'unit' => '%',
						'size' => 108,
					),
					'condition' => array(
						'novixa_show_accent' => 'yes',
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'image-caption-card', 'accent' ) => 'width: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Front-end render.
		 */
		protected function render() {
			$settings = $this->get_settings_for_display();

			$show_button = 'yes' === $settings['novixa_show_button'] && ! empty( $settings['novixa_button_text'] );

			// If a CTA button is shown, it becomes the clickable element —
			// the whole card is no longer wrapped in <a> to avoid an
			// invalid link-inside-a-link.
			$has_link = ! $show_button && ! empty( $settings['novixa_link']['url'] );
			$tag      = $has_link ? 'a' : 'div';

			if ( $has_link ) {
				$this->add_link_attributes( 'novixa_card_link', $settings['novixa_link'] );
			}

			$this->add_render_attribute( 'novixa_card_link', 'class', $this->bem( 'image-caption-card' ) );

			printf( '<%1$s %2$s>', esc_html( $tag ), $this->get_render_attribute_string( 'novixa_card_link' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

			printf( '<div class="%1$s">', esc_attr( $this->bem( 'image-caption-card', 'media' ) ) );
			echo Group_Control_Image_Size::get_attachment_image_html( $settings, 'novixa_image_size', 'novixa_image' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

			if ( 'yes' === $settings['novixa_show_overlay'] ) {
				printf( '<div class="%1$s"></div>', esc_attr( $this->bem( 'image-caption-card', 'overlay' ) ) );
			}

			printf( '<div class="%1$s">', esc_attr( $this->bem( 'image-caption-card', 'content' ) ) );
			if ( ! empty( $settings['novixa_caption'] ) ) {
				$caption_tag = ! empty( $settings['novixa_html_tag'] ) ? $settings['novixa_html_tag'] : 'h3';
				printf(
					'<%1$s class="%2$s">%3$s</%1$s>',
					Utils::validate_html_tag( $caption_tag ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					esc_attr( $this->bem( 'image-caption-card', 'caption' ) ),
					esc_html( $settings['novixa_caption'] )
				);
			}

			if ( 'yes' === $settings['novixa_show_description'] && ! empty( $settings['novixa_description'] ) ) {
				printf(
					'<p class="%1$s">%2$s</p>',
					esc_attr( $this->bem( 'image-caption-card', 'description' ) ),
					esc_html( $settings['novixa_description'] )
				);
			}

			if ( $show_button ) {
				$button_has_link = ! empty( $settings['novixa_button_link']['url'] );
				$button_tag      = $button_has_link ? 'a' : 'span';
				if ( $button_has_link ) {
					$this->add_link_attributes( 'novixa_button_link_attr', $settings['novixa_button_link'] );
				}
				$this->add_render_attribute( 'novixa_button_link_attr', 'class', $this->bem( 'image-caption-card', 'button' ) );
				printf( '<%1$s %2$s>', esc_html( $button_tag ), $this->get_render_attribute_string( 'novixa_button_link_attr' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo esc_html( $settings['novixa_button_text'] );
				if ( 'yes' === $settings['novixa_show_button_icon'] && ! empty( $settings['novixa_button_icon']['value'] ) ) {
					echo ' ';
					Icons_Manager::render_icon( $settings['novixa_button_icon'], array( 'aria-hidden' => 'true' ) );
				}
				echo '</' . esc_html( $button_tag ) . '>';
			}

			echo '</div>'; // .content

			echo '</div>'; // .media

			if ( 'yes' === $settings['novixa_show_accent'] ) {
				printf( '<div class="%1$s"></div>', esc_attr( $this->bem( 'image-caption-card', 'accent' ) ) );
			}

			echo '</' . esc_html( $tag ) . '>';
		}

		/**
		 * Editor live-preview template.
		 */
		protected function content_template() {
			?>
			<#
			var captionTag = settings.novixa_html_tag || 'h3';
			var showButton = settings.novixa_show_button === 'yes' && settings.novixa_button_text;
			#>
			<div class="novixa-addons-image-caption-card">
				<div class="novixa-addons-image-caption-card__media">
					<img src="{{ settings.novixa_image.url }}" alt="" />
					<# if ( settings.novixa_show_overlay === 'yes' ) { #>
					<div class="novixa-addons-image-caption-card__overlay"></div>
					<# } #>
					<div class="novixa-addons-image-caption-card__content">
						<# if ( settings.novixa_caption ) { #>
						<{{{ captionTag }}} class="novixa-addons-image-caption-card__caption">{{{ settings.novixa_caption }}}</{{{ captionTag }}}>
						<# } #>
						<# if ( settings.novixa_show_description === 'yes' && settings.novixa_description ) { #>
						<p class="novixa-addons-image-caption-card__description">{{{ settings.novixa_description }}}</p>
						<# } #>
						<# if ( showButton ) { #>
						<span class="novixa-addons-image-caption-card__button">
							{{{ settings.novixa_button_text }}}
							<# if ( settings.novixa_show_button_icon === 'yes' && settings.novixa_button_icon && settings.novixa_button_icon.value ) { #>
							<i class="{{ settings.novixa_button_icon.value }}"></i>
							<# } #>
						</span>
						<# } #>
					</div>
				</div>
				<# if ( settings.novixa_show_accent === 'yes' ) { #>
				<div class="novixa-addons-image-caption-card__accent"></div>
				<# } #>
			</div>
			<?php
		}
	}
}
