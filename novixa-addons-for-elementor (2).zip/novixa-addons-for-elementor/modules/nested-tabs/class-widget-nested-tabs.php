<?php
/**
 * Nested Tabs (Experimental) widget — tabs where each panel is a real
 * Elementor container that any widget can be dragged into, matching
 * Elementor's own native "Tabs" widget when the Container + Nested
 * Elements experiments are active.
 *
 * ============================== READ THIS ==============================
 * This widget is built on Elementor's `Widget_Nested_Base`, the same
 * internal system Elementor's own Nested Tabs/Accordion widgets use.
 * It is NOT a documented, stable, public API for third-party plugins —
 * an official Elementor GitHub issue asking for third-party guidance on
 * this exact system was closed by Elementor as "not planned"
 * (github.com/elementor/elementor/issues/33810), and multiple
 * experienced plugin developers have reported spending weeks on this
 * exact feature with no success, because so little of it is documented.
 *
 * This implementation follows the closest known-working community
 * pattern (Widget_Nested_Base + content_template() + a small editor-only
 * JS file registering a NestedElementBase/NestedView pair), but it has
 * only been verified against the current stable Elementor release at
 * the time this was written — it may need adjustment on your exact
 * Elementor version, and may behave differently once "Container" +
 * "Nested Elements" experiments are toggled in
 * Elementor > Settings > Experiments. If dragging a widget into a tab
 * doesn't work, that's the most likely next thing to debug.
 * =========================================================================
 *
 * @package Novixa_Addons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Plugin;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Modules\NestedElements\Base\Widget_Nested_Base;
use Elementor\Modules\NestedElements\Controls\Control_Nested_Repeater;

if ( ! class_exists( '\Elementor\Modules\NestedElements\Base\Widget_Nested_Base' ) ) {
	return;
}

if ( ! class_exists( 'Novixa_Addons_Widget_Nested_Tabs' ) ) {

	/**
	 * Class Novixa_Addons_Widget_Nested_Tabs
	 */
	class Novixa_Addons_Widget_Nested_Tabs extends Widget_Nested_Base {

		/**
		 * This widget extends Elementor's own Widget_Nested_Base rather
		 * than our Novixa_Addons_Widget_Base (PHP has no multiple
		 * inheritance, and Widget_Nested_Base is required for nested
		 * containers to work). That means it does NOT automatically get
		 * get_categories(), get_base_keywords(), or bem() the way every
		 * other module in this plugin does — those three methods are
		 * re-declared below so this widget is self-contained. Removing
		 * any of them will bring back a site-wide critical error, since
		 * get_categories() is required by Elementor's Widget_Base and
		 * bem()/get_base_keywords() are called from render(),
		 * content_template(), get_default_children_placeholder_selector()
		 * and get_keywords() below.
		 */

		/**
		 * Group under our own custom category, same as every other
		 * Novixa widget (normally inherited from Novixa_Addons_Widget_Base).
		 *
		 * @return array
		 */
		public function get_categories() {
			return array( 'novixa-addons' );
		}

		/**
		 * Common keywords appended in each concrete widget (normally
		 * inherited from Novixa_Addons_Widget_Base).
		 *
		 * @return array
		 */
		public function get_base_keywords() {
			return array( 'novixa', 'addons' );
		}

		/**
		 * Build a BEM-style class name inside our own namespace, e.g.
		 * $this->bem( 'nested-tabs', 'panel' ) => "novixa-addons-nested-tabs__panel".
		 * Normally inherited from Novixa_Addons_Widget_Base — re-declared
		 * here (kept identical) since this widget can't extend that class.
		 *
		 * @param string $block   Block name (usually the widget slug).
		 * @param string $element Optional element name.
		 * @param string $mod     Optional modifier name.
		 * @return string
		 */
		protected function bem( $block, $element = '', $mod = '' ) {
			$class = Novixa_Addons_Widget_Base::CSS_PREFIX . '-' . $block;

			if ( $element ) {
				$class .= '__' . $element;
			}

			if ( $mod ) {
				$class .= '--' . $mod;
			}

			return $class;
		}

		/**
		 * Unique widget name registered with Elementor. Also used as
		 * the JS-side element type — the value here MUST exactly match
		 * `getType()` in assets/js/editor-nested-tabs.js.
		 *
		 * @return string
		 */
		public function get_name() {
			return 'novixa-addons-nested-tabs';
		}

		/**
		 * Panel label.
		 *
		 * @return string
		 */
		public function get_title() {
			return __( 'Tabs (Nested, Experimental) - Novixa', 'novixa-addons-for-elementor' );
		}

		/**
		 * Panel icon.
		 *
		 * @return string
		 */
		public function get_icon() {
			return 'eicon-tabs';
		}

		/**
		 * Panel search keywords.
		 *
		 * @return array
		 */
		public function get_keywords() {
			return array_merge( $this->get_base_keywords(), array( 'tabs', 'nested', 'container', 'experimental' ) );
		}

		/**
		 * Only offer this widget when both required experiments are on
		 * — without them, containers can't be created/dragged in at all
		 * and the widget would just look broken.
		 *
		 * @return bool
		 */
		public function show_in_panel() {
			$experiments = Plugin::$instance->experiments;

			return $experiments->is_feature_active( 'nested-elements' )
				&& $experiments->is_feature_active( 'container' );
		}

		/**
		 * Script dependency. Without this, Elementor never prints
		 * 'novixa-addons-frontend' (the file with the tab-switching
		 * click handler) on the isolated AJAX request it uses to
		 * render this widget every time a setting changes in the
		 * editor — so clicking a tab in the canvas silently does
		 * nothing, even though a full page load (front-end "view"
		 * mode) can be fine. See the same note on the Button widget.
		 *
		 * @return array
		 */
		public function get_script_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Style dependency.
		 *
		 * @return array
		 */
		public function get_style_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/* -------------------------------------------------------- */
		/* Widget_Nested_Base required methods                       */
		/* -------------------------------------------------------- */

		/**
		 * Default child containers created the first time this widget
		 * is dragged onto the canvas.
		 *
		 * @return array
		 */
		protected function get_default_children_elements() {
			return array(
				array(
					'elType'   => 'container',
					'settings' => array( '_title' => __( 'Tab #1', 'novixa-addons-for-elementor' ) ),
				),
				array(
					'elType'   => 'container',
					'settings' => array( '_title' => __( 'Tab #2', 'novixa-addons-for-elementor' ) ),
				),
				array(
					'elType'   => 'container',
					'settings' => array( '_title' => __( 'Tab #3', 'novixa-addons-for-elementor' ) ),
				),
			);
		}

		/**
		 * The repeater field that holds each tab's title — Elementor
		 * uses this to keep a container's navigator label in sync with
		 * the tab title the person typed.
		 *
		 * @return string
		 */
		protected function get_default_repeater_title_setting_key() {
			return 'novixa_tab_title';
		}

		/**
		 * Default title format for the navigator (fallback only; the
		 * repeater title setting above takes priority once a title is
		 * typed in).
		 *
		 * @return string
		 */
		protected function get_default_children_title() {
			// translators: %d is the tab's numeric position (1, 2, 3...).
			return esc_html__( 'Tab #%d', 'novixa-addons-for-elementor' );
		}

		/**
		 * Where a newly-created tab's container should be inserted in
		 * the DOM — our panels wrapper.
		 *
		 * @return string
		 */
		protected function get_default_children_placeholder_selector() {
			return '.' . $this->bem( 'nested-tabs', 'panels' );
		}

		/**
		 * Register all controls.
		 */
		protected function register_controls() {
			$this->start_controls_section(
				'novixa_section_tabs',
				array(
					'label' => __( 'Tabs', 'novixa-addons-for-elementor' ),
				)
			);

			// Show a friendly notice if the required experiments are off,
			// but keep registering the rest of the controls below
			// regardless — returning early here caused the Content
			// settings (Direction/Justify/Align Title) and the entire
			// Style tab to never register at all for this widget, even
			// after the experiments were turned on, because Elementor
			// only builds this widget's controls schema once and this
			// check ran before the experiments were active.
			if ( ! $this->show_in_panel() ) {
				$this->add_control(
					'novixa_experiments_notice',
					array(
						'type'    => Controls_Manager::ALERT,
						'alert_type' => 'warning',
						'heading' => __( 'Experiments Required', 'novixa-addons-for-elementor' ),
						'content' => __( 'Turn on both "Container" and "Nested Elements" under Elementor → Settings → Experiments to use this widget.', 'novixa-addons-for-elementor' ),
					)
				);
			}

			$repeater = new Repeater();

			$repeater->add_control(
				'novixa_tab_title',
				array(
					'label'       => __( 'Title', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( 'Tab', 'novixa-addons-for-elementor' ),
					'label_block' => true,
					'dynamic'     => array( 'active' => false ),
				)
			);

			$this->add_control(
				'novixa_tabs',
				array(
					'label'       => __( 'Tabs Items', 'novixa-addons-for-elementor' ),
					'type'        => Control_Nested_Repeater::CONTROL_TYPE,
					'fields'      => $repeater->get_controls(),
					'default'     => array(
						array( 'novixa_tab_title' => __( 'Tab #1', 'novixa-addons-for-elementor' ) ),
						array( 'novixa_tab_title' => __( 'Tab #2', 'novixa-addons-for-elementor' ) ),
						array( 'novixa_tab_title' => __( 'Tab #3', 'novixa-addons-for-elementor' ) ),
					),
					'title_field' => '{{{ novixa_tab_title }}}',
					'button_text' => __( 'Add Tab', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_responsive_control(
				'novixa_direction',
				array(
					'label'        => __( 'Direction', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::CHOOSE,
					'default'      => 'top',
					'options'      => array(
						'top'    => array(
							'title' => __( 'Top', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-v-align-top',
						),
						'bottom' => array(
							'title' => __( 'Bottom', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-v-align-bottom',
						),
						'start'  => array(
							'title' => __( 'Start', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-h-align-left',
						),
						'end'    => array(
							'title' => __( 'End', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-h-align-right',
						),
					),
					'prefix_class' => 'novixa-addons-nested-tabs--direction-',
				)
			);

			$this->add_responsive_control(
				'novixa_justify',
				array(
					'label'     => __( 'Justify', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::CHOOSE,
					'default'   => 'start',
					'options'   => array(
						'flex-start' => array(
							'title' => __( 'Start', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-h-align-left',
						),
						'center'     => array(
							'title' => __( 'Center', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-h-align-center',
						),
						'flex-end'   => array(
							'title' => __( 'End', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-h-align-right',
						),
						'stretch'    => array(
							'title' => __( 'Stretch', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-h-align-stretch',
						),
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'nested-tabs', 'nav' ) => 'justify-content: {{VALUE}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_align_title',
				array(
					'label'     => __( 'Align Title', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::CHOOSE,
					'default'   => 'center',
					'options'   => array(
						'left'   => array(
							'title' => __( 'Left', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-left',
						),
						'center' => array(
							'title' => __( 'Center', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-center',
						),
						'right'  => array(
							'title' => __( 'Right', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-right',
						),
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'nested-tabs', 'nav-item' ) => 'text-align: {{VALUE}};',
					),
				)
			);

			$this->end_controls_section();

			$this->register_nav_style_controls();
			$this->register_panels_style_controls();
		}

		/**
		 * Style tab > the tab buttons (nav). Mirrors the plain Tabs
		 * widget's nav style section (see class-widget-tabs.php) so both
		 * widgets are customizable the same way.
		 */
		protected function register_nav_style_controls() {
			$this->start_controls_section(
				'novixa_section_nav_style',
				array(
					'label' => __( 'Tabs', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'     => 'novixa_nav_typography',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'nested-tabs', 'nav-item' ),
				)
			);

			$this->add_responsive_control(
				'novixa_nav_padding',
				array(
					'label'      => __( 'Padding', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', 'em', '%' ),
					'default'    => array(
						'top'      => 14,
						'right'    => 24,
						'bottom'   => 14,
						'left'     => 24,
						'unit'     => 'px',
						'isLinked' => false,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'nested-tabs', 'nav-item' ) => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_nav_radius',
				array(
					'label'      => __( 'Border Radius', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', '%' ),
					'default'    => array(
						'top'      => 6,
						'right'    => 6,
						'bottom'   => 6,
						'left'     => 6,
						'unit'     => 'px',
						'isLinked' => true,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'nested-tabs', 'nav-item' ) => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Border::get_type(),
				array(
					'name'     => 'novixa_nav_border',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'nested-tabs', 'nav-item' ),
				)
			);

			$this->start_controls_tabs( 'novixa_nav_state_tabs' );

			$this->start_controls_tab(
				'novixa_nav_state_normal',
				array( 'label' => __( 'Normal', 'novixa-addons-for-elementor' ) )
			);

			$this->add_control(
				'novixa_nav_bg_normal',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#f2f1fb',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'nested-tabs', 'nav-item' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_nav_text_normal',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#4a4767',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'nested-tabs', 'nav-item' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'novixa_nav_state_hover',
				array( 'label' => __( 'Hover', 'novixa-addons-for-elementor' ) )
			);

			$this->add_control(
				'novixa_nav_bg_hover',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'nested-tabs', 'nav-item' ) . ':hover' => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_nav_text_hover',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'nested-tabs', 'nav-item' ) . ':hover' => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_nav_border_color_hover',
				array(
					'label'     => __( 'Border Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'condition' => array(
						'novixa_nav_border_border!' => '',
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'nested-tabs', 'nav-item' ) . ':hover' => 'border-color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'novixa_nav_state_active',
				array( 'label' => __( 'Active', 'novixa-addons-for-elementor' ) )
			);

			$this->add_control(
				'novixa_nav_bg_active',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#4f3ff0',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'nested-tabs', 'nav-item', 'active' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_nav_text_active',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#ffffff',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'nested-tabs', 'nav-item', 'active' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_nav_border_color_active',
				array(
					'label'     => __( 'Border Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'condition' => array(
						'novixa_nav_border_border!' => '',
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'nested-tabs', 'nav-item', 'active' ) => 'border-color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_tab();

			$this->end_controls_tabs();

			$this->add_responsive_control(
				'novixa_nav_gap',
				array(
					'label'     => __( 'Gap Between Tabs', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'separator' => 'before',
					'range'     => array(
						'px' => array(
							'min' => 0,
							'max' => 40,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 6,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'nested-tabs', 'nav' ) => 'gap: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > the panels wrapper. Each panel itself holds a real
		 * Elementor container (styled independently via that container's
		 * own Style tab), so only wrapper-level styling belongs here —
		 * background, border, padding and shadow around the active panel.
		 */
		protected function register_panels_style_controls() {
			$this->start_controls_section(
				'novixa_section_panels_style',
				array(
					'label' => __( 'Content', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_control(
				'novixa_panels_bg_color',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#ffffff',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'nested-tabs', 'panels' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_panels_padding',
				array(
					'label'      => __( 'Padding', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', 'em', '%' ),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'nested-tabs', 'panels' ) => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Border::get_type(),
				array(
					'name'     => 'novixa_panels_border',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'nested-tabs', 'panels' ),
				)
			);

			$this->add_group_control(
				Group_Control_Box_Shadow::get_type(),
				array(
					'name'     => 'novixa_panels_shadow',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'nested-tabs', 'panels' ),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Underscore.js template used by the Elementor editor to
		 * re-render this widget locally (no server round-trip) whenever
		 * a repeater item is added/removed/reordered. Community reports
		 * indicate this is required for Widget_Nested_Base widgets even
		 * though it's optional for ordinary widgets.
		 */
		protected function content_template() {
			?>
			<#
			view.addRenderAttribute( 'novixa-nested-tabs', 'class', '<?php echo esc_attr( $this->bem( 'nested-tabs' ) ); ?>' );
			#>
			<div {{{ view.getRenderAttributeString( 'novixa-nested-tabs' ) }}}>
				<div class="<?php echo esc_attr( $this->bem( 'nested-tabs', 'nav' ) ); ?>" role="tablist">
					<# _.each( settings.novixa_tabs, function( tab, index ) {
						var isActive = ( 0 === index );
						var navClass = '<?php echo esc_js( $this->bem( 'nested-tabs', 'nav-item' ) ); ?>';
						if ( isActive ) {
							navClass += ' <?php echo esc_js( $this->bem( 'nested-tabs', 'nav-item', 'active' ) ); ?>';
						}
					#>
						<button type="button" class="{{ navClass }}" data-tab-index="{{ index }}" role="tab">{{{ tab.novixa_tab_title }}}</button>
					<# } ); #>
				</div>
				<div class="<?php echo esc_attr( $this->bem( 'nested-tabs', 'panels' ) ); ?>"></div>
			</div>
			<?php
		}

		/**
		 * Front-end render — nav buttons plus one real Elementor
		 * container per tab (via print_child(), provided by
		 * Widget_Nested_Base), so any widget dropped into a tab in the
		 * editor renders exactly as placed.
		 */
		protected function render() {
			if ( ! $this->show_in_panel() ) {
				return;
			}

			$settings = $this->get_settings_for_display();
			$tabs     = ! empty( $settings['novixa_tabs'] ) ? $settings['novixa_tabs'] : array();

			if ( empty( $tabs ) ) {
				return;
			}

			printf( '<div class="%1$s">', esc_attr( $this->bem( 'nested-tabs' ) ) );

			printf( '<div class="%1$s" role="tablist">', esc_attr( $this->bem( 'nested-tabs', 'nav' ) ) );
			foreach ( $tabs as $index => $tab ) {
				$is_active = ( 0 === $index );
				$nav_class = $this->bem( 'nested-tabs', 'nav-item' );
				if ( $is_active ) {
					$nav_class .= ' ' . $this->bem( 'nested-tabs', 'nav-item', 'active' );
				}
				printf(
					'<button type="button" class="%1$s" data-tab-index="%2$d" role="tab" aria-selected="%3$s">%4$s</button>',
					esc_attr( $nav_class ),
					(int) $index,
					$is_active ? 'true' : 'false',
					esc_html( $tab['novixa_tab_title'] )
				);
			}
			echo '</div>'; // .nav

			printf( '<div class="%1$s">', esc_attr( $this->bem( 'nested-tabs', 'panels' ) ) );
			foreach ( $tabs as $index => $tab ) {
				$is_active   = ( 0 === $index );
				$panel_class = $this->bem( 'nested-tabs', 'panel' );
				if ( $is_active ) {
					$panel_class .= ' ' . $this->bem( 'nested-tabs', 'panel', 'active' );
				}
				printf(
					'<div class="%1$s" data-tab-index="%2$d" role="tabpanel" style="display:%3$s;">',
					esc_attr( $panel_class ),
					(int) $index,
					$is_active ? 'block' : 'none'
				);
				$this->print_child( $index );
				echo '</div>';
			}
			echo '</div>'; // .panels

			echo '</div>'; // .nested-tabs
		}
	}
}
