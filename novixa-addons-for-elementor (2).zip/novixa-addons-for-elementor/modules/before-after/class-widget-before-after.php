<?php
/**
 * Before / After widget.
 *
 * A draggable image-comparison slider: two images stacked in the same
 * frame, with the top one revealed/hidden via CSS clip-path as the
 * handle is dragged (mouse, touch, or arrow keys). Both images are
 * rendered as real <img> tags at the FULL frame size (so cropping,
 * srcset, and the Height style control all behave exactly like a
 * normal image) - only the paint region is clipped, which is what
 * keeps the "before" layer from looking zoomed/cropped differently
 * than the "after" layer the way a naive width-based approach would.
 *
 * @package Novixa_Addons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if ( ! class_exists( 'Novixa_Addons_Widget_Before_After' ) ) {

	/**
	 * Class Novixa_Addons_Widget_Before_After
	 */
	class Novixa_Addons_Widget_Before_After extends Novixa_Addons_Widget_Base {

		use Novixa_Addons_Global_Controls;

		/**
		 * Unique widget name registered with Elementor.
		 *
		 * @return string
		 */
		public function get_name() {
			return 'novixa-addons-before-after';
		}

		/**
		 * Panel label.
		 *
		 * @return string
		 */
		public function get_title() {
			return __( 'Before / After - Novixa', 'novixa-addons-for-elementor' );
		}

		/**
		 * Panel icon.
		 *
		 * @return string
		 */
		public function get_icon() {
			return 'eicon-image-before-after';
		}

		/**
		 * Panel search keywords.
		 *
		 * @return array
		 */
		public function get_keywords() {
			return array_merge( $this->get_base_keywords(), array( 'before after', 'before and after', 'comparison', 'image compare', 'slider', 'reveal' ) );
		}

		/**
		 * Script dependency.
		 *
		 * @return array
		 */
		public function get_script_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Style dependency.
		 *
		 * @return array
		 */
		public function get_style_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Register all controls.
		 */
		protected function register_controls() {
			$this->register_content_controls();
			$this->register_media_style_controls();
			$this->register_handle_style_controls();
			$this->register_label_style_controls();
			$this->register_visibility_controls();
			$this->register_spacing_controls();
		}

		/**
		 * Content tab.
		 */
		protected function register_content_controls() {
			$this->start_controls_section(
				'novixa_section_ba_content',
				array(
					'label' => __( 'Before / After', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_ba_before_heading',
				array(
					'label' => __( 'Before Image', 'novixa-addons-for-elementor' ),
					'type'  => Controls_Manager::HEADING,
				)
			);

			$this->add_control(
				'novixa_ba_before_image',
				array(
					'label'   => __( 'Choose Image', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::MEDIA,
					'default' => array(
						'url' => \Elementor\Utils::get_placeholder_image_src(),
					),
				)
			);

			$this->add_control(
				'novixa_ba_before_label',
				array(
					'label'       => __( 'Label', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( 'Before', 'novixa-addons-for-elementor' ),
					'label_block' => false,
				)
			);

			$this->add_control(
				'novixa_ba_after_heading',
				array(
					'label'     => __( 'After Image', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::HEADING,
					'separator' => 'before',
				)
			);

			$this->add_control(
				'novixa_ba_after_image',
				array(
					'label'   => __( 'Choose Image', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::MEDIA,
					'default' => array(
						'url' => \Elementor\Utils::get_placeholder_image_src(),
					),
				)
			);

			$this->add_control(
				'novixa_ba_after_label',
				array(
					'label'       => __( 'Label', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( 'After', 'novixa-addons-for-elementor' ),
					'label_block' => false,
				)
			);

			$this->add_group_control(
				Group_Control_Image_Size::get_type(),
				array(
					'name'      => 'novixa_ba_image_size',
					'default'   => 'large',
					'separator' => 'before',
				)
			);

			$this->add_control(
				'novixa_ba_settings_heading',
				array(
					'label'     => __( 'Slider Settings', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::HEADING,
					'separator' => 'before',
				)
			);

			$this->add_control(
				'novixa_ba_orientation',
				array(
					'label'   => __( 'Orientation', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'horizontal',
					'options' => array(
						'horizontal' => __( 'Horizontal (drag left/right)', 'novixa-addons-for-elementor' ),
						'vertical'   => __( 'Vertical (drag up/down)', 'novixa-addons-for-elementor' ),
					),
				)
			);

			$this->add_control(
				'novixa_ba_start_position',
				array(
					'label'       => __( 'Initial Position', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::SLIDER,
					'range'       => array(
						'px' => array(
							'min' => 0,
							'max' => 100,
						),
					),
					'default'     => array(
						'unit' => 'px',
						'size' => 50,
					),
					'description' => __( 'Where the handle sits before anyone drags it, as a percentage across the frame.', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_ba_hover_move',
				array(
					'label'        => __( 'Move On Hover', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => '',
					'description'  => __( 'If enabled, the slider also follows the mouse on hover, without needing to click and drag first.', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_ba_show_labels',
				array(
					'label'        => __( 'Show Labels', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'yes',
				)
			);

			$this->add_control(
				'novixa_ba_autohide_labels',
				array(
					'label'        => __( 'Auto-hide Label on Approach', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'yes',
					'condition'    => array(
						'novixa_ba_show_labels' => 'yes',
					),
					'description'  => __( 'Instantly hides a label once you drag the handle close to it, so it never overlaps the shrinking sliver of image on that side.', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_ba_show_handle_icon',
				array(
					'label'        => __( 'Show Handle Arrows', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'yes',
				)
			);

			$this->add_control(
				'novixa_ba_motion_heading',
				array(
					'label'     => __( 'Motion', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::HEADING,
					'separator' => 'before',
				)
			);

			$this->add_control(
				'novixa_ba_reveal_on_scroll',
				array(
					'label'        => __( 'Reveal Animation on Scroll', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'yes',
					'description'  => __( 'The first time this scrolls into view, the handle sweeps from the edge to its Initial Position instead of just appearing there.', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_ba_autoplay',
				array(
					'label'        => __( 'Autoplay (Sweep Demo)', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => '',
					'description'  => __( 'Gently sweeps the handle back and forth on its own to draw attention - stops permanently the moment a visitor touches it.', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_ba_autoplay_speed',
				array(
					'label'       => __( 'Sweep Duration (seconds)', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::NUMBER,
					'min'         => 1,
					'max'         => 15,
					'step'        => 0.5,
					'default'     => 4,
					'condition'   => array(
						'novixa_ba_autoplay' => 'yes',
					),
					'description' => __( 'How long one pass (edge to edge) takes.', 'novixa-addons-for-elementor' ),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab — Media (frame) section. The Height control here is
		 * the one that matters most: since both images are painted at
		 * the frame's own size (see class docblock), setting a height
		 * here works exactly like it would on a plain image widget.
		 */
		protected function register_media_style_controls() {
			$this->start_controls_section(
				'novixa_section_ba_media_style',
				array(
					'label' => __( 'Media', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_responsive_control(
				'novixa_ba_height',
				array(
					'label'      => __( 'Height', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => array( 'px', 'vh' ),
					'range'      => array(
						'px' => array(
							'min' => 100,
							'max' => 900,
						),
						'vh' => array(
							'min' => 10,
							'max' => 100,
						),
					),
					'default'    => array(
						'unit' => 'px',
						'size' => 400,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'before-after', 'frame' ) => 'height: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_control(
				'novixa_ba_object_fit',
				array(
					'label'     => __( 'Object Fit', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SELECT,
					'default'   => 'cover',
					'options'   => array(
						'cover'   => __( 'Cover', 'novixa-addons-for-elementor' ),
						'contain' => __( 'Contain', 'novixa-addons-for-elementor' ),
						'fill'    => __( 'Fill (stretch)', 'novixa-addons-for-elementor' ),
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'before-after', 'layer' ) . ' img' => 'object-fit: {{VALUE}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_ba_border_radius',
				array(
					'label'      => __( 'Border Radius', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', '%' ),
					'default'    => array(
						'top'      => 12,
						'right'    => 12,
						'bottom'   => 12,
						'left'     => 12,
						'unit'     => 'px',
						'isLinked' => true,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'before-after', 'frame' ) => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Box_Shadow::get_type(),
				array(
					'name'     => 'novixa_ba_box_shadow',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'before-after', 'frame' ),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab — Handle & divider line section.
		 */
		protected function register_handle_style_controls() {
			$this->start_controls_section(
				'novixa_section_ba_handle_style',
				array(
					'label' => __( 'Handle', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_control(
				'novixa_ba_line_color',
				array(
					'label'     => __( 'Divider Line Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#ffffff',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'before-after', 'handle-line' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_ba_line_width',
				array(
					'label'     => __( 'Divider Line Width', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 1,
							'max' => 10,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 3,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'before-after' ) => '--novixa-ba-line-size: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_ba_handle_size',
				array(
					'label'     => __( 'Handle Size', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 24,
							'max' => 100,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 48,
					),
					'separator' => 'before',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'before-after', 'handle-circle' ) => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_control(
				'novixa_ba_handle_bg_color',
				array(
					'label'     => __( 'Handle Background', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#ffffff',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'before-after', 'handle-circle' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_ba_handle_icon_color',
				array(
					'label'     => __( 'Handle Arrow Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#141414',
					'condition' => array(
						'novixa_ba_show_handle_icon' => 'yes',
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'before-after', 'handle-circle' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Box_Shadow::get_type(),
				array(
					'name'     => 'novixa_ba_handle_shadow',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'before-after', 'handle-circle' ),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab — Labels section.
		 */
		protected function register_label_style_controls() {
			$this->start_controls_section(
				'novixa_section_ba_label_style',
				array(
					'label'     => __( 'Labels', 'novixa-addons-for-elementor' ),
					'tab'       => Controls_Manager::TAB_STYLE,
					'condition' => array(
						'novixa_ba_show_labels' => 'yes',
					),
				)
			);

			$this->add_control(
				'novixa_ba_label_bg_color',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => 'rgba(20, 20, 20, 0.65)',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'before-after', 'label' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_ba_label_text_color',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#ffffff',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'before-after', 'label' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'     => 'novixa_ba_label_typography',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'before-after', 'label' ),
				)
			);

			$this->add_responsive_control(
				'novixa_ba_label_padding',
				array(
					'label'      => __( 'Padding', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', 'em' ),
					'default'    => array(
						'top'      => 6,
						'right'    => 14,
						'bottom'   => 6,
						'left'     => 14,
						'unit'     => 'px',
						'isLinked' => false,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'before-after', 'label' ) => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_ba_label_radius',
				array(
					'label'      => __( 'Border Radius', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', '%' ),
					'default'    => array(
						'top'      => 4,
						'right'    => 4,
						'bottom'   => 4,
						'left'     => 4,
						'unit'     => 'px',
						'isLinked' => true,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'before-after', 'label' ) => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_ba_label_offset',
				array(
					'label'       => __( 'Edge Spacing', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::SLIDER,
					'range'       => array(
						'px' => array(
							'min' => 0,
							'max' => 60,
						),
					),
					'default'     => array(
						'unit' => 'px',
						'size' => 16,
					),
					'description' => __( 'Distance from the frame\'s edges.', 'novixa-addons-for-elementor' ),
					'selectors'   => array(
						'{{WRAPPER}} .' . $this->bem( 'before-after' ) => '--novixa-ba-label-offset: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Render.
		 */
		protected function render() {
			$settings = $this->get_settings_for_display();

			$orientation      = ( 'vertical' === $settings['novixa_ba_orientation'] ) ? 'vertical' : 'horizontal';
			$start            = isset( $settings['novixa_ba_start_position']['size'] ) && '' !== $settings['novixa_ba_start_position']['size']
				? (float) $settings['novixa_ba_start_position']['size']
				: 50;
			$start            = max( 0, min( 100, $start ) );
			$show_labels      = 'yes' === $settings['novixa_ba_show_labels'];
			$autohide_labels  = $show_labels && 'yes' === $settings['novixa_ba_autohide_labels'];
			$show_handle_icon = 'yes' === $settings['novixa_ba_show_handle_icon'];
			$hover_move       = 'yes' === $settings['novixa_ba_hover_move'];
			$reveal_on_scroll = 'yes' === $settings['novixa_ba_reveal_on_scroll'];
			$autoplay         = 'yes' === $settings['novixa_ba_autoplay'];
			$autoplay_speed   = ! empty( $settings['novixa_ba_autoplay_speed'] ) ? (float) $settings['novixa_ba_autoplay_speed'] : 4;

			$wrapper_classes = array_merge(
				array(
					$this->bem( 'before-after' ),
					$this->bem( 'before-after', '', $orientation ),
				),
				$this->get_visibility_classes( $settings )
			);

			$this->add_render_attribute( 'novixa_ba_wrapper', 'class', $wrapper_classes );
			$this->add_render_attribute( 'novixa_ba_wrapper', 'data-novixa-orientation', $orientation );
			$this->add_render_attribute( 'novixa_ba_wrapper', 'data-novixa-hover-move', $hover_move ? '1' : '0' );
			$this->add_render_attribute( 'novixa_ba_wrapper', 'data-novixa-autohide-labels', $autohide_labels ? '1' : '0' );
			$this->add_render_attribute( 'novixa_ba_wrapper', 'data-novixa-reveal-on-scroll', $reveal_on_scroll ? '1' : '0' );
			$this->add_render_attribute( 'novixa_ba_wrapper', 'data-novixa-autoplay', $autoplay ? '1' : '0' );
			$this->add_render_attribute( 'novixa_ba_wrapper', 'data-novixa-autoplay-speed', $autoplay_speed );
			$this->add_render_attribute( 'novixa_ba_wrapper', 'data-novixa-start', $start );

			$this->add_render_attribute( 'novixa_ba_frame', 'class', $this->bem( 'before-after', 'frame' ) );
			$this->add_render_attribute( 'novixa_ba_frame', 'style', '--novixa-ba-pos: ' . esc_attr( $start ) . '%;' );

			printf( '<div %1$s>', $this->get_render_attribute_string( 'novixa_ba_wrapper' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			printf( '<div %1$s>', $this->get_render_attribute_string( 'novixa_ba_frame' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

			// After layer — sits underneath, fully visible, acts as the base.
			printf( '<div class="%1$s">', esc_attr( $this->bem( 'before-after', 'layer' ) . ' ' . $this->bem( 'before-after', 'layer', 'after' ) ) );
			echo Group_Control_Image_Size::get_attachment_image_html( $settings, 'novixa_ba_image_size', 'novixa_ba_after_image' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '</div>';

			// Before layer — stacked on top, revealed/hidden via clip-path.
			printf( '<div class="%1$s">', esc_attr( $this->bem( 'before-after', 'layer' ) . ' ' . $this->bem( 'before-after', 'layer', 'before' ) ) );
			echo Group_Control_Image_Size::get_attachment_image_html( $settings, 'novixa_ba_image_size', 'novixa_ba_before_image' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '</div>';

			if ( $show_labels ) {
				if ( '' !== $settings['novixa_ba_before_label'] ) {
					printf(
						'<span class="%1$s">%2$s</span>',
						esc_attr( $this->bem( 'before-after', 'label' ) . ' ' . $this->bem( 'before-after', 'label', 'before' ) ),
						esc_html( $settings['novixa_ba_before_label'] )
					);
				}
				if ( '' !== $settings['novixa_ba_after_label'] ) {
					printf(
						'<span class="%1$s">%2$s</span>',
						esc_attr( $this->bem( 'before-after', 'label' ) . ' ' . $this->bem( 'before-after', 'label', 'after' ) ),
						esc_html( $settings['novixa_ba_after_label'] )
					);
				}
			}

			printf(
				'<div class="%1$s" tabindex="0" role="slider" aria-label="%2$s" aria-valuemin="0" aria-valuemax="100" aria-valuenow="%3$s" aria-orientation="%4$s">',
				esc_attr( $this->bem( 'before-after', 'handle' ) ),
				esc_attr__( 'Before/after image comparison slider', 'novixa-addons-for-elementor' ),
				esc_attr( round( $start ) ),
				esc_attr( $orientation )
			);
			printf( '<span class="%1$s"></span>', esc_attr( $this->bem( 'before-after', 'handle-line' ) ) );
			printf( '<span class="%1$s">', esc_attr( $this->bem( 'before-after', 'handle-circle' ) ) );
			if ( $show_handle_icon ) {
				echo '<svg viewBox="0 0 24 24" width="42%" height="42%" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="8 7 3 12 8 17"></polyline><polyline points="16 7 21 12 16 17"></polyline></svg>';
			}
			echo '</span>';
			echo '</div>'; // .handle

			echo '</div>'; // .frame
			echo '</div>'; // .novixa-addons-before-after
		}
	}
}
