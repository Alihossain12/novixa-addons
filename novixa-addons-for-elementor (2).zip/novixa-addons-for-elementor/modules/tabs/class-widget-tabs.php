<?php
/**
 * Tabs widget — a set of labeled tabs, one panel visible at a time,
 * modeled on Elementor's own native Tabs widget (Direction / Justify /
 * Align Title controls, Top/Bottom/Start/End layouts).
 *
 * Each tab's content is a WYSIWYG rich-text field — see the same note
 * in modules/accordion/class-widget-accordion.php about why true
 * drag-and-drop nested widgets per tab isn't practical to replicate
 * here.
 *
 * Switching tabs is handled by the shared document-level event
 * delegation in assets/js/frontend.js (same reasoning as the
 * Accordion widgets: a <script> tag printed inside AJAX-rendered
 * widget markup never auto-executes inside the Elementor editor).
 *
 * @package Novixa_Addons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if ( ! class_exists( 'Novixa_Addons_Widget_Tabs' ) ) {

	/**
	 * Class Novixa_Addons_Widget_Tabs
	 */
	class Novixa_Addons_Widget_Tabs extends Novixa_Addons_Widget_Base {

		/**
		 * Unique widget name registered with Elementor.
		 *
		 * @return string
		 */
		public function get_name() {
			return 'novixa-addons-tabs';
		}

		/**
		 * Panel label.
		 *
		 * @return string
		 */
		public function get_title() {
			return __( 'Tabs - Novixa', 'novixa-addons-for-elementor' );
		}

		/**
		 * Panel icon.
		 *
		 * @return string
		 */
		public function get_icon() {
			return 'eicon-tabs';
		}

		/**
		 * Panel search keywords.
		 *
		 * @return array
		 */
		public function get_keywords() {
			return array_merge( $this->get_base_keywords(), array( 'tabs', 'tab', 'toggle', 'panel' ) );
		}

		/**
		 * Script dependency. Without this, Elementor never prints
		 * 'novixa-addons-frontend' (the file with the tab-switching
		 * click handler) on the isolated AJAX request it uses to
		 * render this widget every time a setting changes in the
		 * editor — so clicking a tab in the canvas silently does
		 * nothing, even though a full page load (front-end "view"
		 * mode) can be fine. See the same note on the Button widget.
		 *
		 * @return array
		 */
		public function get_script_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Style dependency.
		 *
		 * @return array
		 */
		public function get_style_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Register all controls.
		 */
		protected function register_controls() {
			$this->register_content_controls();
			$this->register_nav_style_controls();
			$this->register_content_style_controls();
		}

		/**
		 * Content tab.
		 */
		protected function register_content_controls() {
			$this->start_controls_section(
				'novixa_section_tabs',
				array(
					'label' => __( 'Tabs', 'novixa-addons-for-elementor' ),
				)
			);

			$repeater = new Repeater();

			$repeater->add_control(
				'novixa_tab_title',
				array(
					'label'       => __( 'Title', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( 'Tab', 'novixa-addons-for-elementor' ),
					'label_block' => true,
				)
			);

			$repeater->add_control(
				'novixa_tab_content',
				array(
					'label'      => __( 'Content', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::WYSIWYG,
					'default'    => __( 'Type the content for this tab here.', 'novixa-addons-for-elementor' ),
					'show_label' => false,
				)
			);

			$this->add_control(
				'novixa_tabs',
				array(
					'label'       => __( 'Tabs Items', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::REPEATER,
					'fields'      => $repeater->get_controls(),
					'default'     => array(
						array(
							'novixa_tab_title'   => __( 'Tab #1', 'novixa-addons-for-elementor' ),
							'novixa_tab_content' => __( 'Type the content for this tab here.', 'novixa-addons-for-elementor' ),
						),
						array(
							'novixa_tab_title'   => __( 'Tab #2', 'novixa-addons-for-elementor' ),
							'novixa_tab_content' => __( 'Type the content for this tab here.', 'novixa-addons-for-elementor' ),
						),
						array(
							'novixa_tab_title'   => __( 'Tab #3', 'novixa-addons-for-elementor' ),
							'novixa_tab_content' => __( 'Type the content for this tab here.', 'novixa-addons-for-elementor' ),
						),
					),
					'title_field' => '{{{ novixa_tab_title }}}',
				)
			);

			$this->add_responsive_control(
				'novixa_direction',
				array(
					'label'        => __( 'Direction', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::CHOOSE,
					'default'      => 'top',
					'options'      => array(
						'top'    => array(
							'title' => __( 'Top', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-v-align-top',
						),
						'bottom' => array(
							'title' => __( 'Bottom', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-v-align-bottom',
						),
						'start'  => array(
							'title' => __( 'Start', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-h-align-left',
						),
						'end'    => array(
							'title' => __( 'End', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-h-align-right',
						),
					),
					'prefix_class' => 'novixa-addons-tabs--direction-',
				)
			);

			$this->add_responsive_control(
				'novixa_justify',
				array(
					'label'     => __( 'Justify', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::CHOOSE,
					'default'   => 'start',
					'options'   => array(
						'flex-start'    => array(
							'title' => __( 'Start', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-h-align-left',
						),
						'center'        => array(
							'title' => __( 'Center', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-h-align-center',
						),
						'flex-end'      => array(
							'title' => __( 'End', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-h-align-right',
						),
						'stretch'       => array(
							'title' => __( 'Stretch', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-h-align-stretch',
						),
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'tabs', 'nav' ) => 'justify-content: {{VALUE}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_align_title',
				array(
					'label'     => __( 'Align Title', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::CHOOSE,
					'default'   => 'center',
					'options'   => array(
						'left'   => array(
							'title' => __( 'Left', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-left',
						),
						'center' => array(
							'title' => __( 'Center', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-center',
						),
						'right'  => array(
							'title' => __( 'Right', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-right',
						),
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'tabs', 'nav-item' ) => 'text-align: {{VALUE}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > the tab buttons (nav).
		 */
		protected function register_nav_style_controls() {
			$this->start_controls_section(
				'novixa_section_nav_style',
				array(
					'label' => __( 'Tabs', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'     => 'novixa_nav_typography',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'tabs', 'nav-item' ),
				)
			);

			$this->add_responsive_control(
				'novixa_nav_padding',
				array(
					'label'      => __( 'Padding', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', 'em', '%' ),
					'default'    => array(
						'top'      => 14,
						'right'    => 24,
						'bottom'   => 14,
						'left'     => 24,
						'unit'     => 'px',
						'isLinked' => false,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'tabs', 'nav-item' ) => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_nav_radius',
				array(
					'label'      => __( 'Border Radius', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', '%' ),
					'default'    => array(
						'top'      => 6,
						'right'    => 6,
						'bottom'   => 6,
						'left'     => 6,
						'unit'     => 'px',
						'isLinked' => true,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'tabs', 'nav-item' ) => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Border::get_type(),
				array(
					'name'     => 'novixa_nav_border',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'tabs', 'nav-item' ),
				)
			);

			$this->start_controls_tabs( 'novixa_nav_state_tabs' );

			$this->start_controls_tab(
				'novixa_nav_state_normal',
				array( 'label' => __( 'Normal', 'novixa-addons-for-elementor' ) )
			);

			$this->add_control(
				'novixa_nav_bg_normal',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#f2f1fb',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'tabs', 'nav-item' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_nav_text_normal',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#4a4767',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'tabs', 'nav-item' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'novixa_nav_state_hover',
				array( 'label' => __( 'Hover', 'novixa-addons-for-elementor' ) )
			);

			$this->add_control(
				'novixa_nav_bg_hover',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'tabs', 'nav-item' ) . ':hover' => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_nav_text_hover',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'tabs', 'nav-item' ) . ':hover' => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_nav_border_color_hover',
				array(
					'label'     => __( 'Border Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'condition' => array(
						'novixa_nav_border_border!' => '',
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'tabs', 'nav-item' ) . ':hover' => 'border-color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'novixa_nav_state_active',
				array( 'label' => __( 'Active', 'novixa-addons-for-elementor' ) )
			);

			$this->add_control(
				'novixa_nav_bg_active',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#4f3ff0',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'tabs', 'nav-item', 'active' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_nav_text_active',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#ffffff',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'tabs', 'nav-item', 'active' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_nav_border_color_active',
				array(
					'label'     => __( 'Border Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'condition' => array(
						'novixa_nav_border_border!' => '',
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'tabs', 'nav-item', 'active' ) => 'border-color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_tab();

			$this->end_controls_tabs();

			$this->add_responsive_control(
				'novixa_nav_gap',
				array(
					'label'     => __( 'Gap Between Tabs', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'separator' => 'before',
					'range'     => array(
						'px' => array(
							'min' => 0,
							'max' => 40,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 6,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'tabs', 'nav' ) => 'gap: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > the panel content.
		 */
		protected function register_content_style_controls() {
			$this->start_controls_section(
				'novixa_section_content_style',
				array(
					'label' => __( 'Content', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_control(
				'novixa_content_bg_color',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#ffffff',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'tabs', 'panels' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_content_text_color',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#4a4767',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'tabs', 'panel-inner' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'     => 'novixa_content_typography',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'tabs', 'panel-inner' ),
				)
			);

			$this->add_responsive_control(
				'novixa_content_padding',
				array(
					'label'      => __( 'Padding', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', 'em', '%' ),
					'default'    => array(
						'top'      => 30,
						'right'    => 30,
						'bottom'   => 30,
						'left'     => 30,
						'unit'     => 'px',
						'isLinked' => true,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'tabs', 'panel-inner' ) => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Border::get_type(),
				array(
					'name'     => 'novixa_content_border',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'tabs', 'panels' ),
				)
			);

			$this->add_group_control(
				Group_Control_Box_Shadow::get_type(),
				array(
					'name'     => 'novixa_content_shadow',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'tabs', 'panels' ),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Front-end render.
		 */
		protected function render() {
			$settings = $this->get_settings_for_display();

			$tabs = ! empty( $settings['novixa_tabs'] ) ? $settings['novixa_tabs'] : array();
			if ( empty( $tabs ) ) {
				return;
			}

			$uid = 'novixa-tabs-' . esc_attr( $this->get_id() );

			printf( '<div class="%1$s" id="%2$s">', esc_attr( $this->bem( 'tabs' ) ), esc_attr( $uid ) );

			printf( '<div class="%1$s" role="tablist">', esc_attr( $this->bem( 'tabs', 'nav' ) ) );
			foreach ( $tabs as $index => $tab ) {
				$is_active = ( 0 === $index );
				$nav_class  = $this->bem( 'tabs', 'nav-item' );
				if ( $is_active ) {
					$nav_class .= ' ' . $this->bem( 'tabs', 'nav-item', 'active' );
				}
				printf(
					'<button type="button" class="%1$s" data-tab-index="%2$d" role="tab" aria-selected="%3$s">%4$s</button>',
					esc_attr( $nav_class ),
					(int) $index,
					$is_active ? 'true' : 'false',
					esc_html( $tab['novixa_tab_title'] )
				);
			}
			echo '</div>'; // .nav

			printf( '<div class="%1$s">', esc_attr( $this->bem( 'tabs', 'panels' ) ) );
			foreach ( $tabs as $index => $tab ) {
				$is_active   = ( 0 === $index );
				$panel_class = $this->bem( 'tabs', 'panel' );
				if ( $is_active ) {
					$panel_class .= ' ' . $this->bem( 'tabs', 'panel', 'active' );
				}
				printf(
					'<div class="%1$s" data-tab-index="%2$d" role="tabpanel" style="display:%3$s;">',
					esc_attr( $panel_class ),
					(int) $index,
					$is_active ? 'block' : 'none'
				);
				printf( '<div class="%1$s">', esc_attr( $this->bem( 'tabs', 'panel-inner' ) ) );
				echo wp_kses_post( $tab['novixa_tab_content'] );
				echo '</div>';
				echo '</div>'; // .panel
			}
			echo '</div>'; // .panels

			echo '</div>'; // .tabs
		}
	}
}
