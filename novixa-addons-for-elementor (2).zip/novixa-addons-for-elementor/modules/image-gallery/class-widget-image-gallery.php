<?php
/**
 * Image Gallery widget.
 *
 * A luxury filterable image gallery: Grid or Masonry layout, optional
 * category filter bar, a hover overlay (zoom icon + caption), and a
 * built-in lightbox (prev/next, keyboard, counter, caption) - all
 * without any external JS library, matching the rest of this plugin's
 * "plain JS + shared frontend.js" approach (see assets/js/frontend.js).
 *
 * @package Novixa_Addons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Utils;

if ( ! class_exists( 'Novixa_Addons_Widget_Image_Gallery' ) ) {

	/**
	 * Class Novixa_Addons_Widget_Image_Gallery
	 */
	class Novixa_Addons_Widget_Image_Gallery extends Novixa_Addons_Widget_Base {

		use Novixa_Addons_Global_Controls;

		/**
		 * Unique widget name registered with Elementor.
		 *
		 * @return string
		 */
		public function get_name() {
			return 'novixa-addons-image-gallery';
		}

		/**
		 * Panel label.
		 *
		 * @return string
		 */
		public function get_title() {
			return __( 'Image Gallery - Novixa', 'novixa-addons-for-elementor' );
		}

		/**
		 * Panel icon.
		 *
		 * @return string
		 */
		public function get_icon() {
			return 'eicon-gallery-grid';
		}

		/**
		 * Panel search keywords.
		 *
		 * @return array
		 */
		public function get_keywords() {
			return array_merge( $this->get_base_keywords(), array( 'gallery', 'images', 'photo', 'grid', 'masonry', 'lightbox', 'filter', 'portfolio' ) );
		}

		/**
		 * Script dependency.
		 *
		 * @return array
		 */
		public function get_script_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Style dependency.
		 *
		 * @return array
		 */
		public function get_style_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Register all controls.
		 */
		protected function register_controls() {
			$this->register_content_controls();
			$this->register_layout_controls();
			$this->register_filter_controls();
			$this->register_hover_controls();
			$this->register_lightbox_controls();
			$this->register_grid_style_controls();
			$this->register_overlay_style_controls();
			$this->register_caption_style_controls();
			$this->register_filter_style_controls();
			$this->register_lightbox_style_controls();
			$this->register_visibility_controls();
			$this->register_spacing_controls();
		}

		/**
		 * Common WordPress image sizes, offered wherever the widget lets
		 * the user pick a resolution (grid thumbnail, lightbox image).
		 *
		 * @return array
		 */
		private function get_image_size_options() {
			return array(
				'thumbnail'    => __( 'Thumbnail', 'novixa-addons-for-elementor' ),
				'medium'       => __( 'Medium', 'novixa-addons-for-elementor' ),
				'medium_large' => __( 'Medium Large', 'novixa-addons-for-elementor' ),
				'large'        => __( 'Large', 'novixa-addons-for-elementor' ),
				'full'         => __( 'Full', 'novixa-addons-for-elementor' ),
			);
		}

		/**
		 * Content tab — the repeater of gallery images.
		 */
		protected function register_content_controls() {
			$this->start_controls_section(
				'novixa_section_gallery_content',
				array(
					'label' => __( 'Gallery Images', 'novixa-addons-for-elementor' ),
				)
			);

			$repeater = new Repeater();

			$repeater->add_control(
				'novixa_gallery_image',
				array(
					'label'   => __( 'Image', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::MEDIA,
					'default' => array(
						'url' => Utils::get_placeholder_image_src(),
					),
				)
			);

			$repeater->add_control(
				'novixa_gallery_title',
				array(
					'label'       => __( 'Title', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( 'Gallery Image', 'novixa-addons-for-elementor' ),
					'label_block' => true,
				)
			);

			$repeater->add_control(
				'novixa_gallery_caption',
				array(
					'label'       => __( 'Caption (optional)', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXTAREA,
					'default'     => '',
					'label_block' => true,
					'rows'        => 2,
				)
			);

			$repeater->add_control(
				'novixa_gallery_category',
				array(
					'label'       => __( 'Categories (optional)', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => '',
					'label_block' => true,
					'description' => __( 'Comma-separated, e.g. "Rooms, Suites". Used to build the filter bar below.', 'novixa-addons-for-elementor' ),
				)
			);

			$repeater->add_control(
				'novixa_gallery_link',
				array(
					'label'       => __( 'Link (optional)', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::URL,
					'default'     => array(
						'url' => '',
					),
					'label_block' => true,
					'description' => __( 'Only used when "On Click" (Lightbox section) is set to Go to Link.', 'novixa-addons-for-elementor' ),
				)
			);

			$repeater->add_control(
				'novixa_gallery_hide',
				array(
					'label'        => __( 'Hide This Image', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Hidden', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'Visible', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => '',
					'description'  => __( 'Temporarily remove this image from the gallery without deleting it.', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_gallery_items',
				array(
					'label'       => __( 'Images', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::REPEATER,
					'fields'      => $repeater->get_controls(),
					'default'     => array(
						array(),
						array(),
						array(),
						array(),
						array(),
						array(),
					),
					'title_field' => '{{{ novixa_gallery_title || "Gallery Image" }}}{{{ novixa_gallery_hide ? " (Hidden)" : "" }}}',
				)
			);

			$this->add_control(
				'novixa_gallery_image_size',
				array(
					'label'     => __( 'Grid Image Resolution', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SELECT,
					'default'   => 'large',
					'options'   => $this->get_image_size_options(),
					'separator' => 'before',
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Content tab — layout (grid/masonry, columns, gap, aspect ratio).
		 */
		protected function register_layout_controls() {
			$this->start_controls_section(
				'novixa_section_gallery_layout',
				array(
					'label' => __( 'Layout', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_gallery_layout',
				array(
					'label'   => __( 'Layout', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'grid',
					'options' => array(
						'grid'     => __( 'Grid (equal cells)', 'novixa-addons-for-elementor' ),
						'masonry'  => __( 'Masonry (natural heights)', 'novixa-addons-for-elementor' ),
					),
				)
			);

			$this->add_responsive_control(
				'novixa_gallery_columns',
				array(
					'label'       => __( 'Columns', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::SLIDER,
					'range'       => array(
						'px' => array(
							'min' => 1,
							'max' => 6,
							'step' => 1,
						),
					),
					'default'     => array(
						'unit' => 'px',
						'size' => 3,
					),
					'tablet_default' => array(
						'unit' => 'px',
						'size' => 2,
					),
					'mobile_default' => array(
						'unit' => 'px',
						'size' => 1,
					),
					'selectors'   => array(
						'{{WRAPPER}} .' . $this->bem( 'gallery', 'grid' ) => '--novixa-gallery-columns: {{SIZE}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_gallery_gap',
				array(
					'label'     => __( 'Gap', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 0,
							'max' => 80,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 20,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'gallery', 'grid' ) => '--novixa-gallery-gap: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_control(
				'novixa_gallery_aspect_ratio',
				array(
					'label'     => __( 'Image Aspect Ratio', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SELECT,
					'default'   => '1/1',
					'options'   => array(
						'auto'  => __( 'Auto (natural size)', 'novixa-addons-for-elementor' ),
						'1/1'   => __( 'Square (1:1)', 'novixa-addons-for-elementor' ),
						'4/3'   => __( 'Standard (4:3)', 'novixa-addons-for-elementor' ),
						'3/4'   => __( 'Portrait (3:4)', 'novixa-addons-for-elementor' ),
						'16/9'  => __( 'Widescreen (16:9)', 'novixa-addons-for-elementor' ),
						'3/2'   => __( 'Classic (3:2)', 'novixa-addons-for-elementor' ),
						'fixed' => __( 'Fixed Height (custom)', 'novixa-addons-for-elementor' ),
					),
					'condition' => array(
						'novixa_gallery_layout' => 'grid',
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'gallery', 'thumb' ) => 'aspect-ratio: {{VALUE}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_gallery_fixed_height',
				array(
					'label'      => __( 'Height', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => array( 'px' ),
					'range'      => array(
						'px' => array(
							'min' => 80,
							'max' => 800,
						),
					),
					'default'        => array(
						'unit' => 'px',
						'size' => 300,
					),
					'tablet_default' => array(
						'unit' => 'px',
						'size' => 260,
					),
					'mobile_default' => array(
						'unit' => 'px',
						'size' => 220,
					),
					'condition'  => array(
						'novixa_gallery_layout'       => 'grid',
						'novixa_gallery_aspect_ratio' => 'fixed',
					),
					'description' => __( 'Every image is cropped (not stretched) to exactly this height, so the grid stays perfectly even no matter what size the original photos are.', 'novixa-addons-for-elementor' ),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'gallery', 'thumb' ) => 'aspect-ratio: unset; height: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Content tab — filter bar.
		 */
		protected function register_filter_controls() {
			$this->start_controls_section(
				'novixa_section_gallery_filter',
				array(
					'label' => __( 'Filter Bar', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_gallery_show_filter',
				array(
					'label'        => __( 'Show Filter Bar', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => '',
					'description'  => __( 'Builds filter buttons automatically from each image\'s Categories field.', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_gallery_filter_all_label',
				array(
					'label'     => __( '"Show All" Label', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::TEXT,
					'default'   => __( 'All', 'novixa-addons-for-elementor' ),
					'condition' => array(
						'novixa_gallery_show_filter' => 'yes',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Content tab — hover effect + caption placement.
		 */
		protected function register_hover_controls() {
			$this->start_controls_section(
				'novixa_section_gallery_hover',
				array(
					'label' => __( 'Hover Effect', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_gallery_hover_effect',
				array(
					'label'   => __( 'Image Hover', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'zoom',
					'options' => array(
						'zoom' => __( 'Zoom Image', 'novixa-addons-for-elementor' ),
						'none' => __( 'None', 'novixa-addons-for-elementor' ),
					),
				)
			);

			$this->add_control(
				'novixa_gallery_show_overlay',
				array(
					'label'        => __( 'Show Hover Overlay', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'yes',
				)
			);

			$this->add_control(
				'novixa_gallery_show_icon',
				array(
					'label'        => __( 'Show Zoom Icon', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'yes',
					'condition'    => array(
						'novixa_gallery_show_overlay' => 'yes',
					),
				)
			);

			$this->add_control(
				'novixa_gallery_caption_position',
				array(
					'label'     => __( 'Caption Position', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SELECT,
					'default'   => 'overlay',
					'options'   => array(
						'overlay' => __( 'In Hover Overlay', 'novixa-addons-for-elementor' ),
						'below'   => __( 'Below Image (always visible)', 'novixa-addons-for-elementor' ),
						'hidden'  => __( 'Hidden', 'novixa-addons-for-elementor' ),
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Content tab — lightbox behaviour.
		 */
		protected function register_lightbox_controls() {
			$this->start_controls_section(
				'novixa_section_gallery_lightbox',
				array(
					'label' => __( 'Lightbox', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_gallery_click_action',
				array(
					'label'   => __( 'On Click', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'lightbox',
					'options' => array(
						'lightbox' => __( 'Open Lightbox', 'novixa-addons-for-elementor' ),
						'link'     => __( 'Go to Link', 'novixa-addons-for-elementor' ),
						'none'     => __( 'Nothing', 'novixa-addons-for-elementor' ),
					),
				)
			);

			$this->add_control(
				'novixa_gallery_lightbox_image_size',
				array(
					'label'     => __( 'Lightbox Image Resolution', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SELECT,
					'default'   => 'full',
					'options'   => $this->get_image_size_options(),
					'condition' => array(
						'novixa_gallery_click_action' => 'lightbox',
					),
				)
			);

			$this->add_control(
				'novixa_gallery_lightbox_show_caption',
				array(
					'label'        => __( 'Show Caption', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'yes',
					'condition'    => array(
						'novixa_gallery_click_action' => 'lightbox',
					),
				)
			);

			$this->add_control(
				'novixa_gallery_lightbox_show_counter',
				array(
					'label'        => __( 'Show Counter', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'yes',
					'description'  => __( 'e.g. "3 / 12".', 'novixa-addons-for-elementor' ),
					'condition'    => array(
						'novixa_gallery_click_action' => 'lightbox',
					),
				)
			);

			$this->add_control(
				'novixa_gallery_lightbox_show_arrows',
				array(
					'label'        => __( 'Show Navigation Arrows', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'yes',
					'condition'    => array(
						'novixa_gallery_click_action' => 'lightbox',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab — grid/item frame (radius, border, shadow).
		 */
		protected function register_grid_style_controls() {
			$this->start_controls_section(
				'novixa_section_gallery_grid_style',
				array(
					'label' => __( 'Grid Item', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_responsive_control(
				'novixa_gallery_item_radius',
				array(
					'label'      => __( 'Border Radius', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', '%' ),
					'default'    => array(
						'top'      => 10,
						'right'    => 10,
						'bottom'   => 10,
						'left'     => 10,
						'unit'     => 'px',
						'isLinked' => true,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'gallery', 'thumb' ) => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Border::get_type(),
				array(
					'name'     => 'novixa_gallery_item_border',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'gallery', 'thumb' ),
				)
			);

			$this->add_group_control(
				Group_Control_Box_Shadow::get_type(),
				array(
					'name'     => 'novixa_gallery_item_shadow',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'gallery', 'thumb' ),
				)
			);

			$this->add_control(
				'novixa_gallery_zoom_scale',
				array(
					'label'     => __( 'Hover Zoom Amount', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min'  => 100,
							'max'  => 130,
							'step' => 1,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 110,
					),
					'condition' => array(
						'novixa_gallery_hover_effect' => 'zoom',
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'gallery', 'thumb' ) => '--novixa-gallery-zoom: {{SIZE}}%;',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab — hover overlay, icon, and overlay caption.
		 */
		protected function register_overlay_style_controls() {
			$this->start_controls_section(
				'novixa_section_gallery_overlay_style',
				array(
					'label'     => __( 'Hover Overlay', 'novixa-addons-for-elementor' ),
					'tab'       => Controls_Manager::TAB_STYLE,
					'condition' => array(
						'novixa_gallery_show_overlay' => 'yes',
					),
				)
			);

			$this->add_control(
				'novixa_gallery_overlay_color',
				array(
					'label'     => __( 'Overlay Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => 'rgba(20, 20, 20, 0.72)',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'gallery', 'overlay' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_gallery_icon_heading',
				array(
					'label'     => __( 'Zoom Icon', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::HEADING,
					'separator' => 'before',
					'condition' => array(
						'novixa_gallery_show_icon' => 'yes',
					),
				)
			);

			$this->add_control(
				'novixa_gallery_icon_color',
				array(
					'label'     => __( 'Icon Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#141414',
					'condition' => array(
						'novixa_gallery_show_icon' => 'yes',
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'gallery', 'icon' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_gallery_icon_bg_color',
				array(
					'label'     => __( 'Icon Background', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#c9a15f',
					'condition' => array(
						'novixa_gallery_show_icon' => 'yes',
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'gallery', 'icon' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_gallery_icon_size',
				array(
					'label'     => __( 'Icon Size', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 24,
							'max' => 80,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 48,
					),
					'condition' => array(
						'novixa_gallery_show_icon' => 'yes',
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'gallery', 'icon' ) => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .' . $this->bem( 'gallery', 'icon' ) . ' svg' => 'width: calc( {{SIZE}}{{UNIT}} * 0.42 ); height: calc( {{SIZE}}{{UNIT}} * 0.42 );',
					),
				)
			);

			$this->add_control(
				'novixa_gallery_overlay_caption_heading',
				array(
					'label'     => __( 'Caption', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::HEADING,
					'separator' => 'before',
					'condition' => array(
						'novixa_gallery_caption_position' => 'overlay',
					),
				)
			);

			$this->add_control(
				'novixa_gallery_overlay_caption_color',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#ffffff',
					'condition' => array(
						'novixa_gallery_caption_position' => 'overlay',
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'gallery', 'overlay-title' ) => 'color: {{VALUE}};',
						'{{WRAPPER}} .' . $this->bem( 'gallery', 'overlay-caption' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'      => 'novixa_gallery_overlay_title_typography',
					'label'     => __( 'Title Typography', 'novixa-addons-for-elementor' ),
					'selector'  => '{{WRAPPER}} .' . $this->bem( 'gallery', 'overlay-title' ),
					'condition' => array(
						'novixa_gallery_caption_position' => 'overlay',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab — "below image" caption (only relevant in that mode).
		 */
		protected function register_caption_style_controls() {
			$this->start_controls_section(
				'novixa_section_gallery_caption_style',
				array(
					'label'     => __( 'Caption (Below Image)', 'novixa-addons-for-elementor' ),
					'tab'       => Controls_Manager::TAB_STYLE,
					'condition' => array(
						'novixa_gallery_caption_position' => 'below',
					),
				)
			);

			$this->add_control(
				'novixa_gallery_below_title_color',
				array(
					'label'     => __( 'Title Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#141414',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'gallery', 'caption-title' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'     => 'novixa_gallery_below_title_typography',
					'label'    => __( 'Title Typography', 'novixa-addons-for-elementor' ),
					'selector' => '{{WRAPPER}} .' . $this->bem( 'gallery', 'caption-title' ),
				)
			);

			$this->add_control(
				'novixa_gallery_below_text_color',
				array(
					'label'     => __( 'Caption Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#6b6b6b',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'gallery', 'caption-text' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab — filter buttons.
		 */
		protected function register_filter_style_controls() {
			$this->start_controls_section(
				'novixa_section_gallery_filter_style',
				array(
					'label'     => __( 'Filter Bar', 'novixa-addons-for-elementor' ),
					'tab'       => Controls_Manager::TAB_STYLE,
					'condition' => array(
						'novixa_gallery_show_filter' => 'yes',
					),
				)
			);

			$this->register_alignment_control(
				'novixa_gallery_filter_align',
				'{{WRAPPER}} .' . $this->bem( 'gallery', 'filter' )
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'     => 'novixa_gallery_filter_typography',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'gallery', 'filter-btn' ),
				)
			);

			$this->start_controls_tabs( 'novixa_gallery_filter_tabs' );

			$this->start_controls_tab(
				'novixa_gallery_filter_tab_normal',
				array(
					'label' => __( 'Normal', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_gallery_filter_color',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#6b6b6b',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'gallery', 'filter-btn' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'novixa_gallery_filter_tab_active',
				array(
					'label' => __( 'Active', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_gallery_filter_active_color',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#141414',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'gallery', 'filter-btn' ) . '.' . $this->bem( 'gallery', 'filter-btn', 'active' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_gallery_filter_active_line_color',
				array(
					'label'       => __( 'Underline Color', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::COLOR,
					'default'     => '#c9a15f',
					'description' => __( 'The small accent line under the active filter — the "luxury" touch.', 'novixa-addons-for-elementor' ),
					'selectors'   => array(
						'{{WRAPPER}} .' . $this->bem( 'gallery', 'filter-btn' ) . '.' . $this->bem( 'gallery', 'filter-btn', 'active' ) . '::after' => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_tab();

			$this->end_controls_tabs();

			$this->end_controls_section();
		}

		/**
		 * Style tab — lightbox chrome (overlay, arrows, close, caption, counter).
		 */
		protected function register_lightbox_style_controls() {
			$this->start_controls_section(
				'novixa_section_gallery_lightbox_style',
				array(
					'label'     => __( 'Lightbox', 'novixa-addons-for-elementor' ),
					'tab'       => Controls_Manager::TAB_STYLE,
					'condition' => array(
						'novixa_gallery_click_action' => 'lightbox',
					),
				)
			);

			$this->add_control(
				'novixa_gallery_lightbox_bg_color',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => 'rgba(10, 10, 10, 0.95)',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'gallery' ) . ' ~ .' . $this->bem( 'gallery-lightbox' ) => 'background-color: {{VALUE}};',
					),
					'description' => __( 'Applies once the lightbox for this gallery is open (it is inserted as a sibling right after the gallery grid, inside this widget).', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_gallery_lightbox_chrome_heading',
				array(
					'label'     => __( 'Arrows & Close Button', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::HEADING,
					'separator' => 'before',
				)
			);

			$this->add_control(
				'novixa_gallery_lightbox_chrome_color',
				array(
					'label'     => __( 'Icon Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#ffffff',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'gallery' ) . ' ~ .' . $this->bem( 'gallery-lightbox' ) . ' .' . $this->bem( 'gallery-lightbox', 'nav' ) => 'color: {{VALUE}};',
						'{{WRAPPER}} .' . $this->bem( 'gallery' ) . ' ~ .' . $this->bem( 'gallery-lightbox' ) . ' .' . $this->bem( 'gallery-lightbox', 'close' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_gallery_lightbox_chrome_bg',
				array(
					'label'     => __( 'Icon Background', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => 'rgba(255, 255, 255, 0.12)',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'gallery' ) . ' ~ .' . $this->bem( 'gallery-lightbox' ) . ' .' . $this->bem( 'gallery-lightbox', 'nav' ) => 'background-color: {{VALUE}};',
						'{{WRAPPER}} .' . $this->bem( 'gallery' ) . ' ~ .' . $this->bem( 'gallery-lightbox' ) . ' .' . $this->bem( 'gallery-lightbox', 'close' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_gallery_lightbox_caption_heading',
				array(
					'label'     => __( 'Caption & Counter', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::HEADING,
					'separator' => 'before',
				)
			);

			$this->add_control(
				'novixa_gallery_lightbox_caption_color',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#ffffff',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'gallery' ) . ' ~ .' . $this->bem( 'gallery-lightbox' ) . ' .' . $this->bem( 'gallery-lightbox', 'caption' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_gallery_lightbox_counter_color',
				array(
					'label'     => __( 'Counter Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#c9a15f',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'gallery' ) . ' ~ .' . $this->bem( 'gallery-lightbox' ) . ' .' . $this->bem( 'gallery-lightbox', 'counter' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Resolve an image field (MEDIA control value) to a URL at the
		 * requested registered size, falling back to the raw URL that
		 * was stored (e.g. for externally-hosted images) if the
		 * attachment/size lookup comes back empty.
		 *
		 * @param array  $image Repeater image field value.
		 * @param string $size  Registered image size.
		 * @return string
		 */
		private function get_image_src( $image, $size = 'large' ) {
			if ( ! empty( $image['id'] ) ) {
				$src = wp_get_attachment_image_src( $image['id'], $size );
				if ( $src && ! empty( $src[0] ) ) {
					return $src[0];
				}
			}

			return ! empty( $image['url'] ) ? $image['url'] : '';
		}

		/**
		 * Turn a "Rooms, Suites" style field into a clean array of
		 * unique, sanitized filter slugs.
		 *
		 * @param string $raw Raw comma-separated categories string.
		 * @return array
		 */
		private function parse_categories( $raw ) {
			if ( '' === trim( (string) $raw ) ) {
				return array();
			}

			$parts = array_map( 'trim', explode( ',', $raw ) );
			$parts = array_filter( $parts );

			$out = array();
			foreach ( $parts as $part ) {
				$out[ sanitize_title( $part ) ] = $part;
			}

			return $out;
		}

		/**
		 * Render the filter bar (only called when enabled and at least
		 * one image actually has a category).
		 *
		 * @param array $settings   Widget settings.
		 * @param array $categories Map of slug => original label, collected across all items.
		 */
		private function render_filter_bar( $settings, $categories ) {
			printf( '<div class="%1$s">', esc_attr( $this->bem( 'gallery', 'filter' ) ) );

			printf(
				'<button type="button" class="%1$s %2$s" data-novixa-filter="all">%3$s</button>',
				esc_attr( $this->bem( 'gallery', 'filter-btn' ) ),
				esc_attr( $this->bem( 'gallery', 'filter-btn', 'active' ) ),
				esc_html( $settings['novixa_gallery_filter_all_label'] )
			);

			foreach ( $categories as $slug => $label ) {
				printf(
					'<button type="button" class="%1$s" data-novixa-filter="%2$s">%3$s</button>',
					esc_attr( $this->bem( 'gallery', 'filter-btn' ) ),
					esc_attr( $slug ),
					esc_html( $label )
				);
			}

			echo '</div>';
		}

		/**
		 * Render one gallery item (thumb + overlay + optional below-caption).
		 *
		 * @param array $item     Repeater row.
		 * @param array $settings Widget settings.
		 */
		private function render_item( $item, $settings ) {
			$categories    = $this->parse_categories( $item['novixa_gallery_category'] );
			$category_data = implode( ',', array_keys( $categories ) );

			$grid_src  = $this->get_image_src( $item['novixa_gallery_image'], $settings['novixa_gallery_image_size'] );
			$full_src  = $this->get_image_src( $item['novixa_gallery_image'], $settings['novixa_gallery_lightbox_image_size'] );
			$title     = $item['novixa_gallery_title'];
			$caption   = $item['novixa_gallery_caption'];
			$click     = $settings['novixa_gallery_click_action'];

			printf(
				'<div class="%1$s" data-novixa-category="%2$s">',
				esc_attr( $this->bem( 'gallery', 'item' ) ),
				esc_attr( $category_data )
			);

			$tag        = 'div';
			$extra_attr = '';

			if ( 'lightbox' === $click ) {
				$tag = 'button';
				$extra_attr = ' type="button" aria-label="' . esc_attr__( 'Open image in lightbox', 'novixa-addons-for-elementor' ) . '"'
					. ' data-novixa-click-action="lightbox"'
					. ' data-novixa-full="' . esc_url( $full_src ) . '"'
					. ' data-novixa-title="' . esc_attr( $title ) . '"'
					. ' data-novixa-caption="' . esc_attr( $caption ) . '"';
			} elseif ( 'link' === $click && ! empty( $item['novixa_gallery_link']['url'] ) ) {
				$tag         = 'a';
				$extra_attr  = ' href="' . esc_url( $item['novixa_gallery_link']['url'] ) . '"';
				$extra_attr .= ! empty( $item['novixa_gallery_link']['is_external'] ) ? ' target="_blank"' : '';
				$extra_attr .= ! empty( $item['novixa_gallery_link']['nofollow'] ) ? ' rel="nofollow"' : '';
			}

			printf(
				'<%1$s class="%2$s"%3$s>',
				esc_attr( $tag ),
				esc_attr( $this->bem( 'gallery', 'thumb' ) ),
				$extra_attr // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built entirely from esc_*() calls above.
			);

			if ( '' !== $grid_src ) {
				printf(
					'<img class="%1$s" src="%2$s" alt="%3$s" loading="lazy" />',
					esc_attr( $this->bem( 'gallery', 'image' ) ),
					esc_url( $grid_src ),
					esc_attr( '' !== $title ? $title : $caption )
				);
			}

			if ( 'yes' === $settings['novixa_gallery_show_overlay'] ) {
				echo '<div class="' . esc_attr( $this->bem( 'gallery', 'overlay' ) ) . '">';

				if ( 'yes' === $settings['novixa_gallery_show_icon'] ) {
					echo '<span class="' . esc_attr( $this->bem( 'gallery', 'icon' ) ) . '">';
					echo '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line><line x1="11" y1="8" x2="11" y2="14"></line><line x1="8" y1="11" x2="14" y2="11"></line></svg>';
					echo '</span>';
				}

				if ( 'overlay' === $settings['novixa_gallery_caption_position'] && ( '' !== $title || '' !== $caption ) ) {
					echo '<div class="' . esc_attr( $this->bem( 'gallery', 'overlay-text' ) ) . '">';
					if ( '' !== $title ) {
						echo '<div class="' . esc_attr( $this->bem( 'gallery', 'overlay-title' ) ) . '">' . esc_html( $title ) . '</div>';
					}
					if ( '' !== $caption ) {
						echo '<div class="' . esc_attr( $this->bem( 'gallery', 'overlay-caption' ) ) . '">' . esc_html( $caption ) . '</div>';
					}
					echo '</div>';
				}

				echo '</div>';
			}

			echo '</' . esc_attr( $tag ) . '>';

			if ( 'below' === $settings['novixa_gallery_caption_position'] && ( '' !== $title || '' !== $caption ) ) {
				echo '<div class="' . esc_attr( $this->bem( 'gallery', 'caption-below' ) ) . '">';
				if ( '' !== $title ) {
					echo '<div class="' . esc_attr( $this->bem( 'gallery', 'caption-title' ) ) . '">' . esc_html( $title ) . '</div>';
				}
				if ( '' !== $caption ) {
					echo '<div class="' . esc_attr( $this->bem( 'gallery', 'caption-text' ) ) . '">' . esc_html( $caption ) . '</div>';
				}
				echo '</div>';
			}

			echo '</div>'; // .item
		}

		/**
		 * Front-end render.
		 */
		protected function render() {
			$settings = $this->get_settings_for_display();

			if ( empty( $settings['novixa_gallery_items'] ) ) {
				return;
			}

			// Items with "Hide This Image" switched on are skipped
			// completely - not just visually hidden - so they don't
			// contribute to the category filter bar, the grid, or the
			// lightbox's prev/next order and counter.
			$visible_items = array_filter(
				$settings['novixa_gallery_items'],
				function ( $item ) {
					return empty( $item['novixa_gallery_hide'] ) || 'yes' !== $item['novixa_gallery_hide'];
				}
			);

			if ( empty( $visible_items ) ) {
				return;
			}

			// Collect the union of categories across every item, in
			// first-seen order, so the filter bar lists them the same
			// way the user entered them.
			$all_categories = array();
			foreach ( $visible_items as $item ) {
				$all_categories += $this->parse_categories( $item['novixa_gallery_category'] );
			}

			$show_filter = 'yes' === $settings['novixa_gallery_show_filter'] && ! empty( $all_categories );

			$wrapper_classes = array_merge(
				array( $this->bem( 'gallery' ) ),
				$this->get_visibility_classes( $settings )
			);

			$this->add_render_attribute( 'novixa_gallery_wrapper', 'class', $wrapper_classes );
			$this->add_render_attribute( 'novixa_gallery_wrapper', 'data-novixa-click-action', $settings['novixa_gallery_click_action'] );
			$this->add_render_attribute( 'novixa_gallery_wrapper', 'data-novixa-show-caption', ( 'yes' === $settings['novixa_gallery_lightbox_show_caption'] ) ? '1' : '0' );
			$this->add_render_attribute( 'novixa_gallery_wrapper', 'data-novixa-show-counter', ( 'yes' === $settings['novixa_gallery_lightbox_show_counter'] ) ? '1' : '0' );
			$this->add_render_attribute( 'novixa_gallery_wrapper', 'data-novixa-show-arrows', ( 'yes' === $settings['novixa_gallery_lightbox_show_arrows'] ) ? '1' : '0' );

			printf( '<div %1$s>', $this->get_render_attribute_string( 'novixa_gallery_wrapper' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

			if ( $show_filter ) {
				$this->render_filter_bar( $settings, $all_categories );
			}

			$grid_classes = array(
				$this->bem( 'gallery', 'grid' ),
				$this->bem( 'gallery', 'grid', 'masonry' === $settings['novixa_gallery_layout'] ? 'masonry' : 'grid' ),
			);
			if ( 'zoom' === $settings['novixa_gallery_hover_effect'] ) {
				$grid_classes[] = $this->bem( 'gallery', 'grid' ) . '--zoom';
			}

			printf( '<div class="%1$s">', esc_attr( implode( ' ', $grid_classes ) ) );

			foreach ( $visible_items as $item ) {
				$this->render_item( $item, $settings );
			}

			echo '</div>'; // .grid
			echo '</div>'; // .gallery
		}
	}
}
