<?php
/**
 * Liquid Counter widget.
 *
 * A circular stat badge with an animated "liquid fill" wave at the
 * bottom (two slowly counter-rotating blobs clipped to a circle — the
 * classic CSS liquid-fill trick, no SVG/JS wave math needed) and a
 * count-up number in the middle, inspired by the reference design at
 * https://tmieliquidmotion.netlify.app/ (their "DFW Medicare Market"
 * stats row).
 *
 * @package Novixa_Addons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! class_exists( 'Novixa_Addons_Widget_Liquid_Counter' ) ) {

	/**
	 * Class Novixa_Addons_Widget_Liquid_Counter
	 */
	class Novixa_Addons_Widget_Liquid_Counter extends Novixa_Addons_Widget_Base {

		use Novixa_Addons_Global_Controls;

		/**
		 * Unique widget name registered with Elementor.
		 *
		 * @return string
		 */
		public function get_name() {
			return 'novixa-addons-liquid-counter';
		}

		/**
		 * Panel label.
		 *
		 * @return string
		 */
		public function get_title() {
			return __( 'Liquid Counter - Novixa', 'novixa-addons-for-elementor' );
		}

		/**
		 * Panel icon.
		 *
		 * @return string
		 */
		public function get_icon() {
			return 'eicon-number-field';
		}

		/**
		 * Panel search keywords.
		 *
		 * @return array
		 */
		public function get_keywords() {
			return array_merge( $this->get_base_keywords(), array( 'counter', 'liquid', 'wave', 'circle', 'stats', 'gauge' ) );
		}

		/**
		 * Script dependency — the count-up + wave-rise animation lives
		 * in assets/js/frontend.js (see the "Liquid Counter" section
		 * there).
		 *
		 * @return array
		 */
		public function get_script_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Style dependency.
		 *
		 * @return array
		 */
		public function get_style_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Register all controls.
		 */
		protected function register_controls() {
			$this->register_content_controls();
			$this->register_circle_style_controls();
			$this->register_liquid_style_controls();
			$this->register_number_style_controls();
			$this->register_description_style_controls();
		}

		/**
		 * Content tab.
		 */
		protected function register_content_controls() {
			$this->start_controls_section(
				'novixa_section_liquid_counter_content',
				array(
					'label' => __( 'Liquid Counter', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_starting_number',
				array(
					'label'   => __( 'Starting Number', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::NUMBER,
					'default' => 0,
				)
			);

			$this->add_control(
				'novixa_ending_number',
				array(
					'label'   => __( 'Ending Number', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::NUMBER,
					'default' => 58,
				)
			);

			$this->add_control(
				'novixa_decimal_places',
				array(
					'label'   => __( 'Decimal Places', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::NUMBER,
					'min'     => 0,
					'max'     => 4,
					'default' => 0,
				)
			);

			$this->add_control(
				'novixa_thousands_separator',
				array(
					'label'        => __( 'Thousands Separator', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'yes',
				)
			);

			$this->add_control(
				'novixa_prefix',
				array(
					'label'       => __( 'Prefix', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => '',
					'placeholder' => '$',
					'label_block' => false,
				)
			);

			$this->add_control(
				'novixa_suffix',
				array(
					'label'       => __( 'Suffix', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => '',
					'placeholder' => '+',
					'label_block' => false,
				)
			);

			$this->add_control(
				'novixa_description',
				array(
					'label'       => __( 'Description', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXTAREA,
					'default'     => __( 'Medicare Advantage Plans in Dallas County', 'novixa-addons-for-elementor' ),
					'label_block' => true,
					'rows'        => 3,
				)
			);

			$this->add_control(
				'novixa_duration',
				array(
					'label'   => __( 'Animation Duration (ms)', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::SLIDER,
					'range'   => array(
						'px' => array(
							'min'  => 200,
							'max'  => 6000,
							'step' => 100,
						),
					),
					'default' => array(
						'unit' => 'px',
						'size' => 2000,
					),
				)
			);

			$this->add_control(
				'novixa_liquid_fill_level',
				array(
					'label'       => __( 'Liquid Fill Level (%)', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::SLIDER,
					'range'       => array(
						'px' => array(
							'min' => 0,
							'max' => 100,
						),
					),
					'default'     => array(
						'unit' => 'px',
						'size' => 35,
					),
					'description' => __( 'How full the circle looks — independent of the number itself, so a "$106" and an "18" can both sit at the same liquid level.', 'novixa-addons-for-elementor' ),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Circle styling.
		 */
		protected function register_circle_style_controls() {
			$this->start_controls_section(
				'novixa_section_circle_style',
				array(
					'label' => __( 'Circle', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_responsive_control(
				'novixa_circle_size',
				array(
					'label'     => __( 'Size', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 60,
							'max' => 300,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 140,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'liquid-counter', 'circle' ) => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_control(
				'novixa_circle_bg_color',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#faf7f0',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'liquid-counter', 'circle' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_circle_border_color',
				array(
					'label'     => __( 'Border Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#e8d4a0',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'liquid-counter', 'circle' ) => 'border-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_circle_border_width',
				array(
					'label'     => __( 'Border Width', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array( 'max' => 12 ),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 2,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'liquid-counter', 'circle' ) => 'border-width: {{SIZE}}{{UNIT}}; border-style: solid;',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Liquid styling.
		 */
		protected function register_liquid_style_controls() {
			$this->start_controls_section(
				'novixa_section_liquid_style',
				array(
					'label' => __( 'Liquid', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_control(
				'novixa_liquid_color',
				array(
					'label'     => __( 'Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#d9b877',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'liquid-counter', 'wave' ) . '--1' => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_liquid_color_secondary',
				array(
					'label'     => __( 'Secondary Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#c9a15f',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'liquid-counter', 'wave' ) . '--2' => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_liquid_speed',
				array(
					'label'       => __( 'Motion Speed (seconds per rotation)', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::SLIDER,
					'range'       => array(
						'px' => array(
							'min' => 2,
							'max' => 20,
						),
					),
					'default'     => array(
						'unit' => 'px',
						'size' => 7,
					),
					'selectors'   => array(
						'{{WRAPPER}} .' . $this->bem( 'liquid-counter', 'wave' ) . '--1' => 'animation-duration: {{SIZE}}s;',
					),
					'description' => __( 'Lower is faster / more energetic, higher is calmer.', 'novixa-addons-for-elementor' ),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Number styling.
		 */
		protected function register_number_style_controls() {
			$this->start_controls_section(
				'novixa_section_number_style',
				array(
					'label' => __( 'Number', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_control(
				'novixa_number_color',
				array(
					'label'     => __( 'Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#1a1a2e',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'liquid-counter', 'number' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'     => 'novixa_number_typography',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'liquid-counter', 'number' ),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Description styling.
		 */
		protected function register_description_style_controls() {
			$this->start_controls_section(
				'novixa_section_description_style',
				array(
					'label' => __( 'Description', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_control(
				'novixa_description_color',
				array(
					'label'     => __( 'Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#6a6a7a',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'liquid-counter', 'description' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'     => 'novixa_description_typography',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'liquid-counter', 'description' ),
				)
			);

			$this->add_responsive_control(
				'novixa_description_spacing',
				array(
					'label'     => __( 'Spacing (above description)', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array( 'max' => 60 ),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 18,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'liquid-counter' ) => 'gap: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Front-end render.
		 */
		protected function render() {
			$settings = $this->get_settings_for_display();

			$duration    = ! empty( $settings['novixa_duration']['size'] ) ? (int) $settings['novixa_duration']['size'] : 2000;
			$fill_level  = isset( $settings['novixa_liquid_fill_level']['size'] ) ? (float) $settings['novixa_liquid_fill_level']['size'] : 35;

			$this->add_render_attribute( 'novixa_circle', 'class', $this->bem( 'liquid-counter', 'circle' ) );
			$this->add_render_attribute( 'novixa_circle', 'data-novixa-liquid-fill', $fill_level );

			$this->add_render_attribute( 'novixa_number', 'class', $this->bem( 'liquid-counter', 'number' ) );
			$this->add_render_attribute( 'novixa_number', 'data-novixa-counter-start', (float) $settings['novixa_starting_number'] );
			$this->add_render_attribute( 'novixa_number', 'data-novixa-counter-end', (float) $settings['novixa_ending_number'] );
			$this->add_render_attribute( 'novixa_number', 'data-novixa-counter-decimals', (int) $settings['novixa_decimal_places'] );
			$this->add_render_attribute( 'novixa_number', 'data-novixa-counter-duration', $duration );
			$this->add_render_attribute( 'novixa_number', 'data-novixa-counter-separator', 'yes' === $settings['novixa_thousands_separator'] ? '1' : '0' );

			echo '<div class="' . esc_attr( $this->bem( 'liquid-counter' ) ) . '">';

			printf( '<div %1$s>', $this->get_render_attribute_string( 'novixa_circle' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

			echo '<div class="' . esc_attr( $this->bem( 'liquid-counter', 'wave-wrap' ) ) . '">';
			echo '<div class="' . esc_attr( $this->bem( 'liquid-counter', 'wave' ) . ' ' . $this->bem( 'liquid-counter', 'wave' ) . '--1' ) . '"></div>';
			echo '<div class="' . esc_attr( $this->bem( 'liquid-counter', 'wave' ) . ' ' . $this->bem( 'liquid-counter', 'wave' ) . '--2' ) . '"></div>';
			echo '</div>';

			echo '<span class="' . esc_attr( $this->bem( 'liquid-counter', 'number-wrap' ) ) . '">';

			if ( '' !== $settings['novixa_prefix'] ) {
				echo '<span class="' . esc_attr( $this->bem( 'liquid-counter', 'prefix' ) ) . '">' . esc_html( $settings['novixa_prefix'] ) . '</span>';
			}

			printf(
				'<span %1$s>%2$s</span>',
				$this->get_render_attribute_string( 'novixa_number' ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				esc_html( $settings['novixa_starting_number'] )
			);

			if ( '' !== $settings['novixa_suffix'] ) {
				echo '<span class="' . esc_attr( $this->bem( 'liquid-counter', 'suffix' ) ) . '">' . esc_html( $settings['novixa_suffix'] ) . '</span>';
			}

			echo '</span>';

			echo '</div>'; // .novixa-addons-liquid-counter__circle

			if ( ! empty( $settings['novixa_description'] ) ) {
				printf(
					'<div class="%1$s">%2$s</div>',
					esc_attr( $this->bem( 'liquid-counter', 'description' ) ),
					esc_html( $settings['novixa_description'] )
				);
			}

			echo '</div>';
		}
	}
}
