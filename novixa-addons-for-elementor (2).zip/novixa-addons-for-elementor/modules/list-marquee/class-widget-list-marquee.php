<?php
/**
 * List Marquee widget.
 *
 * An infinitely-scrolling horizontal ticker of short list items
 * (each with an optional icon), separated by a bullet — the classic
 * "seamless CSS marquee" trick: the item list is rendered twice back
 * to back inside a wider flex track, which then animates
 * `translateX(0 -> -50%)` on a linear infinite loop, so the moment the
 * first copy has scrolled fully out of view the second copy is sitting
 * exactly where the first one started.
 *
 * @package Novixa_Addons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;

if ( ! class_exists( 'Novixa_Addons_Widget_List_Marquee' ) ) {

	/**
	 * Class Novixa_Addons_Widget_List_Marquee
	 */
	class Novixa_Addons_Widget_List_Marquee extends Novixa_Addons_Widget_Base {

		use Novixa_Addons_Global_Controls;

		/**
		 * Unique widget name registered with Elementor.
		 *
		 * @return string
		 */
		public function get_name() {
			return 'novixa-addons-list-marquee';
		}

		/**
		 * Panel label.
		 *
		 * @return string
		 */
		public function get_title() {
			return __( 'List Marquee - Novixa', 'novixa-addons-for-elementor' );
		}

		/**
		 * Panel icon.
		 *
		 * @return string
		 */
		public function get_icon() {
			return 'eicon-post-list';
		}

		/**
		 * Panel search keywords.
		 *
		 * @return array
		 */
		public function get_keywords() {
			return array_merge( $this->get_base_keywords(), array( 'marquee', 'ticker', 'scrolling', 'list', 'carousel', 'announcement' ) );
		}

		/**
		 * Script dependency — the animation itself is pure CSS; the
		 * shared frontend.js is only needed for the reduced-motion /
		 * editor-safety plumbing every other widget already loads.
		 *
		 * @return array
		 */
		public function get_script_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Style dependency.
		 *
		 * @return array
		 */
		public function get_style_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Register all controls.
		 */
		protected function register_controls() {
			$this->register_content_controls();
			$this->register_box_style_controls();
			$this->register_item_style_controls();
			$this->register_icon_style_controls();
			$this->register_separator_style_controls();
		}

		/**
		 * Content tab.
		 */
		protected function register_content_controls() {
			$this->start_controls_section(
				'novixa_section_marquee_content',
				array(
					'label' => __( 'List Marquee', 'novixa-addons-for-elementor' ),
				)
			);

			$repeater = new Repeater();

			$repeater->add_control(
				'novixa_item_icon',
				array(
					'label'       => __( 'Icon', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::ICONS,
					'default'     => array(
						'value'   => 'fas fa-star',
						'library' => 'fa-solid',
					),
					'skin'        => 'inline',
					'label_block' => false,
				)
			);

			$repeater->add_control(
				'novixa_item_text',
				array(
					'label'       => __( 'Text', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( 'List item', 'novixa-addons-for-elementor' ),
					'label_block' => true,
				)
			);

			$repeater->add_control(
				'novixa_item_link',
				array(
					'label'       => __( 'Link', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::URL,
					'default'     => array(
						'url' => '',
					),
					'label_block' => true,
				)
			);

			$this->add_control(
				'novixa_items',
				array(
					'label'       => __( 'Items', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::REPEATER,
					'fields'      => $repeater->get_controls(),
					'default'     => array(
						array( 'novixa_item_text' => __( 'Deluxe Suite • Ocean View $299/night', 'novixa-addons-for-elementor' ) ),
						array( 'novixa_item_text' => __( 'Executive Room • City View $199/night', 'novixa-addons-for-elementor' ) ),
						array( 'novixa_item_text' => __( 'Presidential Suite • Mountain View $399/night', 'novixa-addons-for-elementor' ) ),
						array( 'novixa_item_text' => __( 'Superior Room • Partial Ocean View $279/night', 'novixa-addons-for-elementor' ) ),
					),
					'title_field' => '{{{ novixa_item_text }}}',
				)
			);

			$this->add_control(
				'novixa_show_icon',
				array(
					'label'        => __( 'Show Icon', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'yes',
					'description'  => __( 'Each item has its own Icon field above in the Items list, so different items can use different icons.', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_separator',
				array(
					'label'       => __( 'Separator', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => '•',
					'label_block' => false,
				)
			);

			$this->add_control(
				'novixa_speed',
				array(
					'label'       => __( 'Speed (seconds per loop)', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::SLIDER,
					'range'       => array(
						'px' => array(
							'min' => 5,
							'max' => 120,
						),
					),
					'default'     => array(
						'unit' => 'px',
						'size' => 25,
					),
					'description' => __( 'Lower is faster, higher is slower.', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_direction',
				array(
					'label'   => __( 'Direction', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::CHOOSE,
					'default' => 'left',
					'options' => array(
						'left'  => array(
							'title' => __( 'Right to Left', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-arrow-left',
						),
						'right' => array(
							'title' => __( 'Left to Right', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-arrow-right',
						),
					),
				)
			);

			$this->add_control(
				'novixa_pause_on_hover',
				array(
					'label'        => __( 'Pause on Hover', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'yes',
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Box styling.
		 */
		protected function register_box_style_controls() {
			$this->start_controls_section(
				'novixa_section_box_style',
				array(
					'label' => __( 'Box', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_control(
				'novixa_box_bg_color',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#4640de',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'list-marquee' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_box_padding',
				array(
					'label'      => __( 'Padding', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', 'em', '%' ),
					'default'    => array(
						'top'      => 18,
						'right'    => 0,
						'bottom'   => 18,
						'left'     => 0,
						'unit'     => 'px',
						'isLinked' => false,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'list-marquee' ) => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_control(
				'novixa_box_border_radius',
				array(
					'label'      => __( 'Border Radius', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', '%' ),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'list-marquee' ) => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Item (text) styling.
		 */
		protected function register_item_style_controls() {
			$this->start_controls_section(
				'novixa_section_item_style',
				array(
					'label' => __( 'Item Text', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_control(
				'novixa_item_color',
				array(
					'label'     => __( 'Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#ffffff',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'list-marquee', 'item' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'     => 'novixa_item_typography',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'list-marquee', 'item' ),
				)
			);

			$this->add_responsive_control(
				'novixa_item_gap',
				array(
					'label'     => __( 'Gap Between Items', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array( 'max' => 80 ),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 28,
					),
					// Also sets `padding-right` (equal to the gap) on
					// the same element on purpose — the widget renders
					// two identical copies of the item list back to
					// back for a seamless marquee loop (translateX to
					// -50%), which only stays seamless if both copies
					// end up exactly the same total width, trailing
					// space included.
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'list-marquee', 'group' ) => 'gap: {{SIZE}}{{UNIT}}; padding-right: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Icon styling.
		 */
		protected function register_icon_style_controls() {
			$this->start_controls_section(
				'novixa_section_marquee_icon_style',
				array(
					'label'     => __( 'Icon', 'novixa-addons-for-elementor' ),
					'tab'       => Controls_Manager::TAB_STYLE,
					'condition' => array(
						'novixa_show_icon' => 'yes',
					),
				)
			);

			$this->add_control(
				'novixa_marquee_icon_color',
				array(
					'label'     => __( 'Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#d9b877',
					// Target the wrapper AND the actual icon element
					// directly (both the `i` a Font Awesome icon
					// renders as, and the `svg`/`path` an SVG-library
					// icon renders as) — relying on `color` inheriting
					// down from the wrapper alone doesn't repaint an
					// SVG icon's fill, so on-canvas the icon looked
					// unaffected even though the control was saving
					// correctly.
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'list-marquee', 'icon' )          => 'color: {{VALUE}};',
						'{{WRAPPER}} .' . $this->bem( 'list-marquee', 'icon' ) . ' svg'  => 'fill: {{VALUE}};',
						'{{WRAPPER}} .' . $this->bem( 'list-marquee', 'icon' ) . ' path' => 'fill: {{VALUE}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_marquee_icon_size',
				array(
					'label'     => __( 'Size', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 8,
							'max' => 40,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 14,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'list-marquee', 'icon' ) . ' i'   => 'font-size: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .' . $this->bem( 'list-marquee', 'icon' ) . ' svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Separator styling.
		 */
		protected function register_separator_style_controls() {
			$this->start_controls_section(
				'novixa_section_separator_style',
				array(
					'label' => __( 'Separator', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_control(
				'novixa_separator_color',
				array(
					'label'     => __( 'Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => 'rgba(255, 255, 255, 0.6)',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'list-marquee', 'separator' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Render one item + optional icon.
		 *
		 * @param array  $settings Widget settings.
		 * @param array  $item     Repeater row.
		 * @param bool   $aria_hidden Whether this copy should be hidden from assistive tech (the duplicate track).
		 */
		private function render_group( $settings, $aria_hidden = false ) {
			printf(
				'<div class="%1$s"%2$s>',
				esc_attr( $this->bem( 'list-marquee', 'group' ) ),
				$aria_hidden ? ' aria-hidden="true"' : ''
			);

			foreach ( $settings['novixa_items'] as $index => $item ) {
				if ( $index > 0 ) {
					echo '<span class="' . esc_attr( $this->bem( 'list-marquee', 'separator' ) ) . '">' . esc_html( $settings['novixa_separator'] ) . '</span>';
				}

				$has_link = ! empty( $item['novixa_item_link']['url'] );
				$tag      = $has_link ? 'a' : 'span';

				echo '<' . esc_attr( $tag ) . ' class="' . esc_attr( $this->bem( 'list-marquee', 'item' ) ) . '"';

				if ( $has_link ) {
					echo ' href="' . esc_url( $item['novixa_item_link']['url'] ) . '"';
					if ( ! empty( $item['novixa_item_link']['is_external'] ) ) {
						echo ' target="_blank"';
					}
					if ( ! empty( $item['novixa_item_link']['nofollow'] ) ) {
						echo ' rel="nofollow"';
					}
				}

				echo '>';

				if ( 'yes' === $settings['novixa_show_icon'] && ! empty( $item['novixa_item_icon']['value'] ) ) {
					echo '<span class="' . esc_attr( $this->bem( 'list-marquee', 'icon' ) ) . '">';
					Icons_Manager::render_icon( $item['novixa_item_icon'], array( 'aria-hidden' => 'true' ) );
					echo '</span>';
				}

				echo '<span>' . esc_html( $item['novixa_item_text'] ) . '</span>';

				echo '</' . esc_attr( $tag ) . '>';
			}

			echo '</div>';
		}

		/**
		 * Front-end render.
		 */
		protected function render() {
			$settings = $this->get_settings_for_display();

			if ( empty( $settings['novixa_items'] ) ) {
				return;
			}

			$speed = ! empty( $settings['novixa_speed']['size'] ) ? (float) $settings['novixa_speed']['size'] : 25;

			$wrapper_classes = array( $this->bem( 'list-marquee' ) );
			if ( 'yes' === $settings['novixa_pause_on_hover'] ) {
				$wrapper_classes[] = $this->bem( 'list-marquee' ) . '--pause-on-hover';
			}
			if ( 'right' === $settings['novixa_direction'] ) {
				$wrapper_classes[] = $this->bem( 'list-marquee' ) . '--reverse';
			}

			printf(
				'<div class="%1$s" style="--novixa-marquee-duration: %2$ss;">',
				esc_attr( implode( ' ', $wrapper_classes ) ),
				esc_attr( $speed )
			);

			echo '<div class="' . esc_attr( $this->bem( 'list-marquee', 'track' ) ) . '">';

			// Rendered twice back-to-back for the seamless-loop trick —
			// see the file-level comment at the top of this class.
			// The second copy is aria-hidden so screen readers only
			// announce the list once.
			$this->render_group( $settings, false );
			$this->render_group( $settings, true );

			echo '</div>';

			echo '</div>';
		}
	}
}
