<?php
/**
 * Overlay Button widget — a button with a small color "chip" pinned to
 * one corner that expands to fill the whole button on hover, while the
 * text color transitions at the same time.
 *
 * @package Novixa_Addons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if ( ! class_exists( 'Novixa_Addons_Widget_Overlay_Button' ) ) {

	/**
	 * Class Novixa_Addons_Widget_Overlay_Button
	 */
	class Novixa_Addons_Widget_Overlay_Button extends Novixa_Addons_Widget_Base {

		/**
		 * Unique widget name registered with Elementor.
		 *
		 * @return string
		 */
		public function get_name() {
			return 'novixa-addons-overlay-button';
		}

		/**
		 * Panel label.
		 *
		 * @return string
		 */
		public function get_title() {
			return __( 'Overlay Button - Novixa', 'novixa-addons-for-elementor' );
		}

		/**
		 * Panel icon.
		 *
		 * @return string
		 */
		public function get_icon() {
			return 'eicon-button';
		}

		/**
		 * Panel search keywords.
		 *
		 * @return array
		 */
		public function get_keywords() {
			return array_merge( $this->get_base_keywords(), array( 'button', 'overlay', 'hover', 'cta', 'fill' ) );
		}

		/**
		 * Style dependency — without this, Elementor doesn't print
		 * 'novixa-addons-frontend' on the isolated AJAX request it uses
		 * to render a widget the moment it's dragged onto the editor
		 * canvas, so the effect would silently fall back to an
		 * unstyled link/button there even though a full page load is
		 * fine.
		 *
		 * @return array
		 */
		/**
		 * Script dependency — 'novixa-addons-frontend' also holds the
		 * shared front-end interaction JS (see assets/js/frontend.js).
		 * Without declaring it here, Elementor won't reliably print it
		 * on the isolated AJAX request used to (re)render this widget
		 * while editing, which can leave this widget's interactive
		 * behaviour silently broken in the editor canvas.
		 *
		 * @return array
		 */
		public function get_script_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Style dependency.
		 *
		 * @return array
		 */
		public function get_style_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Register all controls.
		 */
		protected function register_controls() {
			$this->register_content_controls();
			$this->register_button_style_controls();
			$this->register_overlay_style_controls();
		}

		/**
		 * Content tab.
		 */
		protected function register_content_controls() {
			$this->start_controls_section(
				'novixa_section_overlay_button_content',
				array(
					'label' => __( 'Overlay Button', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_text',
				array(
					'label'       => __( 'Text', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( 'See More', 'novixa-addons-for-elementor' ),
					'label_block' => false,
				)
			);

			$this->add_control(
				'novixa_link',
				array(
					'label'         => __( 'Link', 'novixa-addons-for-elementor' ),
					'type'          => Controls_Manager::URL,
					'placeholder'   => __( 'https://your-link.com', 'novixa-addons-for-elementor' ),
					'show_external' => true,
					'default'       => array(
						'url' => '',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_alignment',
				array(
					'label'     => __( 'Alignment', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::CHOOSE,
					'separator' => 'before',
					'options'   => array(
						'left'   => array(
							'title' => __( 'Left', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-left',
						),
						'center' => array(
							'title' => __( 'Center', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-center',
						),
						'right'  => array(
							'title' => __( 'Right', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-right',
						),
					),
					'default'   => 'left',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'overlay-btn', 'wrap' ) => 'text-align: {{VALUE}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > the button itself (its resting look).
		 */
		protected function register_button_style_controls() {
			$this->start_controls_section(
				'novixa_section_overlay_button_style',
				array(
					'label' => __( 'Button', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'     => 'novixa_typography',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'overlay-btn' ),
				)
			);

			$this->add_responsive_control(
				'novixa_padding',
				array(
					'label'      => __( 'Padding', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', 'em', '%' ),
					'default'    => array(
						'top'      => 18,
						'right'    => 34,
						'bottom'   => 18,
						'left'     => 34,
						'unit'     => 'px',
						'isLinked' => false,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'overlay-btn' ) => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_border_radius',
				array(
					'label'      => __( 'Border Radius', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', '%' ),
					'default'    => array(
						'top'      => 0,
						'right'    => 0,
						'bottom'   => 0,
						'left'     => 0,
						'unit'     => 'px',
						'isLinked' => true,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'overlay-btn' ) => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_control(
				'novixa_bg_color',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#ffffff',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'overlay-btn' ) => '--novixa-bg: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_text_color',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#4f3ff0',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'overlay-btn' ) => '--novixa-text: {{VALUE}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Border::get_type(),
				array(
					'name'     => 'novixa_border',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'overlay-btn' ),
				)
			);

			$this->add_group_control(
				Group_Control_Box_Shadow::get_type(),
				array(
					'name'     => 'novixa_box_shadow',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'overlay-btn' ),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > the hover overlay effect — modeled directly on
		 * Unlimited Elements' Overlay Button widget: explicit
		 * Width/Height for the overlay's resting size, Width/Height
		 * Hover for its expanded size, and Position X/Y for where it
		 * sits (offset from the top-right corner).
		 */
		protected function register_overlay_style_controls() {
			$this->start_controls_section(
				'novixa_section_overlay_style',
				array(
					'label' => __( 'Overlay', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_control(
				'novixa_overlay_color',
				array(
					'label'     => __( 'Overlay Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#4f3ff0',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'overlay-btn' ) => '--novixa-overlay: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_hover_text_color',
				array(
					'label'     => __( 'Text Color Hover', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#ffffff',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'overlay-btn' ) => '--novixa-hover-text: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_overlay_size_heading',
				array(
					'label'     => __( 'Overlay Size (Normal)', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::HEADING,
					'separator' => 'before',
				)
			);

			$this->add_responsive_control(
				'novixa_overlay_width',
				array(
					'label'      => __( 'Overlay Width', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => array( 'px', '%' ),
					'range'      => array(
						'px' => array(
							'min' => 4,
							'max' => 400,
						),
						'%'  => array(
							'min' => 1,
							'max' => 100,
						),
					),
					'default'    => array(
						'unit' => 'px',
						'size' => 20,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'overlay-btn' ) => '--novixa-overlay-w: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_overlay_height',
				array(
					'label'      => __( 'Overlay Height', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => array( 'px', '%' ),
					'range'      => array(
						'px' => array(
							'min' => 4,
							'max' => 400,
						),
						'%'  => array(
							'min' => 1,
							'max' => 100,
						),
					),
					'default'    => array(
						'unit' => 'px',
						'size' => 20,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'overlay-btn' ) => '--novixa-overlay-h: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_control(
				'novixa_overlay_size_hover_heading',
				array(
					'label'     => __( 'Overlay Size (Hover)', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::HEADING,
					'separator' => 'before',
				)
			);

			$this->add_responsive_control(
				'novixa_overlay_width_hover',
				array(
					'label'      => __( 'Overlay Width Hover', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => array( 'px', '%' ),
					'range'      => array(
						'px' => array(
							'min' => 4,
							'max' => 800,
						),
						'%'  => array(
							'min' => 1,
							'max' => 300,
						),
					),
					'default'    => array(
						'unit' => '%',
						'size' => 100,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'overlay-btn' ) => '--novixa-overlay-w-hover: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_overlay_height_hover',
				array(
					'label'      => __( 'Overlay Height Hover', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => array( 'px', '%' ),
					'range'      => array(
						'px' => array(
							'min' => 4,
							'max' => 800,
						),
						'%'  => array(
							'min' => 1,
							'max' => 300,
						),
					),
					'default'    => array(
						'unit' => '%',
						'size' => 100,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'overlay-btn' ) => '--novixa-overlay-h-hover: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_control(
				'novixa_overlay_position_heading',
				array(
					'label'     => __( 'Overlay Position', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::HEADING,
					'separator' => 'before',
					'description' => __( 'Offset from the top-right corner of the button.', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_responsive_control(
				'novixa_overlay_position_x',
				array(
					'label'     => __( 'Position X', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => -50,
							'max' => 100,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 6,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'overlay-btn' ) => '--novixa-overlay-x: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_overlay_position_y',
				array(
					'label'     => __( 'Position Y', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => -50,
							'max' => 100,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 6,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'overlay-btn' ) => '--novixa-overlay-y: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_control(
				'novixa_transition_speed',
				array(
					'label'     => __( 'Fill Speed (ms)', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'separator' => 'before',
					'range'     => array(
						'px' => array(
							'min'  => 100,
							'max'  => 1200,
							'step' => 50,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 400,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'overlay-btn' ) => '--novixa-speed: {{SIZE}}ms;',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Strip anything that isn't a plausible CSS color character.
		 * Defensive only — needed because these values are written
		 * straight into the inline stylesheet rule in render() without
		 * further HTML-escaping.
		 *
		 * @param string $color Raw color value.
		 * @return string
		 */
		private function safe_color( $color ) {
			return preg_replace( '/[^a-zA-Z0-9#(),.%\s\-]/', '', (string) $color );
		}

		/**
		 * Front-end render.
		 *
		 * Markup: an outer <a>/<button> (the visible resting button,
		 * given a unique id) containing one small absolutely-positioned
		 * "chip" span. Every color/size/hover rule for THIS instance is
		 * printed as one small scoped <style id="..."> block keyed to
		 * that unique id, instead of relying on Elementor's WRAPPER
		 * class + prefix_class mechanism (which targets the *outer*
		 * Elementor wrapper element, not this element, and is easy to
		 * get subtly wrong) or on the external frontend.css file having
		 * definitely been re-enqueued/re-cached after an update. A
		 * `:hover` rule on the button's own id always fires the instant
		 * the mouse is over it — no ancestor bubbling, no dependency on
		 * which stylesheet loaded last.
		 */
		protected function render() {
			$settings = $this->get_settings_for_display();

			$has_link = ! empty( $settings['novixa_link']['url'] );
			$tag      = $has_link ? 'a' : 'button';

			$uid = 'novixa-overlay-btn-' . esc_attr( $this->get_id() );

			$this->add_render_attribute( 'novixa_btn', 'id', $uid );
			$this->add_render_attribute( 'novixa_btn', 'class', $this->bem( 'overlay-btn' ) );

			if ( $has_link ) {
				$this->add_link_attributes( 'novixa_btn', $settings['novixa_link'] );
			}

			// PHP-side fallbacks only — the *actual* live values come from
			// the --novixa-* custom properties written by the style
			// controls' `selectors` above, so the editor preview updates
			// instantly with no AJAX re-render.
			$bg          = ! empty( $settings['novixa_bg_color'] ) ? $this->safe_color( $settings['novixa_bg_color'] ) : '#ffffff';
			$text        = ! empty( $settings['novixa_text_color'] ) ? $this->safe_color( $settings['novixa_text_color'] ) : '#4f3ff0';
			$overlay     = ! empty( $settings['novixa_overlay_color'] ) ? $this->safe_color( $settings['novixa_overlay_color'] ) : '#4f3ff0';
			$hover_text  = ! empty( $settings['novixa_hover_text_color'] ) ? $this->safe_color( $settings['novixa_hover_text_color'] ) : '#ffffff';

			$bg_var          = 'var(--novixa-bg, ' . $bg . ')';
			$text_var        = 'var(--novixa-text, ' . $text . ')';
			$overlay_var     = 'var(--novixa-overlay, ' . $overlay . ')';
			$hover_text_var  = 'var(--novixa-hover-text, ' . $hover_text . ')';
			$speed_var       = 'var(--novixa-speed, 400ms)';
			$overlay_w_var   = 'var(--novixa-overlay-w, 20px)';
			$overlay_h_var   = 'var(--novixa-overlay-h, 20px)';
			$overlay_wh_var  = 'var(--novixa-overlay-w-hover, 100%)';
			$overlay_hh_var  = 'var(--novixa-overlay-h-hover, 100%)';
			$overlay_x_var   = 'var(--novixa-overlay-x, 6px)';
			$overlay_y_var   = 'var(--novixa-overlay-y, 6px)';

			// Resting-state: a small overlay pinned near the top-right
			// corner via top/right offsets (Position Y / Position X).
			// Hover-state: it grows to Width Hover / Height Hover and
			// resets its offset to 0/0 so it always ends up covering the
			// button fully regardless of the button's own size — exactly
			// matching Unlimited Elements' Overlay Button control set
			// (Overlay Width/Height, Width/Height Hover, Position X/Y).
			$scoped_css = sprintf(
				'#%1$s{position:relative!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;overflow:hidden!important;box-sizing:border-box!important;background-color:%2$s!important;color:%3$s!important;cursor:pointer!important;text-decoration:none!important;transition:color %4$s ease!important;}'
				. '#%1$s .novixa-addons-overlay-btn__chip{position:absolute!important;z-index:1!important;pointer-events:none!important;top:%5$s!important;right:%6$s!important;width:%7$s!important;height:%8$s!important;background-color:%9$s!important;transition:all %4$s cubic-bezier(.65,0,.35,1)!important;}'
				. '#%1$s .novixa-addons-overlay-btn__text{position:relative!important;z-index:2!important;}'
				. '#%1$s:hover{color:%10$s!important;}'
				. '#%1$s:hover .novixa-addons-overlay-btn__chip{top:0!important;right:0!important;width:%11$s!important;height:%12$s!important;}',
				esc_attr( $uid ),
				esc_attr( $bg_var ),
				esc_attr( $text_var ),
				esc_attr( $speed_var ),
				esc_attr( $overlay_y_var ),
				esc_attr( $overlay_x_var ),
				esc_attr( $overlay_w_var ),
				esc_attr( $overlay_h_var ),
				esc_attr( $overlay_var ),
				esc_attr( $hover_text_var ),
				esc_attr( $overlay_wh_var ),
				esc_attr( $overlay_hh_var )
			);

			printf( '<div class="%1$s">', esc_attr( $this->bem( 'overlay-btn', 'wrap' ) ) );

			// Printed directly inside this widget's own markup (not via
			// wp_add_inline_style()) so it works identically on a full
			// front-end page load and inside Elementor's isolated
			// per-widget editor preview render — see the render() note
			// above.
			echo '<style>' . $scoped_css . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $scoped_css is built entirely from esc_attr()-passed values above, no raw user HTML.

			printf( '<%1$s %2$s>', esc_html( $tag ), $this->get_render_attribute_string( 'novixa_btn' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

			printf( '<span class="%1$s" aria-hidden="true"></span>', esc_attr( $this->bem( 'overlay-btn', 'chip' ) ) );
			printf( '<span class="%1$s">%2$s</span>', esc_attr( $this->bem( 'overlay-btn', 'text' ) ), esc_html( $settings['novixa_text'] ) );

			echo '</' . esc_html( $tag ) . '>';

			echo '</div>';
		}
	}
}
