<?php
/**
 * Icon Accordion widget — a list of expandable panels, each with its
 * own icon, heading, and content, plus an expand/collapse indicator.
 * Modeled on Unlimited Elements' "Icon Accordion" widget.
 *
 * Expand/collapse is done with a visually-hidden <input type="radio|checkbox">
 * per item and a CSS grid-rows trick — no JavaScript required, so it
 * animates smoothly and works identically in the editor preview and
 * on the live front-end.
 *
 * @package Novixa_Addons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Icons_Manager;
use Elementor\Utils;

if ( ! class_exists( 'Novixa_Addons_Widget_Icon_Accordion' ) ) {

	/**
	 * Class Novixa_Addons_Widget_Icon_Accordion
	 */
	class Novixa_Addons_Widget_Icon_Accordion extends Novixa_Addons_Widget_Base {

		/**
		 * Unique widget name registered with Elementor.
		 *
		 * @return string
		 */
		public function get_name() {
			return 'novixa-addons-icon-accordion';
		}

		/**
		 * Panel label.
		 *
		 * @return string
		 */
		public function get_title() {
			return __( 'Icon Accordion - Novixa', 'novixa-addons-for-elementor' );
		}

		/**
		 * Panel icon.
		 *
		 * @return string
		 */
		public function get_icon() {
			return 'eicon-accordion';
		}

		/**
		 * Panel search keywords.
		 *
		 * @return array
		 */
		public function get_keywords() {
			return array_merge( $this->get_base_keywords(), array( 'accordion', 'faq', 'toggle', 'collapse', 'icon' ) );
		}

		/**
		 * Style dependency.
		 *
		 * @return array
		 */
		/**
		 * Script dependency — 'novixa-addons-frontend' also holds the
		 * shared front-end interaction JS (see assets/js/frontend.js).
		 * Without declaring it here, Elementor won't reliably print it
		 * on the isolated AJAX request used to (re)render this widget
		 * while editing, which can leave this widget's interactive
		 * behaviour silently broken in the editor canvas.
		 *
		 * @return array
		 */
		public function get_script_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Style dependency.
		 *
		 * @return array
		 */
		public function get_style_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Register all controls.
		 */
		protected function register_controls() {
			$this->register_general_controls();
			$this->register_icons_controls();
			$this->register_items_controls();
			$this->register_item_style_controls();
			$this->register_heading_style_controls();
			$this->register_content_style_controls();
			$this->register_icon_style_controls();
			$this->register_expand_style_controls();
		}

		/**
		 * Content tab > General settings.
		 */
		protected function register_general_controls() {
			$this->start_controls_section(
				'novixa_section_general',
				array(
					'label' => __( 'General', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_trigger_type',
				array(
					'label'   => __( 'Trigger Type', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'click',
					'options' => array(
						'click' => __( 'Click', 'novixa-addons-for-elementor' ),
						'hover' => __( 'Hover', 'novixa-addons-for-elementor' ),
					),
				)
			);

			$this->add_control(
				'novixa_first_closed',
				array(
					'label'     => __( 'First Accordion Closed', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SELECT,
					'default'   => 'no',
					'options'   => array(
						'no'  => __( 'No', 'novixa-addons-for-elementor' ),
						'yes' => __( 'Yes', 'novixa-addons-for-elementor' ),
					),
					'condition' => array(
						'novixa_trigger_type' => 'click',
					),
				)
			);

			$this->add_control(
				'novixa_close_others',
				array(
					'label'        => __( 'Close Others on Open', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'yes',
					'description'  => __( 'When on, opening one item automatically closes the others.', 'novixa-addons-for-elementor' ),
					'condition'    => array(
						'novixa_trigger_type' => 'click',
					),
				)
			);

			$this->add_control(
				'novixa_heading_direction',
				array(
					'label'   => __( 'Heading Direction', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'regular',
					'options' => array(
						'regular' => __( 'Regular (Icon First)', 'novixa-addons-for-elementor' ),
						'reverse' => __( 'Reverse (Icon Last)', 'novixa-addons-for-elementor' ),
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'header-inner' ) => 'flex-direction: {{VALUE}};',
					),
					'selectors_dictionary' => array(
						'regular' => 'row',
						'reverse' => 'row-reverse',
					),
				)
			);

			$this->add_control(
				'novixa_show_icon',
				array(
					'label'        => __( 'Show Icon', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'yes',
				)
			);

			$this->add_control(
				'novixa_show_expand',
				array(
					'label'        => __( 'Show Expand Icon', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'yes',
				)
			);

			$this->add_control(
				'novixa_html_tag',
				array(
					'label'   => __( 'Title HTML Tag', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::SELECT,
					'options' => array(
						'div'  => 'div',
						'h1'   => 'H1',
						'h2'   => 'H2',
						'h3'   => 'H3',
						'h4'   => 'H4',
						'h5'   => 'H5',
						'h6'   => 'H6',
						'span' => 'span',
						'p'    => 'p',
					),
					'default' => 'h3',
				)
			);

			$this->add_control(
				'novixa_scroll_to_head',
				array(
					'label'     => __( 'Scroll To Head', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SELECT,
					'default'   => 'off',
					'options'   => array(
						'off' => __( 'Off', 'novixa-addons-for-elementor' ),
						'on'  => __( 'On', 'novixa-addons-for-elementor' ),
					),
					'description' => __( 'Smoothly scrolls the opened item into view.', 'novixa-addons-for-elementor' ),
					'condition' => array(
						'novixa_trigger_type' => 'click',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Content tab > Expand/Collapse icons.
		 */
		protected function register_icons_controls() {
			$this->start_controls_section(
				'novixa_section_icons',
				array(
					'label'     => __( 'Expand / Collapse Icons', 'novixa-addons-for-elementor' ),
					'condition' => array(
						'novixa_show_expand' => 'yes',
					),
				)
			);

			$this->add_control(
				'novixa_expand_icon',
				array(
					'label'   => __( 'Expand Icon', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::ICONS,
					'default' => array(
						'value'   => 'fas fa-chevron-down',
						'library' => 'fa-solid',
					),
					'skin'    => 'inline',
				)
			);

			$this->add_control(
				'novixa_collapse_icon',
				array(
					'label'   => __( 'Collapse Icon', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::ICONS,
					'default' => array(
						'value'   => 'fas fa-chevron-up',
						'library' => 'fa-solid',
					),
					'skin'    => 'inline',
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Content tab > Repeater items.
		 */
		protected function register_items_controls() {
			$this->start_controls_section(
				'novixa_section_items',
				array(
					'label' => __( 'Items', 'novixa-addons-for-elementor' ),
				)
			);

			$repeater = new Repeater();

			$repeater->add_control(
				'novixa_item_heading',
				array(
					'label'       => __( 'Heading', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( 'Accordion Item', 'novixa-addons-for-elementor' ),
					'label_block' => true,
				)
			);

			$repeater->add_control(
				'novixa_item_icon',
				array(
					'label'   => __( 'Icon', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::ICONS,
					'default' => array(
						'value'   => 'fas fa-question',
						'library' => 'fa-solid',
					),
					'skin'    => 'inline',
				)
			);

			$repeater->add_control(
				'novixa_item_content',
				array(
					'label'       => __( 'Content', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::WYSIWYG,
					'default'     => __( 'Type the content for this accordion item here.', 'novixa-addons-for-elementor' ),
					'show_label'  => false,
				)
			);

			$this->add_control(
				'novixa_items',
				array(
					'label'       => __( 'Accordion Items', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::REPEATER,
					'fields'      => $repeater->get_controls(),
					'default'     => array(
						array(
							'novixa_item_heading' => __( 'What is recycling?', 'novixa-addons-for-elementor' ),
							'novixa_item_icon'    => array(
								'value'   => 'fas fa-recycle',
								'library' => 'fa-solid',
							),
							'novixa_item_content' => __( 'Recycling is the process of collecting and processing materials that would otherwise be thrown away as trash and turning them into new products.', 'novixa-addons-for-elementor' ),
						),
						array(
							'novixa_item_heading' => __( 'Is recycling truly beneficial for the environment?', 'novixa-addons-for-elementor' ),
							'novixa_item_icon'    => array(
								'value'   => 'fas fa-globe',
								'library' => 'fa-solid',
							),
							'novixa_item_content' => __( 'Yes — recycling reduces the need for raw materials, saves energy, and cuts down on landfill waste.', 'novixa-addons-for-elementor' ),
						),
						array(
							'novixa_item_heading' => __( 'How does recycling save energy?', 'novixa-addons-for-elementor' ),
							'novixa_item_icon'    => array(
								'value'   => 'fas fa-bolt',
								'library' => 'fa-solid',
							),
							'novixa_item_content' => __( 'Making products from recycled materials typically uses far less energy than making them from raw materials.', 'novixa-addons-for-elementor' ),
						),
					),
					'title_field' => '{{{ novixa_item_heading }}}',
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Item (the outer card for each accordion entry).
		 */
		protected function register_item_style_controls() {
			$this->start_controls_section(
				'novixa_section_item_style',
				array(
					'label' => __( 'Item', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_responsive_control(
				'novixa_item_spacing',
				array(
					'label'     => __( 'Spacing Between Items', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 0,
							'max' => 60,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 16,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'item' ) => 'margin-bottom: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_control(
				'novixa_item_bg_color',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#ffffff',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'item' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_item_radius',
				array(
					'label'      => __( 'Border Radius', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', '%' ),
					'default'    => array(
						'top'      => 10,
						'right'    => 10,
						'bottom'   => 10,
						'left'     => 10,
						'unit'     => 'px',
						'isLinked' => true,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'item' ) => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}; overflow: hidden;',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Border::get_type(),
				array(
					'name'     => 'novixa_item_border',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'item' ),
				)
			);

			$this->add_group_control(
				Group_Control_Box_Shadow::get_type(),
				array(
					'name'     => 'novixa_item_shadow',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'item' ),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Heading — background/text/icon color across
		 * Normal, Hover, and Active (open) states, mirroring
		 * Unlimited Elements' "Heading / Heading Hover / Heading
		 * Active" style sections.
		 */
		protected function register_heading_style_controls() {
			$this->start_controls_section(
				'novixa_section_heading_style',
				array(
					'label' => __( 'Heading', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_responsive_control(
				'novixa_heading_padding',
				array(
					'label'      => __( 'Padding', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', 'em', '%' ),
					'default'    => array(
						'top'      => 18,
						'right'    => 20,
						'bottom'   => 18,
						'left'     => 20,
						'unit'     => 'px',
						'isLinked' => false,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'header-inner' ) => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_heading_gap',
				array(
					'label'     => __( 'Icon / Text Gap', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 0,
							'max' => 60,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 14,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'header-inner' ) => 'gap: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'     => 'novixa_heading_typography',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'title' ),
				)
			);

			$this->add_group_control(
				Group_Control_Border::get_type(),
				array(
					'name'     => 'novixa_heading_border',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'header-inner' ),
				)
			);

			$this->start_controls_tabs( 'novixa_heading_state_tabs' );

			$this->start_controls_tab(
				'novixa_heading_state_normal',
				array( 'label' => __( 'Normal', 'novixa-addons-for-elementor' ) )
			);

			$this->add_control(
				'novixa_heading_bg_normal',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'header-inner' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_heading_text_normal',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#1a1a2e',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'title' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'novixa_heading_state_hover',
				array( 'label' => __( 'Hover', 'novixa-addons-for-elementor' ) )
			);

			$this->add_control(
				'novixa_heading_bg_hover',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'header-inner' ) . ':hover' => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_heading_text_hover',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'header-inner' ) . ':hover .' . $this->bem( 'icon-accordion', 'title' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'novixa_heading_state_active',
				array( 'label' => __( 'Active', 'novixa-addons-for-elementor' ) )
			);

			$this->add_control(
				'novixa_heading_bg_active',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'item', 'open' ) . ' .' . $this->bem( 'icon-accordion', 'header-inner' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_heading_text_active',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'item', 'open' ) . ' .' . $this->bem( 'icon-accordion', 'header-inner' ) . ' .' . $this->bem( 'icon-accordion', 'title' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_tab();

			$this->end_controls_tabs();

			$this->end_controls_section();
		}

		/**
		 * Style tab > Content (the collapsible body).
		 */
		protected function register_content_style_controls() {
			$this->start_controls_section(
				'novixa_section_content_style',
				array(
					'label' => __( 'Content', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_control(
				'novixa_content_bg_color',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'content-inner' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_content_text_color',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#6f6c7d',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'content-inner' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'     => 'novixa_content_typography',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'content-inner' ),
				)
			);

			$this->add_responsive_control(
				'novixa_content_padding',
				array(
					'label'      => __( 'Padding', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', 'em', '%' ),
					'default'    => array(
						'top'      => 0,
						'right'    => 20,
						'bottom'   => 20,
						'left'     => 20,
						'unit'     => 'px',
						'isLinked' => false,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'content-inner' ) => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Icon (the leading item icon, not the
		 * expand/collapse indicator).
		 */
		protected function register_icon_style_controls() {
			$this->start_controls_section(
				'novixa_section_icon_style',
				array(
					'label'     => __( 'Icon', 'novixa-addons-for-elementor' ),
					'tab'       => Controls_Manager::TAB_STYLE,
					'condition' => array(
						'novixa_show_icon' => 'yes',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_icon_size',
				array(
					'label'     => __( 'Icon Size', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 8,
							'max' => 60,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 18,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'icon' ) . ' i'   => 'font-size: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'icon' ) . ' svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_icon_box_size',
				array(
					'label'     => __( 'Icon Box Size', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 16,
							'max' => 120,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 42,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'icon' ) => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_control(
				'novixa_icon_color',
				array(
					'label'     => __( 'Icon Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#4f3ff0',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'icon' ) => 'color: {{VALUE}};',
						'{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'icon' ) . ' svg' => 'fill: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_icon_bg_color',
				array(
					'label'     => __( 'Icon Background', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => 'rgba(79,63,240,0.08)',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'icon' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_icon_radius',
				array(
					'label'      => __( 'Border Radius', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', '%' ),
					'default'    => array(
						'top'      => 10,
						'right'    => 10,
						'bottom'   => 10,
						'left'     => 10,
						'unit'     => 'px',
						'isLinked' => true,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'icon' ) => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Expand/Collapse indicator.
		 */
		protected function register_expand_style_controls() {
			$this->start_controls_section(
				'novixa_section_expand_style',
				array(
					'label'     => __( 'Expand / Collapse Icon', 'novixa-addons-for-elementor' ),
					'tab'       => Controls_Manager::TAB_STYLE,
					'condition' => array(
						'novixa_show_expand' => 'yes',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_expand_size',
				array(
					'label'     => __( 'Icon Size', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 6,
							'max' => 40,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 14,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'expand' ) . ' i'   => 'font-size: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'expand' ) . ' svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_control(
				'novixa_expand_color',
				array(
					'label'     => __( 'Icon Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#2e9e6f',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'expand' ) => 'color: {{VALUE}};',
						'{{WRAPPER}} .' . $this->bem( 'icon-accordion', 'expand' ) . ' svg' => 'fill: {{VALUE}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Front-end render.
		 */
		protected function render() {
			$settings = $this->get_settings_for_display();

			$items = ! empty( $settings['novixa_items'] ) ? $settings['novixa_items'] : array();
			if ( empty( $items ) ) {
				return;
			}

			$uid = 'novixa-accordion-' . esc_attr( $this->get_id() );

			$is_hover = 'hover' === $settings['novixa_trigger_type'];
			// "First Accordion Closed" = Yes means nothing is open on
			// load; No (default) means the first item starts open —
			// same wording/behavior as the reference widget.
			$first_open      = ! $is_hover && ( 'yes' !== $settings['novixa_first_closed'] );
			$close_others    = ! $is_hover && 'yes' === $settings['novixa_close_others'];
			$show_icon       = 'yes' === $settings['novixa_show_icon'];
			$show_expand     = 'yes' === $settings['novixa_show_expand'];
			$tag             = ! empty( $settings['novixa_html_tag'] ) ? $settings['novixa_html_tag'] : 'h3';
			$scroll_to_head  = ! $is_hover && 'on' === $settings['novixa_scroll_to_head'];

			printf(
				'<div class="%1$s" id="%2$s" data-trigger="%3$s" data-close-others="%4$s" data-scroll-to-head="%5$s">',
				esc_attr( $this->bem( 'icon-accordion' ) ),
				esc_attr( $uid ),
				esc_attr( $is_hover ? 'hover' : 'click' ),
				esc_attr( $close_others ? 'yes' : 'no' ),
				esc_attr( $scroll_to_head ? 'yes' : 'no' )
			);

			foreach ( $items as $index => $item ) {
				$is_open = ( 0 === $index && $first_open );

				$item_class = $this->bem( 'icon-accordion', 'item' );
				if ( $is_open ) {
					$item_class .= ' ' . $this->bem( 'icon-accordion', 'item', 'open' );
				}

				printf( '<div class="%1$s">', esc_attr( $item_class ) );

				printf(
					'<div class="%1$s" role="button" tabindex="0" aria-expanded="%2$s">',
					esc_attr( $this->bem( 'icon-accordion', 'header' ) ),
					$is_open ? 'true' : 'false'
				);
				printf( '<span class="%1$s">', esc_attr( $this->bem( 'icon-accordion', 'header-inner' ) ) );

				if ( $show_icon && ! empty( $item['novixa_item_icon']['value'] ) ) {
					printf( '<span class="%1$s">', esc_attr( $this->bem( 'icon-accordion', 'icon' ) ) );
					Icons_Manager::render_icon( $item['novixa_item_icon'], array( 'aria-hidden' => 'true' ) );
					echo '</span>';
				}

				printf(
					'<%1$s class="%2$s">%3$s</%1$s>',
					Utils::validate_html_tag( $tag ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					esc_attr( $this->bem( 'icon-accordion', 'title' ) ),
					esc_html( $item['novixa_item_heading'] )
				);

				if ( $show_expand ) {
					printf( '<span class="%1$s">', esc_attr( $this->bem( 'icon-accordion', 'expand' ) ) );

					printf( '<span class="%1$s">', esc_attr( $this->bem( 'icon-accordion', 'expand-open' ) ) );
					if ( ! empty( $settings['novixa_expand_icon']['value'] ) ) {
						Icons_Manager::render_icon( $settings['novixa_expand_icon'], array( 'aria-hidden' => 'true' ) );
					}
					echo '</span>';

					printf( '<span class="%1$s">', esc_attr( $this->bem( 'icon-accordion', 'expand-close' ) ) );
					if ( ! empty( $settings['novixa_collapse_icon']['value'] ) ) {
						Icons_Manager::render_icon( $settings['novixa_collapse_icon'], array( 'aria-hidden' => 'true' ) );
					}
					echo '</span>';

					echo '</span>';
				}

				echo '</span>'; // .header-inner
				echo '</div>'; // .header

				printf(
					'<div class="%1$s" style="overflow:hidden;max-height:%2$s;transition:max-height 0.35s ease;">',
					esc_attr( $this->bem( 'icon-accordion', 'content' ) ),
					$is_open ? '2000px' : '0px'
				);
				printf( '<div class="%1$s">', esc_attr( $this->bem( 'icon-accordion', 'content-inner' ) ) );
				echo wp_kses_post( $item['novixa_item_content'] );
				echo '</div>';
				echo '</div>';

				echo '</div>'; // .item
			}

			echo '</div>'; // .icon-accordion

			// Open/close behavior is handled by the document-level
			// event delegation in assets/js/frontend.js (shared with
			// the plain Accordion widget) — not by a per-instance
			// <script> printed here. A script tag inserted via
			// Elementor's AJAX widget re-render never auto-executes,
			// so a delegated listener registered once, up front, is
			// what makes this work reliably inside the editor too.
		}
	}
}
