<?php
/**
 * Content Reveal on Hover widget — a background-image box whose title
 * shifts and whose description/buttons/badge fade & slide into view
 * on hover, with an adjustable overlay scrim underneath. Modeled on
 * Unlimited Elements' "Content Reveal on Hover" widget.
 *
 * @package Novixa_Addons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Icons_Manager;
use Elementor\Utils;

if ( ! class_exists( 'Novixa_Addons_Widget_Content_Reveal_Hover' ) ) {

	/**
	 * Class Novixa_Addons_Widget_Content_Reveal_Hover
	 */
	class Novixa_Addons_Widget_Content_Reveal_Hover extends Novixa_Addons_Widget_Base {

		/**
		 * Unique widget name registered with Elementor.
		 *
		 * @return string
		 */
		public function get_name() {
			return 'novixa-addons-content-reveal-hover';
		}

		/**
		 * Panel label.
		 *
		 * @return string
		 */
		public function get_title() {
			return __( 'Content Reveal on Hover - Novixa', 'novixa-addons-for-elementor' );
		}

		/**
		 * Panel icon.
		 *
		 * @return string
		 */
		public function get_icon() {
			return 'eicon-image-box';
		}

		/**
		 * Panel search keywords.
		 *
		 * @return array
		 */
		public function get_keywords() {
			return array_merge( $this->get_base_keywords(), array( 'hover', 'reveal', 'content box', 'service', 'image' ) );
		}

		/**
		 * Style dependency.
		 *
		 * @return array
		 */
		public function get_style_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Register all controls.
		 */
		protected function register_controls() {
			$this->register_content_controls();
			$this->register_box_style_controls();
			$this->register_image_style_controls();
			$this->register_overlay_style_controls();
			$this->register_title_style_controls();
			$this->register_text_style_controls();
			$this->register_button_style_controls();
		}

		/**
		 * Content tab.
		 */
		protected function register_content_controls() {
			$this->start_controls_section(
				'novixa_section_content',
				array(
					'label' => __( 'Content Reveal on Hover', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_image',
				array(
					'label'   => __( 'Image', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::MEDIA,
					'default' => array(
						'url' => \Elementor\Utils::get_placeholder_image_src(),
					),
				)
			);

			$this->add_group_control(
				Group_Control_Image_Size::get_type(),
				array(
					'name'    => 'novixa_image_size',
					'default' => 'large',
				)
			);

			$this->add_control(
				'novixa_show_icon',
				array(
					'label'        => __( 'Show Icon', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => '',
				)
			);

			$this->add_control(
				'novixa_icon',
				array(
					'label'     => __( 'Icon', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::ICONS,
					'default'   => array(
						'value'   => 'fas fa-star',
						'library' => 'fa-solid',
					),
					'condition' => array(
						'novixa_show_icon' => 'yes',
					),
				)
			);

			$this->add_control(
				'novixa_show_title',
				array(
					'label'        => __( 'Show Title', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'yes',
				)
			);

			$this->add_control(
				'novixa_title',
				array(
					'label'       => __( 'Title', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( 'Marketing', 'novixa-addons-for-elementor' ),
					'label_block' => true,
					'dynamic'     => array( 'active' => true ),
					'condition'   => array(
						'novixa_show_title' => 'yes',
					),
				)
			);

			$this->add_control(
				'novixa_title_html_tag',
				array(
					'label'     => __( 'Title HTML Tag', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SELECT,
					'options'   => array(
						'h1'   => 'H1',
						'h2'   => 'H2',
						'h3'   => 'H3',
						'h4'   => 'H4',
						'h5'   => 'H5',
						'h6'   => 'H6',
						'div'  => 'div',
						'span' => 'span',
						'p'    => 'p',
					),
					'default'   => 'h3',
					'condition' => array(
						'novixa_show_title' => 'yes',
					),
				)
			);

			$this->add_control(
				'novixa_show_text',
				array(
					'label'        => __( 'Show Text', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'yes',
				)
			);

			$this->add_control(
				'novixa_text',
				array(
					'label'     => __( 'Text', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::WYSIWYG,
					'default'   => __( 'Strategizing targeted campaigns to maximize reach and drive customer engagement.', 'novixa-addons-for-elementor' ),
					'dynamic'   => array( 'active' => true ),
					'condition' => array(
						'novixa_show_text' => 'yes',
					),
				)
			);

			$this->add_control(
				'novixa_show_button',
				array(
					'label'        => __( 'Show Button', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'yes',
				)
			);

			$this->add_control(
				'novixa_button_label',
				array(
					'label'       => __( 'Button Label', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( 'Learn More', 'novixa-addons-for-elementor' ),
					'label_block' => true,
					'dynamic'     => array( 'active' => true ),
					'condition'   => array(
						'novixa_show_button' => 'yes',
					),
				)
			);

			$this->add_control(
				'novixa_button_link',
				array(
					'label'         => __( 'Button Link', 'novixa-addons-for-elementor' ),
					'type'          => Controls_Manager::URL,
					'placeholder'   => __( 'https://your-link.com', 'novixa-addons-for-elementor' ),
					'show_external' => true,
					'default'       => array(
						'url' => '',
					),
					'condition'     => array(
						'novixa_show_button' => 'yes',
					),
				)
			);

			$this->add_control(
				'novixa_show_button_icon',
				array(
					'label'        => __( 'Show Button Icon', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'yes',
					'condition'    => array(
						'novixa_show_button' => 'yes',
					),
				)
			);

			$this->add_control(
				'novixa_button_icon',
				array(
					'label'     => __( 'Button Icon', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::ICONS,
					'default'   => array(
						'value'   => 'fas fa-arrow-right',
						'library' => 'fa-solid',
					),
					'condition' => array(
						'novixa_show_button'      => 'yes',
						'novixa_show_button_icon' => 'yes',
					),
				)
			);

			$this->add_control(
				'novixa_show_button_two',
				array(
					'label'        => __( 'Show Button Two', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => '',
				)
			);

			$this->add_control(
				'novixa_button_two_label',
				array(
					'label'       => __( 'Button Two Label', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( 'Hire Us', 'novixa-addons-for-elementor' ),
					'label_block' => true,
					'dynamic'     => array( 'active' => true ),
					'condition'   => array(
						'novixa_show_button_two' => 'yes',
					),
				)
			);

			$this->add_control(
				'novixa_button_two_link',
				array(
					'label'         => __( 'Button Two Link', 'novixa-addons-for-elementor' ),
					'type'          => Controls_Manager::URL,
					'placeholder'   => __( 'https://your-link.com', 'novixa-addons-for-elementor' ),
					'show_external' => true,
					'default'       => array(
						'url' => '',
					),
					'condition'     => array(
						'novixa_show_button_two' => 'yes',
					),
				)
			);

			$this->add_control(
				'novixa_show_badge',
				array(
					'label'        => __( 'Show Badge', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => '',
				)
			);

			$this->add_control(
				'novixa_badge_text',
				array(
					'label'       => __( 'Badge Text', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( 'New', 'novixa-addons-for-elementor' ),
					'label_block' => true,
					'dynamic'     => array( 'active' => true ),
					'condition'   => array(
						'novixa_show_badge' => 'yes',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_align',
				array(
					'label'     => __( 'Align', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::CHOOSE,
					'default'   => 'left',
					'options'   => array(
						'left'   => array(
							'title' => __( 'Left', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-left',
						),
						'center' => array(
							'title' => __( 'Center', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-center',
						),
						'right'  => array(
							'title' => __( 'Right', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-right',
						),
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'content-reveal-hover', 'content' ) => 'text-align: {{VALUE}}; align-items: ' . '{{VALUE}}' . ';',
					),
				)
			);

			$this->add_control(
				'novixa_transition_time',
				array(
					'label'   => __( 'Transition Time (seconds)', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::NUMBER,
					'min'     => 0.1,
					'max'     => 2,
					'step'    => 0.05,
					'default' => 0.35,
				)
			);

			$this->add_control(
				'novixa_overlay_transition_time',
				array(
					'label'   => __( 'Overlay Transition Time (seconds)', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::NUMBER,
					'min'     => 0.1,
					'max'     => 2,
					'step'    => 0.05,
					'default' => 0.35,
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Box (media container).
		 */
		protected function register_box_style_controls() {
			$this->start_controls_section(
				'novixa_section_box_style',
				array(
					'label' => __( 'Box', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_responsive_control(
				'novixa_content_padding',
				array(
					'label'      => __( 'Content Padding', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', 'em', '%' ),
					'default'    => array(
						'top'      => 28,
						'right'    => 28,
						'bottom'   => 28,
						'left'     => 28,
						'unit'     => 'px',
						'isLinked' => true,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'content-reveal-hover', 'content' ) => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_box_radius',
				array(
					'label'      => __( 'Box Radius', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', '%' ),
					'default'    => array(
						'top'      => 24,
						'right'    => 24,
						'bottom'   => 24,
						'left'     => 24,
						'unit'     => 'px',
						'isLinked' => true,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'content-reveal-hover' ) => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}; overflow: hidden;',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Border::get_type(),
				array(
					'name'     => 'novixa_box_border',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'content-reveal-hover' ),
				)
			);

			$this->add_control(
				'novixa_content_valign',
				array(
					'label'     => __( 'Content Vertical Align', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::CHOOSE,
					'default'   => 'end',
					'options'   => array(
						'start'  => array(
							'title' => __( 'Start', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-v-align-top',
						),
						'center' => array(
							'title' => __( 'Center', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-v-align-middle',
						),
						'end'    => array(
							'title' => __( 'End', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-v-align-bottom',
						),
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'content-reveal-hover', 'content' ) => 'justify-content: flex-{{VALUE}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Box_Shadow::get_type(),
				array(
					'name'     => 'novixa_box_shadow',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'content-reveal-hover' ),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Image.
		 */
		protected function register_image_style_controls() {
			$this->start_controls_section(
				'novixa_section_image_style',
				array(
					'label' => __( 'Image', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_responsive_control(
				'novixa_image_height',
				array(
					'label'     => __( 'Image Height', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 200,
							'max' => 900,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 420,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'content-reveal-hover' ) => 'height: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_control(
				'novixa_image_position',
				array(
					'label'     => __( 'Image Position', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SELECT,
					'default'   => 'center center',
					'options'   => array(
						'top center'    => __( 'Top Center', 'novixa-addons-for-elementor' ),
						'center center' => __( 'Center Center', 'novixa-addons-for-elementor' ),
						'bottom center' => __( 'Bottom Center', 'novixa-addons-for-elementor' ),
						'top left'      => __( 'Top Left', 'novixa-addons-for-elementor' ),
						'top right'     => __( 'Top Right', 'novixa-addons-for-elementor' ),
						'bottom left'   => __( 'Bottom Left', 'novixa-addons-for-elementor' ),
						'bottom right'  => __( 'Bottom Right', 'novixa-addons-for-elementor' ),
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'content-reveal-hover', 'media' ) . ' img' => 'object-position: {{VALUE}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Overlay (the readability scrim that darkens
		 * further on hover).
		 */
		protected function register_overlay_style_controls() {
			$this->start_controls_section(
				'novixa_section_overlay_style',
				array(
					'label' => __( 'Overlay', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_control(
				'novixa_overlay_color',
				array(
					'label'     => __( 'Overlay Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => 'rgba(10, 10, 30, 0.9)',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'content-reveal-hover', 'overlay' ) => 'background: linear-gradient(0deg, {{VALUE}} 0%, transparent 65%);',
					),
				)
			);

			$this->add_control(
				'novixa_overlay_opacity',
				array(
					'label'     => __( 'Overlay Opacity', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min'  => 0,
							'max'  => 1,
							'step' => 0.05,
						),
					),
					'default'   => array(
						'size' => 0.55,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'content-reveal-hover', 'overlay' ) => 'opacity: {{SIZE}};',
					),
				)
			);

			$this->add_control(
				'novixa_overlay_opacity_hover',
				array(
					'label'     => __( 'Overlay Opacity Hover', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min'  => 0,
							'max'  => 1,
							'step' => 0.05,
						),
					),
					'default'   => array(
						'size' => 1,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'content-reveal-hover' ) . ':hover .' . $this->bem( 'content-reveal-hover', 'overlay' ) => 'opacity: {{SIZE}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Title.
		 */
		protected function register_title_style_controls() {
			$this->start_controls_section(
				'novixa_section_title_style',
				array(
					'label'     => __( 'Title', 'novixa-addons-for-elementor' ),
					'tab'       => Controls_Manager::TAB_STYLE,
					'condition' => array(
						'novixa_show_title' => 'yes',
					),
				)
			);

			$this->add_control(
				'novixa_title_color',
				array(
					'label'     => __( 'Title Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#ffffff',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'content-reveal-hover', 'title' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'           => 'novixa_title_typography',
					'selector'       => '{{WRAPPER}} .' . $this->bem( 'content-reveal-hover', 'title' ),
					'fields_options' => array(
						'font_weight' => array(
							'default' => '700',
						),
						'font_size'   => array(
							'default' => array(
								'unit' => 'px',
								'size' => 24,
							),
						),
					),
				)
			);

			$this->add_control(
				'novixa_title_hover_gap',
				array(
					'label'       => __( 'Title Hover Vertical Gap', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::SLIDER,
					'range'       => array(
						'px' => array(
							'min' => -60,
							'max' => 60,
						),
					),
					'default'     => array(
						'unit' => 'px',
						'size' => -8,
					),
					'description' => __( 'How far the title shifts vertically when the box is hovered — negative moves it up.', 'novixa-addons-for-elementor' ),
					'selectors'   => array(
						'{{WRAPPER}} .' . $this->bem( 'content-reveal-hover' ) . ':hover .' . $this->bem( 'content-reveal-hover', 'title' ) => 'transform: translateY({{SIZE}}{{UNIT}});',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Text (the description + buttons + badge that
		 * stay collapsed until hover).
		 */
		protected function register_text_style_controls() {
			$this->start_controls_section(
				'novixa_section_text_style',
				array(
					'label'     => __( 'Text', 'novixa-addons-for-elementor' ),
					'tab'       => Controls_Manager::TAB_STYLE,
					'condition' => array(
						'novixa_show_text' => 'yes',
					),
				)
			);

			$this->add_control(
				'novixa_text_color',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => 'rgba(255,255,255,0.85)',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'content-reveal-hover', 'text' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'     => 'novixa_text_typography',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'content-reveal-hover', 'text' ),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Button (covers both buttons; Normal/Hover tabs).
		 */
		protected function register_button_style_controls() {
			$this->start_controls_section(
				'novixa_section_button_style',
				array(
					'label' => __( 'Button', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_control(
				'novixa_button_style_width',
				array(
					'label'     => __( 'Button Style', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SELECT,
					'default'   => 'auto',
					'options'   => array(
						'auto' => __( 'Auto Width', 'novixa-addons-for-elementor' ),
						'100%' => __( 'Full Width', 'novixa-addons-for-elementor' ),
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'content-reveal-hover', 'button' ) => 'width: {{VALUE}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'     => 'novixa_button_typography',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'content-reveal-hover', 'button' ),
				)
			);

			$this->add_responsive_control(
				'novixa_button_padding',
				array(
					'label'      => __( 'Button Padding', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', 'em' ),
					'default'    => array(
						'top'      => 10,
						'right'    => 20,
						'bottom'   => 10,
						'left'     => 20,
						'unit'     => 'px',
						'isLinked' => false,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'content-reveal-hover', 'button' ) => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_button_spacing_top',
				array(
					'label'     => __( 'Button Spacing Top', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 0,
							'max' => 60,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 16,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'content-reveal-hover', 'buttons' ) => 'margin-top: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_button_gap',
				array(
					'label'     => __( 'Button Gap', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 0,
							'max' => 60,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 12,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'content-reveal-hover', 'buttons' ) => 'gap: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_button_border_radius',
				array(
					'label'      => __( 'Button Border Radius', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', '%' ),
					'default'    => array(
						'top'      => 6,
						'right'    => 6,
						'bottom'   => 6,
						'left'     => 6,
						'unit'     => 'px',
						'isLinked' => true,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'content-reveal-hover', 'button' ) => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->start_controls_tabs( 'novixa_button_state_tabs' );

			$this->start_controls_tab(
				'novixa_button_state_normal',
				array(
					'label' => __( 'Normal', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_button_bg_color',
				array(
					'label'     => __( 'Button BG Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#ffffff',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'content-reveal-hover', 'button' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_button_text_color',
				array(
					'label'     => __( 'Button Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#1a1a2e',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'content-reveal-hover', 'button' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Border::get_type(),
				array(
					'name'     => 'novixa_button_border',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'content-reveal-hover', 'button' ),
				)
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'novixa_button_state_hover',
				array(
					'label' => __( 'Hover', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_button_bg_color_hover',
				array(
					'label'     => __( 'Button BG Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'content-reveal-hover', 'button' ) . ':hover' => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_button_text_color_hover',
				array(
					'label'     => __( 'Button Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'content-reveal-hover', 'button' ) . ':hover' => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_button_border_color_hover',
				array(
					'label'     => __( 'Button Border Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'condition' => array(
						'novixa_button_border_border!' => '',
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'content-reveal-hover', 'button' ) . ':hover' => 'border-color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_tab();

			$this->end_controls_tabs();

			$this->end_controls_section();
		}

		/**
		 * Front-end render.
		 */
		protected function render() {
			$settings = $this->get_settings_for_display();

			$transition_time         = ( isset( $settings['novixa_transition_time'] ) && '' !== $settings['novixa_transition_time'] ) ? (float) $settings['novixa_transition_time'] : 0.35;
			$overlay_transition_time = ( isset( $settings['novixa_overlay_transition_time'] ) && '' !== $settings['novixa_overlay_transition_time'] ) ? (float) $settings['novixa_overlay_transition_time'] : 0.35;

			$wrapper_style = sprintf(
				'--novixa-crh-transition:%1$ss;--novixa-crh-overlay-transition:%2$ss;',
				esc_attr( $transition_time ),
				esc_attr( $overlay_transition_time )
			);

			printf(
				'<div class="%1$s" style="%2$s">',
				esc_attr( $this->bem( 'content-reveal-hover' ) ),
				esc_attr( $wrapper_style )
			);

			printf( '<div class="%1$s">', esc_attr( $this->bem( 'content-reveal-hover', 'media' ) ) );
			echo Group_Control_Image_Size::get_attachment_image_html( $settings, 'novixa_image_size', 'novixa_image' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '</div>';

			printf( '<div class="%1$s"></div>', esc_attr( $this->bem( 'content-reveal-hover', 'overlay' ) ) );

			if ( 'yes' === $settings['novixa_show_badge'] && ! empty( $settings['novixa_badge_text'] ) ) {
				printf(
					'<div class="%1$s">%2$s</div>',
					esc_attr( $this->bem( 'content-reveal-hover', 'badge' ) ),
					esc_html( $settings['novixa_badge_text'] )
				);
			}

			printf( '<div class="%1$s">', esc_attr( $this->bem( 'content-reveal-hover', 'content' ) ) );

			if ( 'yes' === $settings['novixa_show_icon'] && ! empty( $settings['novixa_icon']['value'] ) ) {
				printf( '<div class="%1$s">', esc_attr( $this->bem( 'content-reveal-hover', 'icon' ) ) );
				Icons_Manager::render_icon( $settings['novixa_icon'], array( 'aria-hidden' => 'true' ) );
				echo '</div>';
			}

			if ( 'yes' === $settings['novixa_show_title'] && ! empty( $settings['novixa_title'] ) ) {
				$title_tag = ! empty( $settings['novixa_title_html_tag'] ) ? $settings['novixa_title_html_tag'] : 'h3';
				printf(
					'<%1$s class="%2$s">%3$s</%1$s>',
					Utils::validate_html_tag( $title_tag ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					esc_attr( $this->bem( 'content-reveal-hover', 'title' ) ),
					esc_html( $settings['novixa_title'] )
				);
			}

			$reveal_inner = '';

			if ( 'yes' === $settings['novixa_show_text'] && ! empty( $settings['novixa_text'] ) ) {
				$reveal_inner .= sprintf(
					'<div class="%1$s">%2$s</div>',
					esc_attr( $this->bem( 'content-reveal-hover', 'text' ) ),
					wp_kses_post( $settings['novixa_text'] )
				);
			}

			$show_button_one = 'yes' === $settings['novixa_show_button'] && ! empty( $settings['novixa_button_label'] );
			$show_button_two = 'yes' === $settings['novixa_show_button_two'] && ! empty( $settings['novixa_button_two_label'] );

			if ( $show_button_one || $show_button_two ) {
				ob_start();
				echo '<div class="' . esc_attr( $this->bem( 'content-reveal-hover', 'buttons' ) ) . '">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

				if ( $show_button_one ) {
					$has_link = ! empty( $settings['novixa_button_link']['url'] );
					$tag      = $has_link ? 'a' : 'span';
					if ( $has_link ) {
						$this->add_link_attributes( 'novixa_button_link_attr', $settings['novixa_button_link'] );
					}
					$this->add_render_attribute( 'novixa_button_link_attr', 'class', $this->bem( 'content-reveal-hover', 'button' ) );
					printf( '<%1$s %2$s>', esc_html( $tag ), $this->get_render_attribute_string( 'novixa_button_link_attr' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo esc_html( $settings['novixa_button_label'] );
					if ( 'yes' === $settings['novixa_show_button_icon'] && ! empty( $settings['novixa_button_icon']['value'] ) ) {
						echo ' ';
						Icons_Manager::render_icon( $settings['novixa_button_icon'], array( 'aria-hidden' => 'true' ) );
					}
					echo '</' . esc_html( $tag ) . '>';
				}

				if ( $show_button_two ) {
					$has_link_2 = ! empty( $settings['novixa_button_two_link']['url'] );
					$tag_2      = $has_link_2 ? 'a' : 'span';
					if ( $has_link_2 ) {
						$this->add_link_attributes( 'novixa_button_two_link_attr', $settings['novixa_button_two_link'] );
					}
					$this->add_render_attribute( 'novixa_button_two_link_attr', 'class', $this->bem( 'content-reveal-hover', 'button' ) . ' ' . $this->bem( 'content-reveal-hover', 'button', 'secondary' ) );
					printf( '<%1$s %2$s>', esc_html( $tag_2 ), $this->get_render_attribute_string( 'novixa_button_two_link_attr' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo esc_html( $settings['novixa_button_two_label'] );
					echo '</' . esc_html( $tag_2 ) . '>';
				}

				echo '</div>'; // .buttons
				$reveal_inner .= ob_get_clean();
			}

			if ( '' !== $reveal_inner ) {
				printf( '<div class="%1$s">', esc_attr( $this->bem( 'content-reveal-hover', 'reveal-group' ) ) );
				printf( '<div class="%1$s">', esc_attr( $this->bem( 'content-reveal-hover', 'reveal-group-inner' ) ) );
				echo $reveal_inner; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo '</div>'; // .reveal-group-inner
				echo '</div>'; // .reveal-group
			}

			echo '</div>'; // .content

			echo '</div>'; // root
		}

		/**
		 * Editor live-preview template.
		 */
		protected function content_template() {
			?>
			<#
			var titleTag = settings.novixa_title_html_tag || 'h3';
			var transitionTime = settings.novixa_transition_time || 0.35;
			var overlayTransitionTime = settings.novixa_overlay_transition_time || 0.35;
			var wrapperStyle = '--novixa-crh-transition:' + transitionTime + 's;--novixa-crh-overlay-transition:' + overlayTransitionTime + 's;';
			var showButtonOne = settings.novixa_show_button === 'yes' && settings.novixa_button_label;
			var showButtonTwo = settings.novixa_show_button_two === 'yes' && settings.novixa_button_two_label;
			#>
			<div class="novixa-addons-content-reveal-hover" style="{{ wrapperStyle }}">
				<div class="novixa-addons-content-reveal-hover__media">
					<img src="{{ settings.novixa_image.url }}" alt="" />
				</div>
				<div class="novixa-addons-content-reveal-hover__overlay"></div>
				<# if ( settings.novixa_show_badge === 'yes' && settings.novixa_badge_text ) { #>
				<div class="novixa-addons-content-reveal-hover__badge">{{{ settings.novixa_badge_text }}}</div>
				<# } #>
				<div class="novixa-addons-content-reveal-hover__content">
					<# if ( settings.novixa_show_icon === 'yes' && settings.novixa_icon && settings.novixa_icon.value ) { #>
					<div class="novixa-addons-content-reveal-hover__icon">
						<# if ( settings.novixa_icon.library && settings.novixa_icon.library.indexOf( 'svg' ) >= 0 ) { #>
						<# } else { #>
						<i class="{{ settings.novixa_icon.value }}"></i>
						<# } #>
					</div>
					<# } #>
					<# if ( settings.novixa_show_title === 'yes' && settings.novixa_title ) { #>
					<{{{ titleTag }}} class="novixa-addons-content-reveal-hover__title">{{{ settings.novixa_title }}}</{{{ titleTag }}}>
					<# } #>
					<# if ( ( settings.novixa_show_text === 'yes' && settings.novixa_text ) || showButtonOne || showButtonTwo ) { #>
					<div class="novixa-addons-content-reveal-hover__reveal-group">
						<div class="novixa-addons-content-reveal-hover__reveal-group-inner">
							<# if ( settings.novixa_show_text === 'yes' && settings.novixa_text ) { #>
							<div class="novixa-addons-content-reveal-hover__text">{{{ settings.novixa_text }}}</div>
							<# } #>
							<# if ( showButtonOne || showButtonTwo ) { #>
							<div class="novixa-addons-content-reveal-hover__buttons">
								<# if ( showButtonOne ) { #>
								<span class="novixa-addons-content-reveal-hover__button">{{{ settings.novixa_button_label }}}</span>
								<# } #>
								<# if ( showButtonTwo ) { #>
								<span class="novixa-addons-content-reveal-hover__button novixa-addons-content-reveal-hover__button--secondary">{{{ settings.novixa_button_two_label }}}</span>
								<# } #>
							</div>
							<# } #>
						</div>
					</div>
					<# } #>
				</div>
			</div>
			<?php
		}
	}
}
