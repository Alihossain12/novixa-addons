<?php
/**
 * Dual Color Heading widget — a heading split into two text runs, each
 * with its own independent color/typography, so a single title can
 * highlight part of its text in an accent color without needing raw
 * HTML in a text field.
 *
 * @package Novixa_Addons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Text_Stroke;
use Elementor\Utils;

if ( ! class_exists( 'Novixa_Addons_Widget_Dual_Color_Heading' ) ) {

	/**
	 * Class Novixa_Addons_Widget_Dual_Color_Heading
	 */
	class Novixa_Addons_Widget_Dual_Color_Heading extends Novixa_Addons_Widget_Base {

		use Novixa_Addons_Global_Controls;

		/**
		 * Unique widget name registered with Elementor.
		 *
		 * @return string
		 */
		public function get_name() {
			return 'novixa-addons-dual-color-heading';
		}

		/**
		 * Panel label.
		 *
		 * @return string
		 */
		public function get_title() {
			return __( 'Dual Color Heading - Novixa', 'novixa-addons-for-elementor' );
		}

		/**
		 * Panel icon.
		 *
		 * @return string
		 */
		public function get_icon() {
			return 'eicon-t-letter';
		}

		/**
		 * Panel search keywords.
		 *
		 * @return array
		 */
		public function get_keywords() {
			return array_merge( $this->get_base_keywords(), array( 'heading', 'title', 'text', 'dual', 'two color', 'split color', 'highlight' ) );
		}

		/**
		 * Script dependency — see the same note on the Heading widget.
		 *
		 * @return array
		 */
		public function get_script_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Style dependency.
		 *
		 * @return array
		 */
		public function get_style_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Register all controls.
		 */
		protected function register_controls() {
			$this->register_content_controls();
			$this->register_heading_style_controls();
			$this->register_part_style_controls( 'one', __( 'First Part', 'novixa-addons-for-elementor' ) );
			$this->register_part_style_controls( 'two', __( 'Second Part', 'novixa-addons-for-elementor' ) );
			$this->register_spacing_controls();
		}

		/**
		 * Content tab.
		 */
		protected function register_content_controls() {
			$this->start_controls_section(
				'novixa_section_heading_content',
				array(
					'label' => __( 'Heading', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_part_one_text',
				array(
					'label'       => __( 'First Part', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( 'Add Your', 'novixa-addons-for-elementor' ),
					'placeholder' => __( 'First part of the heading', 'novixa-addons-for-elementor' ),
					'label_block' => true,
				)
			);

			$this->add_control(
				'novixa_part_two_text',
				array(
					'label'       => __( 'Second Part', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( 'Heading Text', 'novixa-addons-for-elementor' ),
					'placeholder' => __( 'Second part of the heading', 'novixa-addons-for-elementor' ),
					'label_block' => true,
				)
			);

			$this->add_control(
				'novixa_layout',
				array(
					'label'   => __( 'Layout', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::SELECT,
					'options' => array(
						'inline' => __( 'Same Line', 'novixa-addons-for-elementor' ),
						'block'  => __( 'Second Part on New Line', 'novixa-addons-for-elementor' ),
					),
					'default'      => 'inline',
				)
			);

			$this->add_control(
				'novixa_link',
				array(
					'label'         => __( 'Link', 'novixa-addons-for-elementor' ),
					'type'          => Controls_Manager::URL,
					'placeholder'   => __( 'https://your-link.com', 'novixa-addons-for-elementor' ),
					'show_external' => true,
					'default'       => array(
						'url'         => '',
						'is_external' => false,
						'nofollow'    => false,
					),
				)
			);

			$this->add_control(
				'novixa_html_tag',
				array(
					'label'   => __( 'HTML Tag', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::SELECT,
					'options' => array(
						'h1'   => 'H1',
						'h2'   => 'H2',
						'h3'   => 'H3',
						'h4'   => 'H4',
						'h5'   => 'H5',
						'h6'   => 'H6',
						'div'  => 'div',
						'span' => 'span',
						'p'    => 'p',
					),
					'default' => 'h2',
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Heading section — properties shared by the whole
		 * heading (both parts): alignment, base typography (either part
		 * below can still override individual typography fields), text
		 * stroke/shadow, blend mode, and the gap between the two parts.
		 */
		protected function register_heading_style_controls() {
			$this->start_controls_section(
				'novixa_section_heading_style',
				array(
					'label' => __( 'Heading', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_responsive_control(
				'novixa_alignment',
				array(
					'label'     => __( 'Alignment', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::CHOOSE,
					'options'   => array(
						'left'    => array(
							'title' => __( 'Left', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-left',
						),
						'center'  => array(
							'title' => __( 'Center', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-center',
						),
						'right'   => array(
							'title' => __( 'Right', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-right',
						),
						'justify' => array(
							'title' => __( 'Justified', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-justify',
						),
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'dual-color-heading' )       => 'text-align: {{VALUE}};',
						'{{WRAPPER}} .' . $this->bem( 'dual-color-heading', 'title' ) => 'text-align: {{VALUE}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_gap',
				array(
					'label'     => __( 'Gap Between Parts', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 0,
							'max' => 60,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 8,
					),
					'condition' => array(
						'novixa_layout' => 'inline',
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'dual-color-heading', 'part-one' ) => 'margin-right: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'           => 'novixa_title_typography',
					'label'          => __( 'Typography (Both Parts)', 'novixa-addons-for-elementor' ),
					'selector'       => '{{WRAPPER}} .' . $this->bem( 'dual-color-heading', 'title' ),
					'fields_options' => array(
						'line_height' => array(
							'default' => array(
								'unit' => 'em',
								'size' => 1.2,
							),
						),
					),
				)
			);

			$this->add_group_control(
				Group_Control_Text_Stroke::get_type(),
				array(
					'name'     => 'novixa_title_stroke',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'dual-color-heading', 'title' ),
				)
			);

			$this->add_group_control(
				Group_Control_Text_Shadow::get_type(),
				array(
					'name'     => 'novixa_title_shadow',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'dual-color-heading', 'title' ),
				)
			);

			$this->register_blend_mode_control( 'novixa_title_blend_mode', '{{WRAPPER}} .' . $this->bem( 'dual-color-heading', 'title' ) );

			$this->end_controls_section();
		}

		/**
		 * Style tab > First/Second Part section — own typography override
		 * plus Normal/Hover color tabs, for one of the two text runs.
		 *
		 * @param string $part  'one' or 'two'.
		 * @param string $label Section label shown in the panel.
		 */
		protected function register_part_style_controls( $part, $label ) {
			$section_id = 'novixa_section_part_' . $part . '_style';
			$element    = 'part-' . $part;

			$this->start_controls_section(
				$section_id,
				array(
					'label' => $label,
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'     => 'novixa_part_' . $part . '_typography',
					'label'    => __( 'Typography Override', 'novixa-addons-for-elementor' ),
					'selector' => '{{WRAPPER}} .' . $this->bem( 'dual-color-heading', $element ),
				)
			);

			$this->start_controls_tabs( 'novixa_part_' . $part . '_color_tabs' );

			$this->start_controls_tab(
				'novixa_part_' . $part . '_color_normal',
				array( 'label' => __( 'Normal', 'novixa-addons-for-elementor' ) )
			);

			$this->add_control(
				'novixa_part_' . $part . '_color',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => ( 'two' === $part ) ? '#4f3ff0' : '',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'dual-color-heading', $element ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'novixa_part_' . $part . '_color_hover',
				array( 'label' => __( 'Hover', 'novixa-addons-for-elementor' ) )
			);

			$this->add_control(
				'novixa_part_' . $part . '_hover_color',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}}:hover .' . $this->bem( 'dual-color-heading', $element ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_part_' . $part . '_hover_transition',
				array(
					'label'     => __( 'Transition Duration', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'max'  => 3,
							'step' => 0.1,
						),
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'dual-color-heading', $element ) => 'transition-duration: {{SIZE}}s;',
					),
				)
			);

			$this->end_controls_tab();

			$this->end_controls_tabs();

			$this->end_controls_section();
		}

		/**
		 * Front-end render.
		 */
		protected function render() {
			$settings = $this->get_settings_for_display();

			$tag    = ! empty( $settings['novixa_html_tag'] ) ? $settings['novixa_html_tag'] : 'h2';
			$layout = ! empty( $settings['novixa_layout'] ) ? $settings['novixa_layout'] : 'inline';

			$this->add_render_attribute( 'novixa_title_wrap', 'class', $this->bem( 'dual-color-heading', 'title' ) );

			$has_link = ! empty( $settings['novixa_link']['url'] );

			if ( $has_link ) {
				$this->add_link_attributes( 'novixa_link', $settings['novixa_link'] );
			}

			$wrapper_class = $this->bem( 'dual-color-heading' ) . ' ' . $this->bem( 'dual-color-heading', '', 'layout-' . $layout );

			printf( '<div class="%1$s">', esc_attr( $wrapper_class ) );

			if ( $has_link ) {
				echo '<a ' . $this->get_render_attribute_string( 'novixa_link' ) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}

			printf(
				'<%1$s %2$s>',
				Utils::validate_html_tag( $tag ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				$this->get_render_attribute_string( 'novixa_title_wrap' ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			);

			printf(
				'<span class="%1$s">%2$s</span>',
				esc_attr( $this->bem( 'dual-color-heading', 'part-one' ) ),
				esc_html( $settings['novixa_part_one_text'] )
			);

			printf(
				'<span class="%1$s">%2$s</span>',
				esc_attr( $this->bem( 'dual-color-heading', 'part-two' ) ),
				esc_html( $settings['novixa_part_two_text'] )
			);

			printf( '</%1$s>', Utils::validate_html_tag( $tag ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

			if ( $has_link ) {
				echo '</a>';
			}

			echo '</div>';
		}

		/**
		 * Editor-side (JS) render template for a faster preview.
		 */
		protected function content_template() {
			?>
			<#
			var tag = settings.novixa_html_tag || 'h2';
			var layout = settings.novixa_layout || 'inline';
			var hasLink = settings.novixa_link && settings.novixa_link.url;
			#>
			<div class="novixa-addons-dual-color-heading novixa-addons-dual-color-heading--layout-{{ layout }}">
				<# if ( hasLink ) { #><a href="{{ settings.novixa_link.url }}"><# } #>
				<{{{ tag }}} class="novixa-addons-dual-color-heading__title">
					<span class="novixa-addons-dual-color-heading__part-one">{{{ settings.novixa_part_one_text }}}</span><span class="novixa-addons-dual-color-heading__part-two">{{{ settings.novixa_part_two_text }}}</span>
				</{{{ tag }}}>
				<# if ( hasLink ) { #></a><# } #>
			</div>
			<?php
		}
	}
}
