<?php
/**
 * Counter widget.
 *
 * @package Novixa_Addons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Icons_Manager;

if ( ! class_exists( 'Novixa_Addons_Widget_Counter' ) ) {

	/**
	 * Class Novixa_Addons_Widget_Counter
	 */
	class Novixa_Addons_Widget_Counter extends Novixa_Addons_Widget_Base {

		use Novixa_Addons_Global_Controls;

		/**
		 * Unique widget name registered with Elementor.
		 *
		 * @return string
		 */
		public function get_name() {
			return 'novixa-addons-counter';
		}

		/**
		 * Panel label.
		 *
		 * @return string
		 */
		public function get_title() {
			return __( 'Counter - Novixa', 'novixa-addons-for-elementor' );
		}

		/**
		 * Panel icon.
		 *
		 * @return string
		 */
		public function get_icon() {
			return 'eicon-counter';
		}

		/**
		 * Panel search keywords.
		 *
		 * @return array
		 */
		public function get_keywords() {
			return array_merge( $this->get_base_keywords(), array( 'counter', 'number', 'count up', 'stats', 'statistics' ) );
		}

		/**
		 * Script dependency — the count-up animation itself lives in
		 * assets/js/frontend.js (see the "Counter" section there),
		 * alongside this plugin's other shared front-end behaviour.
		 * Declaring it here (not just enqueuing it globally) is what
		 * makes Elementor reliably print it on the isolated AJAX
		 * request used to (re)render this widget while editing.
		 *
		 * @return array
		 */
		public function get_script_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Style dependency.
		 *
		 * @return array
		 */
		public function get_style_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Register all controls.
		 */
		protected function register_controls() {
			$this->register_content_controls();
			$this->register_box_style_controls();
			$this->register_icon_style_controls();
			$this->register_number_style_controls();
			$this->register_title_style_controls();
		}

		/**
		 * Content tab.
		 */
		protected function register_content_controls() {
			$this->start_controls_section(
				'novixa_section_counter_content',
				array(
					'label' => __( 'Counter', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_starting_number',
				array(
					'label'   => __( 'Starting Number', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::NUMBER,
					'default' => 0,
				)
			);

			$this->add_control(
				'novixa_ending_number',
				array(
					'label'   => __( 'Ending Number', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::NUMBER,
					'default' => 500,
				)
			);

			$this->add_control(
				'novixa_decimal_places',
				array(
					'label'   => __( 'Decimal Places', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::NUMBER,
					'min'     => 0,
					'max'     => 4,
					'default' => 0,
				)
			);

			$this->add_control(
				'novixa_thousands_separator',
				array(
					'label'        => __( 'Thousands Separator', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'yes',
				)
			);

			$this->add_control(
				'novixa_prefix',
				array(
					'label'       => __( 'Prefix', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => '',
					'placeholder' => '$',
					'label_block' => false,
				)
			);

			$this->add_control(
				'novixa_suffix',
				array(
					'label'       => __( 'Suffix', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => '+',
					'placeholder' => '%',
					'label_block' => false,
				)
			);

			$this->add_control(
				'novixa_title',
				array(
					'label'       => __( 'Title', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( 'Happy Clients', 'novixa-addons-for-elementor' ),
					'label_block' => true,
				)
			);

			$this->add_control(
				'novixa_duration',
				array(
					'label'     => __( 'Animation Duration (ms)', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min'  => 200,
							'max'  => 6000,
							'step' => 100,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 2000,
					),
				)
			);

			$this->add_control(
				'novixa_show_icon',
				array(
					'label'        => __( 'Show Icon', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'yes',
				)
			);

			$this->add_control(
				'novixa_icon',
				array(
					'label'       => __( 'Icon', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::ICONS,
					'default'     => array(
						'value'   => 'fas fa-users',
						'library' => 'fa-solid',
					),
					'skin'        => 'inline',
					'label_block' => false,
					'condition'   => array(
						'novixa_show_icon' => 'yes',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_icon_position',
				array(
					'label'                => __( 'Icon Position', 'novixa-addons-for-elementor' ),
					'type'                 => Controls_Manager::CHOOSE,
					'default'              => 'top',
					'options'              => array(
						'top'   => array(
							'title' => __( 'Top', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-v-align-top',
						),
						'left'  => array(
							'title' => __( 'Left', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-h-align-left',
						),
						'right' => array(
							'title' => __( 'Right', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-h-align-right',
						),
					),
					// Top keeps the icon stacked above the number/title
					// (the box stays a vertical flex column, as before).
					// Left/Right instead lay the icon out beside the
					// number+title block, so the box itself needs to
					// become a flex row (reversed for Right, so the
					// icon still ends up on the right visually).
					'selectors_dictionary' => array(
						'top'   => 'column',
						'left'  => 'row',
						'right' => 'row-reverse',
					),
					'selectors'            => array(
						'{{WRAPPER}} .' . $this->bem( 'counter' ) => 'flex-direction: {{VALUE}};',
					),
					'condition'            => array(
						'novixa_show_icon' => 'yes',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_content_alignment',
				array(
					'label'     => __( 'Alignment', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::CHOOSE,
					'default'   => 'center',
					'options'   => array(
						'left'   => array(
							'title' => __( 'Left', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-left',
						),
						'center' => array(
							'title' => __( 'Center', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-center',
						),
						'right'  => array(
							'title' => __( 'Right', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-right',
						),
					),
					'selectors_dictionary' => array(
						'left'   => 'flex-start',
						'center' => 'center',
						'right'  => 'flex-end',
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'counter' ) . ', {{WRAPPER}} .' . $this->bem( 'counter', 'content' ) => 'align-items: {{VALUE}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Box styling.
		 */
		protected function register_box_style_controls() {
			$this->start_controls_section(
				'novixa_section_box_style',
				array(
					'label' => __( 'Box', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_control(
				'novixa_box_bg_color',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'counter' ) => 'background: {{VALUE}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_box_padding',
				array(
					'label'      => __( 'Padding', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', 'em', '%' ),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'counter' ) => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_control(
				'novixa_box_border_radius',
				array(
					'label'      => __( 'Border Radius', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', '%' ),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'counter' ) => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Box_Shadow::get_type(),
				array(
					'name'     => 'novixa_box_shadow',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'counter' ),
				)
			);

			$this->add_control(
				'novixa_box_hover_lift',
				array(
					'label'        => __( 'Lift on Hover', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'return_value' => 'yes',
					'default'      => 'yes',
					'selectors'    => array(
						'{{WRAPPER}} .' . $this->bem( 'counter' ) . ':hover' => 'transform: translateY(-6px);',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Icon styling.
		 */
		protected function register_icon_style_controls() {
			$this->start_controls_section(
				'novixa_section_icon_style',
				array(
					'label'     => __( 'Icon', 'novixa-addons-for-elementor' ),
					'tab'       => Controls_Manager::TAB_STYLE,
					'condition' => array(
						'novixa_show_icon' => 'yes',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_icon_size',
				array(
					'label'     => __( 'Icon Size', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 10,
							'max' => 80,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 26,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'counter', 'icon' ) . ' i'   => 'font-size: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .' . $this->bem( 'counter', 'icon' ) . ' svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_icon_wrapper_size',
				array(
					'label'     => __( 'Icon Wrapper Size', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 30,
							'max' => 160,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 64,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'counter', 'icon' ) => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_control(
				'novixa_icon_color',
				array(
					'label'     => __( 'Icon Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#1a1608',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'counter', 'icon' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_icon_bg_color',
				array(
					'label'     => __( 'Background', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#d9b877',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'counter', 'icon' ) => 'background-color: {{VALUE}}; background-image: none;',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_icon_spacing',
				array(
					'label'     => __( 'Icon Spacing', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array( 'max' => 60 ),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 18,
					),
					// Using `gap` on the outer box (rather than a
					// margin on the icon itself) means this one control
					// keeps working correctly no matter which Icon
					// Position is chosen — vertical space when the icon
					// sits on Top, horizontal space when it's Left/Right.
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'counter' ) => 'gap: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Number styling.
		 */
		protected function register_number_style_controls() {
			$this->start_controls_section(
				'novixa_section_number_style',
				array(
					'label' => __( 'Number', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_control(
				'novixa_number_color',
				array(
					'label'     => __( 'Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#1a1a2e',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'counter', 'number-wrap' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'     => 'novixa_number_typography',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'counter', 'number-wrap' ),
				)
			);

			$this->add_responsive_control(
				'novixa_number_spacing',
				array(
					'label'     => __( 'Spacing (below number)', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array( 'max' => 40 ),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 8,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'counter', 'number-wrap' ) => 'margin-bottom: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Title styling.
		 */
		protected function register_title_style_controls() {
			$this->start_controls_section(
				'novixa_section_title_style',
				array(
					'label' => __( 'Title', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_control(
				'novixa_title_color',
				array(
					'label'     => __( 'Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#6a6a7a',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'counter', 'title' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'     => 'novixa_title_typography',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'counter', 'title' ),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Front-end render.
		 */
		protected function render() {
			$settings = $this->get_settings_for_display();

			$duration = ! empty( $settings['novixa_duration']['size'] ) ? (int) $settings['novixa_duration']['size'] : 2000;

			$this->add_render_attribute( 'novixa_number', 'class', $this->bem( 'counter', 'number' ) );
			$this->add_render_attribute( 'novixa_number', 'data-novixa-counter-start', (float) $settings['novixa_starting_number'] );
			$this->add_render_attribute( 'novixa_number', 'data-novixa-counter-end', (float) $settings['novixa_ending_number'] );
			$this->add_render_attribute( 'novixa_number', 'data-novixa-counter-decimals', (int) $settings['novixa_decimal_places'] );
			$this->add_render_attribute( 'novixa_number', 'data-novixa-counter-duration', $duration );
			$this->add_render_attribute( 'novixa_number', 'data-novixa-counter-separator', 'yes' === $settings['novixa_thousands_separator'] ? '1' : '0' );

			echo '<div class="' . esc_attr( $this->bem( 'counter' ) ) . '">';

			if ( 'yes' === $settings['novixa_show_icon'] && ! empty( $settings['novixa_icon']['value'] ) ) {
				echo '<div class="' . esc_attr( $this->bem( 'counter', 'icon' ) ) . '">';
				Icons_Manager::render_icon( $settings['novixa_icon'], array( 'aria-hidden' => 'true' ) );
				echo '</div>';
			}

			// Number + title are grouped in their own wrapper so the
			// Icon Position control (Top/Left/Right) can lay the icon
			// out beside this whole block instead of only above it —
			// see the flex-direction switch on .novixa-addons-counter
			// in register_content_controls().
			echo '<div class="' . esc_attr( $this->bem( 'counter', 'content' ) ) . '">';

			echo '<div class="' . esc_attr( $this->bem( 'counter', 'number-wrap' ) ) . '">';

			if ( '' !== $settings['novixa_prefix'] ) {
				echo '<span class="' . esc_attr( $this->bem( 'counter', 'prefix' ) ) . '">' . esc_html( $settings['novixa_prefix'] ) . '</span>';
			}

			printf(
				'<span %1$s>%2$s</span>',
				$this->get_render_attribute_string( 'novixa_number' ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				esc_html( $settings['novixa_starting_number'] )
			);

			if ( '' !== $settings['novixa_suffix'] ) {
				echo '<span class="' . esc_attr( $this->bem( 'counter', 'suffix' ) ) . '">' . esc_html( $settings['novixa_suffix'] ) . '</span>';
			}

			echo '</div>';

			if ( ! empty( $settings['novixa_title'] ) ) {
				printf(
					'<div class="%1$s">%2$s</div>',
					esc_attr( $this->bem( 'counter', 'title' ) ),
					esc_html( $settings['novixa_title'] )
				);
			}

			echo '</div>'; // .novixa-addons-counter__content

			echo '</div>';
		}
	}
}
