<?php
/**
 * Gradient Text Effect widget — a heading split into three text runs
 * (Beginning / Gradient / Ending), where the middle run gets a
 * two-color CSS gradient clipped to the text itself. Modeled on
 * Unlimited Elements' "Gradient Text Effect" widget.
 *
 * @package Novixa_Addons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Utils;

if ( ! class_exists( 'Novixa_Addons_Widget_Gradient_Text_Effect' ) ) {

	/**
	 * Class Novixa_Addons_Widget_Gradient_Text_Effect
	 */
	class Novixa_Addons_Widget_Gradient_Text_Effect extends Novixa_Addons_Widget_Base {

		/**
		 * Unique widget name registered with Elementor.
		 *
		 * @return string
		 */
		public function get_name() {
			return 'novixa-addons-gradient-text-effect';
		}

		/**
		 * Panel label.
		 *
		 * @return string
		 */
		public function get_title() {
			return __( 'Gradient Text Effect - Novixa', 'novixa-addons-for-elementor' );
		}

		/**
		 * Panel icon.
		 *
		 * @return string
		 */
		public function get_icon() {
			return 'eicon-t-letter';
		}

		/**
		 * Panel search keywords.
		 *
		 * @return array
		 */
		public function get_keywords() {
			return array_merge( $this->get_base_keywords(), array( 'gradient', 'text', 'heading', 'typography', 'color' ) );
		}

		/**
		 * Style dependency.
		 *
		 * @return array
		 */
		public function get_style_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Register all controls.
		 */
		protected function register_controls() {
			$this->register_content_controls();
			$this->register_beginning_style_controls();
			$this->register_gradient_style_controls();
			$this->register_ending_style_controls();
		}

		/**
		 * Content tab.
		 */
		protected function register_content_controls() {
			$this->start_controls_section(
				'novixa_section_content',
				array(
					'label' => __( 'Gradient Text', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_text_beginning',
				array(
					'label'       => __( 'Beginning Text', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( "Elevate Your Brand's ", 'novixa-addons-for-elementor' ),
					'label_block' => true,
					'dynamic'     => array( 'active' => true ),
				)
			);

			$this->add_control(
				'novixa_text_gradient',
				array(
					'label'       => __( 'Gradient Text', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( 'Online Presence', 'novixa-addons-for-elementor' ),
					'label_block' => true,
					'dynamic'     => array( 'active' => true ),
				)
			);

			$this->add_control(
				'novixa_text_ending',
				array(
					'label'       => __( 'Ending Text', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( ' In The Digital Era', 'novixa-addons-for-elementor' ),
					'label_block' => true,
					'dynamic'     => array( 'active' => true ),
				)
			);

			$this->add_control(
				'novixa_html_tag',
				array(
					'label'   => __( 'HTML Tag', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::SELECT,
					'options' => array(
						'h1'   => 'H1',
						'h2'   => 'H2',
						'h3'   => 'H3',
						'h4'   => 'H4',
						'h5'   => 'H5',
						'h6'   => 'H6',
						'div'  => 'div',
						'span' => 'span',
						'p'    => 'p',
					),
					'default' => 'h2',
				)
			);

			$this->add_responsive_control(
				'novixa_alignment',
				array(
					'label'     => __( 'Alignment', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::CHOOSE,
					'options'   => array(
						'left'    => array(
							'title' => __( 'Left', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-left',
						),
						'center'  => array(
							'title' => __( 'Center', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-center',
						),
						'right'   => array(
							'title' => __( 'Right', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-right',
						),
						'justify' => array(
							'title' => __( 'Justified', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-justify',
						),
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'gradient-text' ) => 'text-align: {{VALUE}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Beginning Text.
		 */
		protected function register_beginning_style_controls() {
			$this->start_controls_section(
				'novixa_section_beginning_style',
				array(
					'label'     => __( 'Beginning Text', 'novixa-addons-for-elementor' ),
					'tab'       => Controls_Manager::TAB_STYLE,
					'condition' => array(
						'novixa_text_beginning!' => '',
					),
				)
			);

			$this->add_control(
				'novixa_beginning_color',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#1a1a2e',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'gradient-text', 'beginning' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'     => 'novixa_beginning_typography',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'gradient-text', 'beginning' ),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Gradient Text.
		 */
		protected function register_gradient_style_controls() {
			$this->start_controls_section(
				'novixa_section_gradient_style',
				array(
					'label' => __( 'Gradient Text', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_control(
				'novixa_gradient_color_1',
				array(
					'label'     => __( 'Color 1', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#4f3ff0',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'gradient-text', 'gradient' ) => '--novixa-gradient-c1: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_gradient_color_2',
				array(
					'label'     => __( 'Color 2', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#b026ff',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'gradient-text', 'gradient' ) => '--novixa-gradient-c2: {{VALUE}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_gradient_angle',
				array(
					'label'     => __( 'Gradient Angle', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'deg' => array(
							'min' => 0,
							'max' => 360,
						),
					),
					'default'   => array(
						'unit' => 'deg',
						'size' => 90,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'gradient-text', 'gradient' ) => '--novixa-gradient-angle: {{SIZE}}deg;',
					),
				)
			);

			$this->add_control(
				'novixa_gradient_selection_color',
				array(
					'label'       => __( 'Selection Color', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::COLOR,
					'description' => __( 'The background color shown when a visitor selects/highlights the gradient text.', 'novixa-addons-for-elementor' ),
					'selectors'   => array(
						'{{WRAPPER}} .' . $this->bem( 'gradient-text', 'gradient' ) . '::selection' => 'background-color: {{VALUE}}; -webkit-text-fill-color: initial; color: initial;',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'     => 'novixa_gradient_typography',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'gradient-text', 'gradient' ),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Ending Text.
		 */
		protected function register_ending_style_controls() {
			$this->start_controls_section(
				'novixa_section_ending_style',
				array(
					'label'     => __( 'Ending Text', 'novixa-addons-for-elementor' ),
					'tab'       => Controls_Manager::TAB_STYLE,
					'condition' => array(
						'novixa_text_ending!' => '',
					),
				)
			);

			$this->add_control(
				'novixa_ending_color',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#1a1a2e',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'gradient-text', 'ending' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'     => 'novixa_ending_typography',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'gradient-text', 'ending' ),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Strip anything that isn't a plausible CSS color character —
		 * defensive only, since these values are written straight into
		 * an inline stylesheet rule below without further escaping.
		 *
		 * @param string $color Raw color value.
		 * @return string
		 */
		private function safe_color( $color ) {
			return preg_replace( '/[^a-zA-Z0-9#(),.%\s\-]/', '', (string) $color );
		}

		/**
		 * Front-end render.
		 *
		 * The gradient itself is printed as a small scoped <style>
		 * block keyed to this instance's own id, in addition to the
		 * CSS custom properties set by the style controls' `selectors`
		 * (which give an instant live-preview in the editor). Two
		 * defenses layered together: if the external frontend.css file
		 * hasn't (re)loaded for any reason, the gradient still renders
		 * from real computed values here rather than falling back to
		 * invisible transparent text with no gradient behind it. An
		 * `@supports` fallback also sets a plain solid color for the
		 * rare browser without background-clip: text support, so the
		 * text is never actually invisible.
		 */
		protected function render() {
			$settings = $this->get_settings_for_display();

			$tag = ! empty( $settings['novixa_html_tag'] ) ? $settings['novixa_html_tag'] : 'h2';
			$uid = 'novixa-gradient-text-' . esc_attr( $this->get_id() );

			$color_1 = ! empty( $settings['novixa_gradient_color_1'] ) ? $this->safe_color( $settings['novixa_gradient_color_1'] ) : '#4f3ff0';
			$color_2 = ! empty( $settings['novixa_gradient_color_2'] ) ? $this->safe_color( $settings['novixa_gradient_color_2'] ) : '#b026ff';
			$angle   = ( isset( $settings['novixa_gradient_angle']['size'] ) && '' !== $settings['novixa_gradient_angle']['size'] )
				? (float) $settings['novixa_gradient_angle']['size']
				: 90;

			$color_1_var = 'var(--novixa-gradient-c1, ' . $color_1 . ')';
			$color_2_var = 'var(--novixa-gradient-c2, ' . $color_2 . ')';
			$angle_var   = 'var(--novixa-gradient-angle, ' . $angle . 'deg)';

			$scoped_css = sprintf(
				'#%1$s .%2$s{background-image:linear-gradient(%3$s,%4$s,%5$s)!important;-webkit-background-clip:text!important;background-clip:text!important;-webkit-text-fill-color:transparent!important;color:transparent!important;}'
				. '@supports not (background-clip: text){#%1$s .%2$s{color:%4$s!important;-webkit-text-fill-color:%4$s!important;}}',
				esc_attr( $uid ),
				esc_attr( $this->bem( 'gradient-text', 'gradient' ) ),
				esc_attr( $angle_var ),
				esc_attr( $color_1_var ),
				esc_attr( $color_2_var )
			);

			echo '<style>' . $scoped_css . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $scoped_css is built entirely from esc_attr()-passed values above, no raw user HTML.

			printf( '<%1$s id="%2$s" class="%3$s">', Utils::validate_html_tag( $tag ), esc_attr( $uid ), esc_attr( $this->bem( 'gradient-text' ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

			if ( ! empty( $settings['novixa_text_beginning'] ) ) {
				printf(
					'<span class="%1$s">%2$s</span>',
					esc_attr( $this->bem( 'gradient-text', 'beginning' ) ),
					esc_html( $settings['novixa_text_beginning'] )
				);
			}

			if ( ! empty( $settings['novixa_text_gradient'] ) ) {
				printf(
					'<span class="%1$s">%2$s</span>',
					esc_attr( $this->bem( 'gradient-text', 'gradient' ) ),
					esc_html( $settings['novixa_text_gradient'] )
				);
			}

			if ( ! empty( $settings['novixa_text_ending'] ) ) {
				printf(
					'<span class="%1$s">%2$s</span>',
					esc_attr( $this->bem( 'gradient-text', 'ending' ) ),
					esc_html( $settings['novixa_text_ending'] )
				);
			}

			echo '</' . Utils::validate_html_tag( $tag ) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		/**
		 * Editor live-preview template. The gradient itself doesn't need
		 * its own inline <style> block here — the base
		 * ".novixa-addons-gradient-text__gradient" class in frontend.css
		 * already paints the gradient from the same CSS custom
		 * properties ("--novixa-gradient-c1/c2/angle") that the Color 1 /
		 * Color 2 / Angle controls write live via their own `selectors`,
		 * so this only needs to reproduce the markup.
		 */
		protected function content_template() {
			?>
			<#
			var tag = settings.novixa_html_tag || 'h2';
			#>
			<{{{ tag }}} class="novixa-addons-gradient-text">
				<# if ( settings.novixa_text_beginning ) { #>
				<span class="novixa-addons-gradient-text__beginning">{{{ settings.novixa_text_beginning }}}</span>
				<# } #>
				<# if ( settings.novixa_text_gradient ) { #>
				<span class="novixa-addons-gradient-text__gradient">{{{ settings.novixa_text_gradient }}}</span>
				<# } #>
				<# if ( settings.novixa_text_ending ) { #>
				<span class="novixa-addons-gradient-text__ending">{{{ settings.novixa_text_ending }}}</span>
				<# } #>
			</{{{ tag }}}>
			<?php
		}
	}
}
