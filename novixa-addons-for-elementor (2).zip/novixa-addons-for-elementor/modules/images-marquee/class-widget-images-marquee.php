<?php
/**
 * Images Marquee widget.
 *
 * An infinitely-scrolling gallery strip of plain images — a photo wall,
 * portfolio strip, or "as seen in" band — rendered directly (no card
 * frame), unlike the Logo Marquee widget which wraps each item in a
 * white card. Uses the exact same seamless-loop technique as List
 * Marquee / Logo Marquee: the image list is rendered twice back to
 * back inside a wider (or taller, in Vertical mode) flex track, which
 * then animates `translate(0 -> -50%)` on a linear infinite loop, so
 * the moment the first copy has scrolled fully out of view the second
 * copy is sitting exactly where the first one started.
 *
 * @package Novixa_Addons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Utils;

if ( ! class_exists( 'Novixa_Addons_Widget_Images_Marquee' ) ) {

	/**
	 * Class Novixa_Addons_Widget_Images_Marquee
	 */
	class Novixa_Addons_Widget_Images_Marquee extends Novixa_Addons_Widget_Base {

		use Novixa_Addons_Global_Controls;

		/**
		 * Unique widget name registered with Elementor.
		 *
		 * @return string
		 */
		public function get_name() {
			return 'novixa-addons-images-marquee';
		}

		/**
		 * Panel label.
		 *
		 * @return string
		 */
		public function get_title() {
			return __( 'Images Marquee - Novixa', 'novixa-addons-for-elementor' );
		}

		/**
		 * Panel icon.
		 *
		 * @return string
		 */
		public function get_icon() {
			return 'eicon-gallery-grid';
		}

		/**
		 * Panel search keywords.
		 *
		 * @return array
		 */
		public function get_keywords() {
			return array_merge( $this->get_base_keywords(), array( 'images', 'photo', 'gallery', 'marquee', 'carousel', 'ticker', 'scrolling', 'strip' ) );
		}

		/**
		 * Script dependency — the animation itself is pure CSS; the
		 * shared frontend.js is only needed for the reduced-motion /
		 * editor-safety plumbing every other widget already loads.
		 *
		 * @return array
		 */
		public function get_script_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Style dependency.
		 *
		 * @return array
		 */
		public function get_style_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Register all controls.
		 */
		protected function register_controls() {
			$this->register_content_controls();
			$this->register_track_style_controls();
			$this->register_image_style_controls();
			$this->register_caption_style_controls();
		}

		/**
		 * Content tab.
		 */
		protected function register_content_controls() {
			$this->start_controls_section(
				'novixa_section_images_marquee_content',
				array(
					'label' => __( 'Images Marquee', 'novixa-addons-for-elementor' ),
				)
			);

			$repeater = new Repeater();

			$repeater->add_control(
				'novixa_image',
				array(
					'label'   => __( 'Image', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::MEDIA,
					'default' => array(
						'url' => Utils::get_placeholder_image_src(),
					),
				)
			);

			$repeater->add_control(
				'novixa_image_caption',
				array(
					'label'       => __( 'Caption (optional)', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => '',
					'label_block' => true,
				)
			);

			$repeater->add_control(
				'novixa_image_link',
				array(
					'label'       => __( 'Link (optional)', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::URL,
					'default'     => array(
						'url' => '',
					),
					'label_block' => true,
				)
			);

			$this->add_control(
				'novixa_images',
				array(
					'label'       => __( 'Images', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::REPEATER,
					'fields'      => $repeater->get_controls(),
					'default'     => array(
						array(),
						array(),
						array(),
						array(),
						array(),
						array(),
					),
					'title_field' => '{{{ novixa_image_caption || "Image" }}}',
				)
			);

			$this->add_control(
				'novixa_show_caption',
				array(
					'label'        => __( 'Show Caption', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => '',
					'description'  => __( 'Show each image\'s Caption field (above) underneath it.', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_responsive_control(
				'novixa_items_to_show',
				array(
					'label'       => __( 'Items to Show', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::NUMBER,
					'min'         => 1,
					'placeholder' => __( 'All', 'novixa-addons-for-elementor' ),
					'description' => __( 'Limit how many images are shown on this device. Leave empty to show all of them. The marquee keeps looping normally either way.', 'novixa-addons-for-elementor' ),
					// No 'selectors' here on purpose — the CSS for this one
					// is hand-built in render_items_limit_style() instead
					// of letting Elementor auto-generate it. Reason: the
					// hide-all-then-reveal-first-N technique needs a raw
					// integer inside :nth-child(-n+N), and Elementor's
					// {{VALUE}} placeholder substitution inside a pseudo-
					// class function argument isn't reliable for every
					// control/version combination. Building the CSS
					// ourselves guarantees a valid, literal number.
				)
			);

			$this->add_control(
				'novixa_speed',
				array(
					'label'       => __( 'Speed (seconds per loop)', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::SLIDER,
					'range'       => array(
						'px' => array(
							'min' => 5,
							'max' => 120,
						),
					),
					'default'     => array(
						'unit' => 'px',
						'size' => 35,
					),
					'description' => __( 'Lower is faster, higher is slower.', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_orientation',
				array(
					'label'   => __( 'Orientation', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'horizontal',
					'options' => array(
						'horizontal' => __( 'Horizontal', 'novixa-addons-for-elementor' ),
						'vertical'   => __( 'Vertical', 'novixa-addons-for-elementor' ),
					),
				)
			);

			$this->add_control(
				'novixa_direction',
				array(
					'label'     => __( 'Direction', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::CHOOSE,
					'default'   => 'left',
					'options'   => array(
						'left'  => array(
							'title' => __( 'Right to Left', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-arrow-left',
						),
						'right' => array(
							'title' => __( 'Left to Right', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-arrow-right',
						),
					),
					'condition' => array(
						'novixa_orientation' => 'horizontal',
					),
				)
			);

			$this->add_control(
				'novixa_direction_vertical',
				array(
					'label'     => __( 'Direction', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::CHOOSE,
					'default'   => 'down',
					'options'   => array(
						'down' => array(
							'title' => __( 'Top to Bottom', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-arrow-down',
						),
						'up'   => array(
							'title' => __( 'Bottom to Top', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-arrow-up',
						),
					),
					'condition' => array(
						'novixa_orientation' => 'vertical',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_track_height',
				array(
					'label'       => __( 'Track Height', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::SLIDER,
					'range'       => array(
						'px' => array(
							'min' => 150,
							'max' => 900,
						),
					),
					'default'     => array(
						'unit' => 'px',
						'size' => 420,
					),
					'condition'   => array(
						'novixa_orientation' => 'vertical',
					),
					'description' => __( 'A vertical marquee needs a fixed viewport height to scroll inside of.', 'novixa-addons-for-elementor' ),
					'selectors'   => array(
						'{{WRAPPER}} .' . $this->bem( 'images-marquee' ) => 'height: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_control(
				'novixa_pause_on_hover',
				array(
					'label'        => __( 'Pause on Hover', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'yes',
				)
			);

			$this->add_control(
				'novixa_grayscale_hover',
				array(
					'label'        => __( 'Grayscale until Hover', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => '',
					'description'  => __( 'Renders every image in grayscale, restoring full color when that image is hovered.', 'novixa-addons-for-elementor' ),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Track (outer strip) styling.
		 */
		protected function register_track_style_controls() {
			$this->start_controls_section(
				'novixa_section_track_style',
				array(
					'label' => __( 'Track', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_control(
				'novixa_track_bg_color',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'images-marquee' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_track_padding',
				array(
					'label'      => __( 'Padding', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', 'em', '%' ),
					'default'    => array(
						'top'      => 0,
						'right'    => 0,
						'bottom'   => 0,
						'left'     => 0,
						'unit'     => 'px',
						'isLinked' => true,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'images-marquee' ) => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_control(
				'novixa_track_border_radius',
				array(
					'label'      => __( 'Border Radius', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', '%' ),
					'default'    => array(
						'top'      => 0,
						'right'    => 0,
						'bottom'   => 0,
						'left'     => 0,
						'unit'     => 'px',
						'isLinked' => true,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'images-marquee' ) => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_control(
				'novixa_edge_fade',
				array(
					'label'        => __( 'Edge Fade', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => '',
					'description'  => __( 'Softly fades the leading/trailing edges of the track. Leave off for a clean, hard edge.', 'novixa-addons-for-elementor' ),
					'separator'    => 'before',
				)
			);

			$this->add_responsive_control(
				'novixa_image_gap',
				array(
					'label'     => __( 'Gap Between Images', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array( 'max' => 100 ),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 16,
					),
					// Also sets `padding-right` (equal to the gap) on the
					// same element on purpose — see the file-level comment
					// at the top of this class for why the seamless loop
					// depends on both copies of the track being an equal
					// total size, trailing space included. When switched
					// to Vertical orientation, the second (more specific)
					// selector below takes over and drives `padding-bottom`
					// instead, for the same reason along the vertical axis.
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'images-marquee', 'group' ) => 'gap: {{SIZE}}{{UNIT}}; padding-right: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .' . $this->bem( 'images-marquee' ) . '--vertical .' . $this->bem( 'images-marquee', 'group' ) => 'padding-right: 0; padding-bottom: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Image styling.
		 */
		protected function register_image_style_controls() {
			$this->start_controls_section(
				'novixa_section_image_style',
				array(
					'label' => __( 'Image', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_responsive_control(
				'novixa_image_width',
				array(
					'label'      => __( 'Width', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => array( 'px', 'em', '%' ),
					'range'      => array(
						'px' => array(
							'min' => 40,
							'max' => 800,
						),
						'em' => array(
							'min' => 2,
							'max' => 50,
						),
						'%'  => array(
							'min' => 5,
							'max' => 100,
						),
					),
					'default'    => array(
						'unit' => 'px',
						'size' => 260,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'images-marquee', 'frame' ) => 'width: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_image_height',
				array(
					'label'      => __( 'Height', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => array( 'px', 'em', '%' ),
					'range'      => array(
						'px' => array(
							'min' => 40,
							'max' => 800,
						),
						'em' => array(
							'min' => 2,
							'max' => 50,
						),
						'%'  => array(
							'min' => 5,
							'max' => 100,
						),
					),
					'default'    => array(
						'unit' => 'px',
						'size' => 180,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'images-marquee', 'frame' ) => 'height: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_control(
				'novixa_image_object_fit',
				array(
					'label'     => __( 'Object Fit', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SELECT,
					'default'   => 'cover',
					'options'   => array(
						'cover'   => __( 'Cover', 'novixa-addons-for-elementor' ),
						'contain' => __( 'Contain', 'novixa-addons-for-elementor' ),
						'fill'    => __( 'Fill', 'novixa-addons-for-elementor' ),
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'images-marquee', 'frame' ) . ' img' => 'object-fit: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_image_border_radius',
				array(
					'label'      => __( 'Border Radius', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', '%' ),
					'default'    => array(
						'top'      => 12,
						'right'    => 12,
						'bottom'   => 12,
						'left'     => 12,
						'unit'     => 'px',
						'isLinked' => true,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'images-marquee', 'frame' ) => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Border::get_type(),
				array(
					'name'     => 'novixa_image_border',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'images-marquee', 'frame' ),
				)
			);

			$this->add_group_control(
				Group_Control_Box_Shadow::get_type(),
				array(
					'name'     => 'novixa_image_shadow',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'images-marquee', 'frame' ),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Caption styling.
		 */
		protected function register_caption_style_controls() {
			$this->start_controls_section(
				'novixa_section_caption_style',
				array(
					'label'     => __( 'Caption', 'novixa-addons-for-elementor' ),
					'tab'       => Controls_Manager::TAB_STYLE,
					'condition' => array(
						'novixa_show_caption' => 'yes',
					),
				)
			);

			$this->add_control(
				'novixa_caption_color',
				array(
					'label'     => __( 'Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#4a4a4a',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'images-marquee', 'caption' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_caption_font_size',
				array(
					'label'     => __( 'Font Size', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 8,
							'max' => 30,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 13,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'images-marquee', 'caption' ) => 'font-size: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Render one image + optional caption.
		 *
		 * @param array $image    Repeater row.
		 * @param array $settings Widget settings.
		 */
		private function render_frame( $image, $settings ) {
			$has_link = ! empty( $image['novixa_image_link']['url'] );
			$tag      = $has_link ? 'a' : 'div';

			echo '<div class="' . esc_attr( $this->bem( 'images-marquee', 'item' ) ) . '">';

			echo '<' . esc_attr( $tag ) . ' class="' . esc_attr( $this->bem( 'images-marquee', 'frame' ) ) . '"';

			if ( $has_link ) {
				echo ' href="' . esc_url( $image['novixa_image_link']['url'] ) . '"';
				if ( ! empty( $image['novixa_image_link']['is_external'] ) ) {
					echo ' target="_blank"';
				}
				if ( ! empty( $image['novixa_image_link']['nofollow'] ) ) {
					echo ' rel="nofollow"';
				}
			}

			echo '>';

			if ( ! empty( $image['novixa_image']['url'] ) ) {
				echo '<img src="' . esc_url( $image['novixa_image']['url'] ) . '" alt="' . esc_attr( $image['novixa_image_caption'] ) . '" loading="lazy" />';
			}

			echo '</' . esc_attr( $tag ) . '>';

			if ( 'yes' === $settings['novixa_show_caption'] && '' !== $image['novixa_image_caption'] ) {
				echo '<div class="' . esc_attr( $this->bem( 'images-marquee', 'caption' ) ) . '">' . esc_html( $image['novixa_image_caption'] ) . '</div>';
			}

			echo '</div>';
		}

		/**
		 * Render one full copy of the image list.
		 *
		 * @param array $settings    Widget settings.
		 * @param bool  $aria_hidden Whether this copy should be hidden from assistive tech (the duplicate track).
		 */
		private function render_group( $settings, $aria_hidden = false ) {
			printf(
				'<div class="%1$s"%2$s>',
				esc_attr( $this->bem( 'images-marquee', 'group' ) ),
				$aria_hidden ? ' aria-hidden="true"' : ''
			);

			foreach ( $settings['novixa_images'] as $image ) {
				$this->render_frame( $image, $settings );
			}

			echo '</div>';
		}

		/**
		 * Echo a small inline <style> block that limits how many image
		 * frames are visible per breakpoint. Built by hand (rather than
		 * via a control's 'selectors') so the number inside
		 * :nth-child(-n+N) is always a plain literal integer — see the
		 * comment on the "Items to Show" control for why.
		 *
		 * @param array $settings Widget settings.
		 */
		private function render_items_limit_style( $settings ) {
			$desktop = ( isset( $settings['novixa_items_to_show'] ) && '' !== $settings['novixa_items_to_show'] ) ? absint( $settings['novixa_items_to_show'] ) : 0;
			$tablet  = ( isset( $settings['novixa_items_to_show_tablet'] ) && '' !== $settings['novixa_items_to_show_tablet'] ) ? absint( $settings['novixa_items_to_show_tablet'] ) : 0;
			$mobile  = ( isset( $settings['novixa_items_to_show_mobile'] ) && '' !== $settings['novixa_items_to_show_mobile'] ) ? absint( $settings['novixa_items_to_show_mobile'] ) : 0;

			if ( ! $desktop && ! $tablet && ! $mobile ) {
				return;
			}

			// Every Elementor widget instance is already wrapped in an
			// ".elementor-element-{id}" class, so we can scope our CSS
			// to just this widget without touching our own markup.
			$scope    = '.elementor-element-' . $this->get_id();
			$selector = $scope . ' .' . $this->bem( 'images-marquee', 'item' );

			$tablet_bp = 1024;
			$mobile_bp = 767;

			if ( class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->breakpoints ) ) {
				$breakpoints = \Elementor\Plugin::$instance->breakpoints->get_breakpoints();
				if ( ! empty( $breakpoints['tablet'] ) && method_exists( $breakpoints['tablet'], 'get_value' ) ) {
					$tablet_bp = (int) $breakpoints['tablet']->get_value();
				}
				if ( ! empty( $breakpoints['mobile'] ) && method_exists( $breakpoints['mobile'], 'get_value' ) ) {
					$mobile_bp = (int) $breakpoints['mobile']->get_value();
				}
			}

			$css = '';

			if ( $desktop ) {
				$css .= $selector . '{display:none;}' . $selector . ':nth-child(-n+' . $desktop . '){display:flex;}';
			}
			if ( $tablet ) {
				$css .= '@media(max-width:' . $tablet_bp . 'px){' . $selector . '{display:none;}' . $selector . ':nth-child(-n+' . $tablet . '){display:flex;}}';
			}
			if ( $mobile ) {
				$css .= '@media(max-width:' . $mobile_bp . 'px){' . $selector . '{display:none;}' . $selector . ':nth-child(-n+' . $mobile . '){display:flex;}}';
			}

			if ( '' !== $css ) {
				// Every byte above is either a hard-coded string or an
				// absint()'d number — nothing user-supplied is echoed raw.
				echo '<style>' . $css . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		}

		/**
		 * Front-end render.
		 */
		protected function render() {
			$settings = $this->get_settings_for_display();

			if ( empty( $settings['novixa_images'] ) ) {
				return;
			}

			$this->render_items_limit_style( $settings );

			$speed = ! empty( $settings['novixa_speed']['size'] ) ? (float) $settings['novixa_speed']['size'] : 35;

			$wrapper_classes = array( $this->bem( 'images-marquee' ) );
			if ( 'yes' === $settings['novixa_pause_on_hover'] ) {
				$wrapper_classes[] = $this->bem( 'images-marquee' ) . '--pause-on-hover';
			}

			$is_vertical = 'vertical' === $settings['novixa_orientation'];

			if ( $is_vertical ) {
				$wrapper_classes[] = $this->bem( 'images-marquee' ) . '--vertical';
				if ( 'up' === $settings['novixa_direction_vertical'] ) {
					$wrapper_classes[] = $this->bem( 'images-marquee' ) . '--reverse';
				}
			} elseif ( 'right' === $settings['novixa_direction'] ) {
				$wrapper_classes[] = $this->bem( 'images-marquee' ) . '--reverse';
			}

			if ( 'yes' === $settings['novixa_grayscale_hover'] ) {
				$wrapper_classes[] = $this->bem( 'images-marquee' ) . '--grayscale-hover';
			}
			if ( 'yes' === $settings['novixa_edge_fade'] ) {
				$wrapper_classes[] = $this->bem( 'images-marquee' ) . '--edge-fade';
			}

			printf(
				'<div class="%1$s" style="--novixa-marquee-duration: %2$ss;">',
				esc_attr( implode( ' ', $wrapper_classes ) ),
				esc_attr( $speed )
			);

			echo '<div class="' . esc_attr( $this->bem( 'images-marquee', 'track' ) ) . '">';

			// Rendered twice back-to-back for the seamless-loop trick —
			// see the file-level comment at the top of this class. The
			// second copy is aria-hidden so screen readers only announce
			// the image list once.
			$this->render_group( $settings, false );
			$this->render_group( $settings, true );

			echo '</div>';

			echo '</div>';
		}
	}
}
