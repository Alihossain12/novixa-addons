<?php
/**
 * Numbered Feature Box widget — a dark card with a colored icon badge
 * top-left, a large faint step number top-right, a bold title and a
 * short description underneath. Built for numbered feature/benefit
 * grids (e.g. "01 Transparent Pricing", "02 Fast Turnaround" ...).
 *
 * @package Novixa_Addons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Icons_Manager;

if ( ! class_exists( 'Novixa_Addons_Widget_Numbered_Feature_Box' ) ) {

	/**
	 * Class Novixa_Addons_Widget_Numbered_Feature_Box
	 */
	class Novixa_Addons_Widget_Numbered_Feature_Box extends Novixa_Addons_Widget_Base {

		use Novixa_Addons_Global_Controls;

		/**
		 * Unique widget name registered with Elementor.
		 *
		 * @return string
		 */
		public function get_name() {
			return 'novixa-addons-numbered-feature-box';
		}

		/**
		 * Panel label.
		 *
		 * @return string
		 */
		public function get_title() {
			return __( 'Numbered Feature Box - Novixa', 'novixa-addons-for-elementor' );
		}

		/**
		 * Panel icon.
		 *
		 * @return string
		 */
		public function get_icon() {
			return 'eicon-editor-list-ol';
		}

		/**
		 * Panel search keywords.
		 *
		 * @return array
		 */
		public function get_keywords() {
			return array_merge( $this->get_base_keywords(), array( 'number', 'step', 'feature', 'benefit', 'service', 'icon box', 'card' ) );
		}

		/**
		 * Style dependency.
		 *
		 * @return array
		 */
		public function get_style_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Register all controls.
		 */
		protected function register_controls() {
			$this->register_content_controls();
			$this->register_card_style_controls();
			$this->register_icon_style_controls();
			$this->register_number_style_controls();
			$this->register_title_style_controls();
			$this->register_description_style_controls();
			$this->register_flip_style_controls();
		}

		/**
		 * Content tab.
		 */
		protected function register_content_controls() {
			$this->start_controls_section(
				'novixa_section_content',
				array(
					'label' => __( 'Numbered Feature Box', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_style',
				array(
					'label'       => __( 'Style', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::SELECT,
					'default'     => 'default',
					'options'     => array(
						'default'    => __( 'Default', 'novixa-addons-for-elementor' ),
						'flip-left'  => __( 'Flip (Reveal from Left)', 'novixa-addons-for-elementor' ),
						'flip-right' => __( 'Flip (Reveal from Right)', 'novixa-addons-for-elementor' ),
						'flip-top'   => __( 'Flip (Reveal from Top)', 'novixa-addons-for-elementor' ),
						'flip-bottom' => __( 'Flip (Reveal from Bottom)', 'novixa-addons-for-elementor' ),
					),
					'description' => __( 'Switches the whole card look. The Flip options slide a second panel of its own icon/title/description over the card from the chosen edge on hover. Colors set below still apply on top of whichever style is picked.', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_icon',
				array(
					'label'       => __( 'Icon', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::ICONS,
					'default'     => array(
						'value'   => 'fas fa-wallet',
						'library' => 'fa-solid',
					),
					'skin'        => 'inline',
					'label_block' => false,
				)
			);

			$this->add_control(
				'novixa_number',
				array(
					'label'       => __( 'Number', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => '01',
					'label_block' => false,
					'dynamic'     => array( 'active' => true ),
				)
			);

			$this->add_control(
				'novixa_title',
				array(
					'label'       => __( 'Title', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( 'Transparent Pricing', 'novixa-addons-for-elementor' ),
					'label_block' => true,
					'dynamic'     => array( 'active' => true ),
				)
			);

			$this->add_control(
				'novixa_title_tag',
				array(
					'label'   => __( 'Title HTML Tag', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'h3',
					'options' => array(
						'h1'   => 'H1',
						'h2'   => 'H2',
						'h3'   => 'H3',
						'h4'   => 'H4',
						'h5'   => 'H5',
						'h6'   => 'H6',
						'div'  => 'div',
						'span' => 'span',
						'p'    => 'p',
					),
				)
			);

			$this->add_control(
				'novixa_description',
				array(
					'label'       => __( 'Description', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXTAREA,
					'default'     => __( 'We offer fair, transparent pricing with no hidden fees, and a free quote before every job.', 'novixa-addons-for-elementor' ),
					'label_block' => true,
					'rows'        => 4,
					'dynamic'     => array( 'active' => true ),
				)
			);

			$this->register_alignment_control( 'novixa_content_alignment', '{{WRAPPER}} .' . $this->bem( 'numbered-feature-box' ) );

			$this->end_controls_section();

			$this->register_flip_content_controls();
		}

		/**
		 * Content tab > Back panel (only shown when Style = one of the Flip variants).
		 */
		protected function register_flip_content_controls() {
			$this->start_controls_section(
				'novixa_section_flip_content',
				array(
					'label'     => __( 'Back Panel (Flip)', 'novixa-addons-for-elementor' ),
					'condition' => array(
						'novixa_style' => array( 'flip-left', 'flip-right', 'flip-top', 'flip-bottom' ),
					),
				)
			);

			$this->add_control(
				'novixa_flip_icon',
				array(
					'label'       => __( 'Icon', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::ICONS,
					'default'     => array(
						'value'   => 'fas fa-check',
						'library' => 'fa-solid',
					),
					'skin'        => 'inline',
					'label_block' => false,
				)
			);

			$this->add_control(
				'novixa_flip_title',
				array(
					'label'       => __( 'Title', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( 'Transparent Pricing', 'novixa-addons-for-elementor' ),
					'label_block' => true,
					'dynamic'     => array( 'active' => true ),
				)
			);

			$this->add_control(
				'novixa_flip_description',
				array(
					'label'       => __( 'Description', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXTAREA,
					'default'     => __( 'No hidden fees. Every quote is itemized and explained before we start.', 'novixa-addons-for-elementor' ),
					'label_block' => true,
					'rows'        => 4,
					'dynamic'     => array( 'active' => true ),
				)
			);

			$this->add_responsive_control(
				'novixa_flip_content_alignment',
				array(
					'label'     => __( 'Alignment', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::CHOOSE,
					'default'   => 'flex-start',
					'options'   => array(
						'flex-start' => array(
							'title' => __( 'Left', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-left',
						),
						'center'     => array(
							'title' => __( 'Center', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-center',
						),
						'flex-end'   => array(
							'title' => __( 'Right', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-text-align-right',
						),
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box', 'back' ) => 'align-items: {{VALUE}}; text-align: {{VALUE}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Card.
		 */
		protected function register_card_style_controls() {
			$this->start_controls_section(
				'novixa_section_card_style',
				array(
					'label' => __( 'Card', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->start_controls_tabs( 'novixa_card_style_tabs' );

			$this->start_controls_tab(
				'novixa_card_style_normal',
				array( 'label' => __( 'Normal', 'novixa-addons-for-elementor' ) )
			);

			$this->add_control(
				'novixa_card_bg_color',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#1a1a2e',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'novixa_card_style_hover',
				array( 'label' => __( 'Hover', 'novixa-addons-for-elementor' ) )
			);

			$this->add_control(
				'novixa_card_bg_color_hover',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box' ) . ':hover' => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_card_border_color_hover',
				array(
					'label'     => __( 'Border Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box' ) . ':hover' => 'border-color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_tab();

			$this->end_controls_tabs();

			$this->add_responsive_control(
				'novixa_card_padding',
				array(
					'label'      => __( 'Padding', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', 'em', '%' ),
					'default'    => array(
						'top'      => 28,
						'right'    => 28,
						'bottom'   => 28,
						'left'     => 28,
						'unit'     => 'px',
						'isLinked' => true,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box' ) => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_control(
				'novixa_card_border_radius',
				array(
					'label'      => __( 'Border Radius', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', '%' ),
					'default'    => array(
						'top'      => 18,
						'right'    => 18,
						'bottom'   => 18,
						'left'     => 18,
						'unit'     => 'px',
						'isLinked' => true,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box' ) => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}; overflow: hidden;',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_card_min_height',
				array(
					'label'     => __( 'Minimum Height', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 100,
							'max' => 500,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 260,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box' ) => 'min-height: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Border::get_type(),
				array(
					'name'     => 'novixa_card_border',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'numbered-feature-box' ),
				)
			);

			$this->add_group_control(
				Group_Control_Box_Shadow::get_type(),
				array(
					'name'     => 'novixa_card_shadow',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'numbered-feature-box' ),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Icon badge.
		 */
		protected function register_icon_style_controls() {
			$this->start_controls_section(
				'novixa_section_icon_style',
				array(
					'label' => __( 'Icon', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->start_controls_tabs( 'novixa_icon_style_tabs' );

			$this->start_controls_tab(
				'novixa_icon_style_normal',
				array( 'label' => __( 'Normal', 'novixa-addons-for-elementor' ) )
			);

			$this->add_control(
				'novixa_icon_bg_color',
				array(
					'label'     => __( 'Badge Background', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#4f3ff0',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box', 'icon' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_icon_color',
				array(
					'label'     => __( 'Icon Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#ffffff',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box', 'icon' ) . ' i'   => 'color: {{VALUE}};',
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box', 'icon' ) . ' svg' => 'fill: {{VALUE}};',
					),
				)
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'novixa_icon_style_hover',
				array( 'label' => __( 'Hover', 'novixa-addons-for-elementor' ) )
			);

			$this->add_control(
				'novixa_icon_bg_color_hover',
				array(
					'label'     => __( 'Badge Background', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box' ) . ':hover .' . $this->bem( 'numbered-feature-box', 'icon' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_icon_color_hover',
				array(
					'label'     => __( 'Icon Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box' ) . ':hover .' . $this->bem( 'numbered-feature-box', 'icon' ) . ' i'   => 'color: {{VALUE}};',
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box' ) . ':hover .' . $this->bem( 'numbered-feature-box', 'icon' ) . ' svg' => 'fill: {{VALUE}};',
					),
				)
			);

			$this->end_controls_tab();

			$this->end_controls_tabs();

			$this->add_responsive_control(
				'novixa_icon_size',
				array(
					'label'     => __( 'Icon Size', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 12,
							'max' => 60,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 24,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box', 'icon' ) . ' i'   => 'font-size: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box', 'icon' ) . ' svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_icon_badge_size',
				array(
					'label'     => __( 'Badge Size', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 30,
							'max' => 120,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 56,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box', 'icon' ) => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_control(
				'novixa_icon_border_radius',
				array(
					'label'      => __( 'Badge Border Radius', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', '%' ),
					'default'    => array(
						'top'      => 14,
						'right'    => 14,
						'bottom'   => 14,
						'left'     => 14,
						'unit'     => 'px',
						'isLinked' => true,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box', 'icon' ) => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > the large faint step number.
		 */
		protected function register_number_style_controls() {
			$this->start_controls_section(
				'novixa_section_number_style',
				array(
					'label'     => __( 'Number', 'novixa-addons-for-elementor' ),
					'tab'       => Controls_Manager::TAB_STYLE,
					'condition' => array(
						'novixa_number!' => '',
					),
				)
			);

			$this->start_controls_tabs( 'novixa_number_style_tabs' );

			$this->start_controls_tab(
				'novixa_number_style_normal',
				array( 'label' => __( 'Normal', 'novixa-addons-for-elementor' ) )
			);

			$this->add_control(
				'novixa_number_color',
				array(
					'label'     => __( 'Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => 'rgba(255, 255, 255, 0.08)',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box', 'number' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'novixa_number_style_hover',
				array( 'label' => __( 'Hover', 'novixa-addons-for-elementor' ) )
			);

			$this->add_control(
				'novixa_number_color_hover',
				array(
					'label'     => __( 'Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box' ) . ':hover .' . $this->bem( 'numbered-feature-box', 'number' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_tab();

			$this->end_controls_tabs();

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'           => 'novixa_number_typography',
					'selector'       => '{{WRAPPER}} .' . $this->bem( 'numbered-feature-box', 'number' ),
					'fields_options' => array(
						'font_weight' => array(
							'default' => '800',
						),
						'font_size'   => array(
							'default' => array(
								'unit' => 'px',
								'size' => 48,
							),
						),
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Title.
		 */
		protected function register_title_style_controls() {
			$this->start_controls_section(
				'novixa_section_title_style',
				array(
					'label' => __( 'Title', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->start_controls_tabs( 'novixa_title_style_tabs' );

			$this->start_controls_tab(
				'novixa_title_style_normal',
				array( 'label' => __( 'Normal', 'novixa-addons-for-elementor' ) )
			);

			$this->add_control(
				'novixa_title_color',
				array(
					'label'     => __( 'Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#ffffff',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box', 'title' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'novixa_title_style_hover',
				array( 'label' => __( 'Hover', 'novixa-addons-for-elementor' ) )
			);

			$this->add_control(
				'novixa_title_color_hover',
				array(
					'label'     => __( 'Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box' ) . ':hover .' . $this->bem( 'numbered-feature-box', 'title' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_tab();

			$this->end_controls_tabs();

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'           => 'novixa_title_typography',
					'selector'       => '{{WRAPPER}} .' . $this->bem( 'numbered-feature-box', 'title' ),
					'fields_options' => array(
						'font_weight' => array(
							'default' => '700',
						),
						'font_size'   => array(
							'default' => array(
								'unit' => 'px',
								'size' => 20,
							),
						),
					),
				)
			);

			$this->add_responsive_control(
				'novixa_title_spacing_top',
				array(
					'label'     => __( 'Spacing Top', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 0,
							'max' => 60,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 24,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box', 'title' ) => 'margin-top: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Description.
		 */
		protected function register_description_style_controls() {
			$this->start_controls_section(
				'novixa_section_description_style',
				array(
					'label'     => __( 'Description', 'novixa-addons-for-elementor' ),
					'tab'       => Controls_Manager::TAB_STYLE,
					'condition' => array(
						'novixa_description!' => '',
					),
				)
			);

			$this->start_controls_tabs( 'novixa_description_style_tabs' );

			$this->start_controls_tab(
				'novixa_description_style_normal',
				array( 'label' => __( 'Normal', 'novixa-addons-for-elementor' ) )
			);

			$this->add_control(
				'novixa_description_color',
				array(
					'label'     => __( 'Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#c7c7c7',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box', 'description' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'novixa_description_style_hover',
				array( 'label' => __( 'Hover', 'novixa-addons-for-elementor' ) )
			);

			$this->add_control(
				'novixa_description_color_hover',
				array(
					'label'     => __( 'Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box' ) . ':hover .' . $this->bem( 'numbered-feature-box', 'description' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_tab();

			$this->end_controls_tabs();

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'           => 'novixa_description_typography',
					'selector'       => '{{WRAPPER}} .' . $this->bem( 'numbered-feature-box', 'description' ),
					'fields_options' => array(
						'font_size'   => array(
							'default' => array(
								'unit' => 'px',
								'size' => 15,
							),
						),
						'line_height' => array(
							'default' => array(
								'unit' => 'em',
								'size' => 1.7,
							),
						),
					),
				)
			);

			$this->add_responsive_control(
				'novixa_description_spacing_top',
				array(
					'label'     => __( 'Spacing Top', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 0,
							'max' => 40,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 12,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box', 'description' ) => 'margin-top: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Back panel (only shown when Style = one of the Flip variants).
		 */
		protected function register_flip_style_controls() {
			$this->start_controls_section(
				'novixa_section_flip_style',
				array(
					'label'     => __( 'Back Panel (Flip)', 'novixa-addons-for-elementor' ),
					'tab'       => Controls_Manager::TAB_STYLE,
					'condition' => array(
						'novixa_style' => array( 'flip-left', 'flip-right', 'flip-top', 'flip-bottom' ),
					),
				)
			);

			$this->add_control(
				'novixa_flip_bg_color',
				array(
					'label'     => __( 'Background Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#4f3ff0',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box', 'back' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_flip_icon_bg_color',
				array(
					'label'     => __( 'Icon Badge Background', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => 'rgba(255, 255, 255, 0.15)',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box', 'back-icon' ) => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_flip_icon_color',
				array(
					'label'     => __( 'Icon Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#ffffff',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box', 'back-icon' ) . ' i'   => 'color: {{VALUE}};',
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box', 'back-icon' ) . ' svg' => 'fill: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_flip_title_color',
				array(
					'label'     => __( 'Title Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#ffffff',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box', 'back-title' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_flip_description_color',
				array(
					'label'     => __( 'Description Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => 'rgba(255, 255, 255, 0.85)',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'numbered-feature-box', 'back-description' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Front-end render.
		 */
		protected function render() {
			$settings = $this->get_settings_for_display();

			$style         = ! empty( $settings['novixa_style'] ) ? $settings['novixa_style'] : 'default';
			$is_flip       = ( 0 === strpos( $style, 'flip-' ) );
			$wrapper_class = $this->bem( 'numbered-feature-box' );
			if ( 'default' !== $style ) {
				$wrapper_class .= ' ' . $this->bem( 'numbered-feature-box', '', 'style-' . $style );
			}

			printf( '<div class="%1$s">', esc_attr( $wrapper_class ) );

			if ( $is_flip ) {
				printf( '<div class="%1$s">', esc_attr( $this->bem( 'numbered-feature-box', 'front' ) ) );
			}

			printf( '<div class="%1$s">', esc_attr( $this->bem( 'numbered-feature-box', 'top-row' ) ) );

			if ( ! empty( $settings['novixa_icon']['value'] ) ) {
				printf( '<div class="%1$s">', esc_attr( $this->bem( 'numbered-feature-box', 'icon' ) ) );
				Icons_Manager::render_icon( $settings['novixa_icon'], array( 'aria-hidden' => 'true' ) );
				echo '</div>';
			}

			if ( '' !== $settings['novixa_number'] ) {
				printf(
					'<div class="%1$s">%2$s</div>',
					esc_attr( $this->bem( 'numbered-feature-box', 'number' ) ),
					esc_html( $settings['novixa_number'] )
				);
			}

			echo '</div>'; // .top-row

			if ( '' !== $settings['novixa_title'] ) {
				$title_tag = ! empty( $settings['novixa_title_tag'] ) ? $settings['novixa_title_tag'] : 'h3';
				printf(
					'<%1$s class="%2$s">%3$s</%1$s>',
					esc_attr( $title_tag ),
					esc_attr( $this->bem( 'numbered-feature-box', 'title' ) ),
					esc_html( $settings['novixa_title'] )
				);
			}

			if ( '' !== $settings['novixa_description'] ) {
				printf(
					'<div class="%1$s">%2$s</div>',
					esc_attr( $this->bem( 'numbered-feature-box', 'description' ) ),
					esc_html( $settings['novixa_description'] )
				);
			}

			if ( $is_flip ) {
				echo '</div>'; // .front

				printf( '<div class="%1$s">', esc_attr( $this->bem( 'numbered-feature-box', 'back' ) ) );

				if ( ! empty( $settings['novixa_flip_icon']['value'] ) ) {
					printf( '<div class="%1$s">', esc_attr( $this->bem( 'numbered-feature-box', 'back-icon' ) ) );
					Icons_Manager::render_icon( $settings['novixa_flip_icon'], array( 'aria-hidden' => 'true' ) );
					echo '</div>';
				}

				if ( '' !== $settings['novixa_flip_title'] ) {
					printf(
						'<div class="%1$s">%2$s</div>',
						esc_attr( $this->bem( 'numbered-feature-box', 'back-title' ) ),
						esc_html( $settings['novixa_flip_title'] )
					);
				}

				if ( '' !== $settings['novixa_flip_description'] ) {
					printf(
						'<div class="%1$s">%2$s</div>',
						esc_attr( $this->bem( 'numbered-feature-box', 'back-description' ) ),
						esc_html( $settings['novixa_flip_description'] )
					);
				}

				echo '</div>'; // .back
			}

			echo '</div>'; // .novixa-addons-numbered-feature-box
		}

		/**
		 * Editor live-preview template.
		 */
		protected function content_template() {
			?>
			<#
			var titleTag = settings.novixa_title_tag || 'h3';
			var style = settings.novixa_style || 'default';
			var isFlip = ( style.indexOf( 'flip-' ) === 0 );
			var wrapperClass = 'novixa-addons-numbered-feature-box';
			if ( style !== 'default' ) {
				wrapperClass += ' novixa-addons-numbered-feature-box--style-' + style;
			}
			#>
			<div class="{{ wrapperClass }}">
				<# if ( isFlip ) { #>
				<div class="novixa-addons-numbered-feature-box__front">
				<# } #>
				<div class="novixa-addons-numbered-feature-box__top-row">
					<# if ( settings.novixa_icon && settings.novixa_icon.value ) { #>
					<div class="novixa-addons-numbered-feature-box__icon">
						<# if ( settings.novixa_icon.library && settings.novixa_icon.library.indexOf( 'svg' ) < 0 ) { #>
						<i class="{{ settings.novixa_icon.value }}"></i>
						<# } #>
					</div>
					<# } #>
					<# if ( settings.novixa_number ) { #>
					<div class="novixa-addons-numbered-feature-box__number">{{{ settings.novixa_number }}}</div>
					<# } #>
				</div>
				<# if ( settings.novixa_title ) { #>
				<{{{ titleTag }}} class="novixa-addons-numbered-feature-box__title">{{{ settings.novixa_title }}}</{{{ titleTag }}}>
				<# } #>
				<# if ( settings.novixa_description ) { #>
				<div class="novixa-addons-numbered-feature-box__description">{{{ settings.novixa_description }}}</div>
				<# } #>
				<# if ( isFlip ) { #>
				</div>
				<div class="novixa-addons-numbered-feature-box__back">
					<# if ( settings.novixa_flip_icon && settings.novixa_flip_icon.value ) { #>
					<div class="novixa-addons-numbered-feature-box__back-icon">
						<# if ( settings.novixa_flip_icon.library && settings.novixa_flip_icon.library.indexOf( 'svg' ) < 0 ) { #>
						<i class="{{ settings.novixa_flip_icon.value }}"></i>
						<# } #>
					</div>
					<# } #>
					<# if ( settings.novixa_flip_title ) { #>
					<div class="novixa-addons-numbered-feature-box__back-title">{{{ settings.novixa_flip_title }}}</div>
					<# } #>
					<# if ( settings.novixa_flip_description ) { #>
					<div class="novixa-addons-numbered-feature-box__back-description">{{{ settings.novixa_flip_description }}}</div>
					<# } #>
				</div>
				<# } #>
			</div>
			<?php
		}
	}
}
