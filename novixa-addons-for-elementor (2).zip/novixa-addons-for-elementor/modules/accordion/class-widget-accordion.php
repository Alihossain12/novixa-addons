<?php
/**
 * Accordion widget — a simple, no-icon-box accordion with a
 * plus/minus (or any icon) indicator, modeled on Elementor's own
 * native Accordion widget. Each item's content is a WYSIWYG rich-text
 * field (see the note in the plugin's chat history: true drag-and-drop
 * nested widgets per item is a much deeper Elementor-core feature that
 * isn't practical to replicate in a third-party widget).
 *
 * Shares the same JS-driven, inline-style open/close mechanism as the
 * Icon Accordion widget (see modules/icon-accordion) — no CSS
 * specificity war possible, no `!important` needed.
 *
 * @package Novixa_Addons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Icons_Manager;
use Elementor\Utils;

if ( ! class_exists( 'Novixa_Addons_Widget_Accordion' ) ) {

	/**
	 * Class Novixa_Addons_Widget_Accordion
	 */
	class Novixa_Addons_Widget_Accordion extends Novixa_Addons_Widget_Base {

		/**
		 * Unique widget name registered with Elementor.
		 *
		 * @return string
		 */
		public function get_name() {
			return 'novixa-addons-accordion';
		}

		/**
		 * Panel label.
		 *
		 * @return string
		 */
		public function get_title() {
			return __( 'Accordion - Novixa', 'novixa-addons-for-elementor' );
		}

		/**
		 * Panel icon.
		 *
		 * @return string
		 */
		public function get_icon() {
			return 'eicon-accordion';
		}

		/**
		 * Panel search keywords.
		 *
		 * @return array
		 */
		public function get_keywords() {
			return array_merge( $this->get_base_keywords(), array( 'accordion', 'faq', 'toggle', 'collapse', 'schema' ) );
		}

		/**
		 * Style dependency.
		 *
		 * @return array
		 */
		/**
		 * Script dependency — 'novixa-addons-frontend' also holds the
		 * shared front-end interaction JS (see assets/js/frontend.js).
		 * Without declaring it here, Elementor won't reliably print it
		 * on the isolated AJAX request used to (re)render this widget
		 * while editing, which can leave this widget's interactive
		 * behaviour silently broken in the editor canvas.
		 *
		 * @return array
		 */
		public function get_script_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Style dependency.
		 *
		 * @return array
		 */
		public function get_style_depends() {
			return array( 'novixa-addons-frontend' );
		}

		/**
		 * Register all controls.
		 */
		protected function register_controls() {
			$this->register_layout_controls();
			$this->register_icon_controls();
			$this->register_item_style_controls();
			$this->register_heading_style_controls();
			$this->register_content_style_controls();
			$this->register_icon_style_controls();
		}

		/**
		 * Content tab > Layout (items + general behavior).
		 */
		protected function register_layout_controls() {
			$this->start_controls_section(
				'novixa_section_layout',
				array(
					'label' => __( 'Layout', 'novixa-addons-for-elementor' ),
				)
			);

			$repeater = new Repeater();

			$repeater->add_control(
				'novixa_item_heading',
				array(
					'label'       => __( 'Heading', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( 'Accordion Item', 'novixa-addons-for-elementor' ),
					'label_block' => true,
				)
			);

			$repeater->add_control(
				'novixa_item_content',
				array(
					'label'      => __( 'Content', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::WYSIWYG,
					'default'    => __( 'Type the content for this accordion item here.', 'novixa-addons-for-elementor' ),
					'show_label' => false,
				)
			);

			$this->add_control(
				'novixa_items',
				array(
					'label'       => __( 'Items', 'novixa-addons-for-elementor' ),
					'type'        => Controls_Manager::REPEATER,
					'fields'      => $repeater->get_controls(),
					'default'     => array(
						array(
							'novixa_item_heading' => __( 'Item #1', 'novixa-addons-for-elementor' ),
							'novixa_item_content' => __( 'Type the content for this accordion item here.', 'novixa-addons-for-elementor' ),
						),
						array(
							'novixa_item_heading' => __( 'Item #2', 'novixa-addons-for-elementor' ),
							'novixa_item_content' => __( 'Type the content for this accordion item here.', 'novixa-addons-for-elementor' ),
						),
						array(
							'novixa_item_heading' => __( 'Item #3', 'novixa-addons-for-elementor' ),
							'novixa_item_content' => __( 'Type the content for this accordion item here.', 'novixa-addons-for-elementor' ),
						),
					),
					'title_field' => '{{{ novixa_item_heading }}}',
				)
			);

			$this->add_control(
				'novixa_item_position',
				array(
					'label'   => __( 'Item Position', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::CHOOSE,
					'default' => 'top',
					'options' => array(
						'top' => array(
							'title' => __( 'Icon Left', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-h-align-left',
						),
						'end' => array(
							'title' => __( 'Icon Right', 'novixa-addons-for-elementor' ),
							'icon'  => 'eicon-h-align-right',
						),
					),
					'selectors_dictionary' => array(
						'top' => 'row',
						'end' => 'row-reverse',
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'accordion', 'header-inner' ) => 'flex-direction: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'novixa_first_closed',
				array(
					'label'   => __( 'First Item Closed', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'no',
					'options' => array(
						'no'  => __( 'No', 'novixa-addons-for-elementor' ),
						'yes' => __( 'Yes', 'novixa-addons-for-elementor' ),
					),
				)
			);

			$this->add_control(
				'novixa_close_others',
				array(
					'label'        => __( 'Close Others on Open', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'yes',
				)
			);

			$this->add_control(
				'novixa_html_tag',
				array(
					'label'   => __( 'Title HTML Tag', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::SELECT,
					'options' => array(
						'div'  => 'div',
						'h1'   => 'H1',
						'h2'   => 'H2',
						'h3'   => 'H3',
						'h4'   => 'H4',
						'h5'   => 'H5',
						'h6'   => 'H6',
						'span' => 'span',
						'p'    => 'p',
					),
					'default' => 'div',
				)
			);

			$this->add_control(
				'novixa_faq_schema',
				array(
					'label'        => __( 'FAQ Schema', 'novixa-addons-for-elementor' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Yes', 'novixa-addons-for-elementor' ),
					'label_off'    => __( 'No', 'novixa-addons-for-elementor' ),
					'return_value' => 'yes',
					'default'      => 'no',
					'description'  => __( 'Outputs schema.org FAQPage structured data (JSON-LD) so search engines can show your items as an FAQ rich result. Turn this on only if every item is genuinely a question and answer.', 'novixa-addons-for-elementor' ),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Content tab > Expand/collapse icon.
		 */
		protected function register_icon_controls() {
			$this->start_controls_section(
				'novixa_section_icon',
				array(
					'label' => __( 'Icon', 'novixa-addons-for-elementor' ),
				)
			);

			$this->add_control(
				'novixa_expand_icon',
				array(
					'label'   => __( 'Expand', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::ICONS,
					'default' => array(
						'value'   => 'fas fa-plus',
						'library' => 'fa-solid',
					),
					'skin'    => 'inline',
				)
			);

			$this->add_control(
				'novixa_collapse_icon',
				array(
					'label'   => __( 'Collapse', 'novixa-addons-for-elementor' ),
					'type'    => Controls_Manager::ICONS,
					'default' => array(
						'value'   => 'fas fa-minus',
						'library' => 'fa-solid',
					),
					'skin'    => 'inline',
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Item (the outer border/spacing per row).
		 */
		protected function register_item_style_controls() {
			$this->start_controls_section(
				'novixa_section_item_style',
				array(
					'label' => __( 'Item', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_group_control(
				Group_Control_Border::get_type(),
				array(
					'name'     => 'novixa_item_border',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'accordion', 'item' ),
					'fields_options' => array(
						'width' => array(
							'default' => array(
								'top'    => 0,
								'right'  => 0,
								'bottom' => 1,
								'left'   => 0,
								'unit'   => 'px',
							),
						),
						'color' => array(
							'default' => '#e4e4e7',
						),
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Heading.
		 */
		protected function register_heading_style_controls() {
			$this->start_controls_section(
				'novixa_section_heading_style',
				array(
					'label' => __( 'Heading', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_responsive_control(
				'novixa_heading_padding',
				array(
					'label'      => __( 'Padding', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', 'em', '%' ),
					'default'    => array(
						'top'      => 16,
						'right'    => 4,
						'bottom'   => 16,
						'left'     => 4,
						'unit'     => 'px',
						'isLinked' => false,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'accordion', 'header-inner' ) => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'     => 'novixa_heading_typography',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'accordion', 'title' ),
				)
			);

			$this->start_controls_tabs( 'novixa_heading_state_tabs' );

			$this->start_controls_tab(
				'novixa_heading_state_normal',
				array( 'label' => __( 'Normal', 'novixa-addons-for-elementor' ) )
			);

			$this->add_control(
				'novixa_heading_text_normal',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#1a1a2e',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'accordion', 'title' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'novixa_heading_state_active',
				array( 'label' => __( 'Active', 'novixa-addons-for-elementor' ) )
			);

			$this->add_control(
				'novixa_heading_text_active',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#4f3ff0',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'accordion', 'item', 'open' ) . ' .' . $this->bem( 'accordion', 'title' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->end_controls_tab();

			$this->end_controls_tabs();

			$this->end_controls_section();
		}

		/**
		 * Style tab > Content.
		 */
		protected function register_content_style_controls() {
			$this->start_controls_section(
				'novixa_section_content_style',
				array(
					'label' => __( 'Content', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_control(
				'novixa_content_text_color',
				array(
					'label'     => __( 'Text Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#6f6c7d',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'accordion', 'content-inner' ) => 'color: {{VALUE}};',
					),
				)
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				array(
					'name'     => 'novixa_content_typography',
					'selector' => '{{WRAPPER}} .' . $this->bem( 'accordion', 'content-inner' ),
				)
			);

			$this->add_responsive_control(
				'novixa_content_padding',
				array(
					'label'      => __( 'Padding', 'novixa-addons-for-elementor' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => array( 'px', 'em', '%' ),
					'default'    => array(
						'top'      => 0,
						'right'    => 4,
						'bottom'   => 16,
						'left'     => 4,
						'unit'     => 'px',
						'isLinked' => false,
					),
					'selectors'  => array(
						'{{WRAPPER}} .' . $this->bem( 'accordion', 'content-inner' ) => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Style tab > Expand/collapse icon.
		 */
		protected function register_icon_style_controls() {
			$this->start_controls_section(
				'novixa_section_icon_style',
				array(
					'label' => __( 'Icon', 'novixa-addons-for-elementor' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);

			$this->add_responsive_control(
				'novixa_icon_size',
				array(
					'label'     => __( 'Size', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 6,
							'max' => 40,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 14,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'accordion', 'expand' ) . ' i'   => 'font-size: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .' . $this->bem( 'accordion', 'expand' ) . ' svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_responsive_control(
				'novixa_icon_spacing',
				array(
					'label'     => __( 'Spacing', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::SLIDER,
					'range'     => array(
						'px' => array(
							'min' => 0,
							'max' => 40,
						),
					),
					'default'   => array(
						'unit' => 'px',
						'size' => 12,
					),
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'accordion', 'header-inner' ) => 'gap: {{SIZE}}{{UNIT}};',
					),
				)
			);

			$this->add_control(
				'novixa_icon_color',
				array(
					'label'     => __( 'Color', 'novixa-addons-for-elementor' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#4f3ff0',
					'selectors' => array(
						'{{WRAPPER}} .' . $this->bem( 'accordion', 'expand' ) => 'color: {{VALUE}};',
						'{{WRAPPER}} .' . $this->bem( 'accordion', 'expand' ) . ' svg' => 'fill: {{VALUE}};',
					),
				)
			);

			$this->end_controls_section();
		}

		/**
		 * Front-end render.
		 */
		protected function render() {
			$settings = $this->get_settings_for_display();

			$items = ! empty( $settings['novixa_items'] ) ? $settings['novixa_items'] : array();
			if ( empty( $items ) ) {
				return;
			}

			$uid = 'novixa-accordion-plain-' . esc_attr( $this->get_id() );

			$first_open   = 'yes' !== $settings['novixa_first_closed'];
			$close_others = 'yes' === $settings['novixa_close_others'];
			$tag          = ! empty( $settings['novixa_html_tag'] ) ? $settings['novixa_html_tag'] : 'div';

			if ( 'yes' === $settings['novixa_faq_schema'] ) {
				$this->render_faq_schema( $items );
			}

			printf(
				'<div class="%1$s" id="%2$s" data-close-others="%3$s">',
				esc_attr( $this->bem( 'accordion' ) ),
				esc_attr( $uid ),
				esc_attr( $close_others ? 'yes' : 'no' )
			);

			foreach ( $items as $index => $item ) {
				$is_open = ( 0 === $index && $first_open );

				$item_class = $this->bem( 'accordion', 'item' );
				if ( $is_open ) {
					$item_class .= ' ' . $this->bem( 'accordion', 'item', 'open' );
				}

				printf( '<div class="%1$s">', esc_attr( $item_class ) );

				printf(
					'<div class="%1$s" role="button" tabindex="0" aria-expanded="%2$s">',
					esc_attr( $this->bem( 'accordion', 'header' ) ),
					$is_open ? 'true' : 'false'
				);
				printf( '<span class="%1$s">', esc_attr( $this->bem( 'accordion', 'header-inner' ) ) );

				printf( '<span class="%1$s">', esc_attr( $this->bem( 'accordion', 'expand' ) ) );
				printf( '<span class="%1$s">', esc_attr( $this->bem( 'accordion', 'expand-open' ) ) );
				if ( ! empty( $settings['novixa_expand_icon']['value'] ) ) {
					Icons_Manager::render_icon( $settings['novixa_expand_icon'], array( 'aria-hidden' => 'true' ) );
				}
				echo '</span>';
				printf( '<span class="%1$s">', esc_attr( $this->bem( 'accordion', 'expand-close' ) ) );
				if ( ! empty( $settings['novixa_collapse_icon']['value'] ) ) {
					Icons_Manager::render_icon( $settings['novixa_collapse_icon'], array( 'aria-hidden' => 'true' ) );
				}
				echo '</span>';
				echo '</span>'; // .expand

				printf(
					'<%1$s class="%2$s">%3$s</%1$s>',
					Utils::validate_html_tag( $tag ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					esc_attr( $this->bem( 'accordion', 'title' ) ),
					esc_html( $item['novixa_item_heading'] )
				);

				echo '</span>'; // .header-inner
				echo '</div>'; // .header

				printf(
					'<div class="%1$s" style="overflow:hidden;max-height:%2$s;transition:max-height 0.35s ease;">',
					esc_attr( $this->bem( 'accordion', 'content' ) ),
					$is_open ? '2000px' : '0px'
				);
				printf( '<div class="%1$s">', esc_attr( $this->bem( 'accordion', 'content-inner' ) ) );
				echo wp_kses_post( $item['novixa_item_content'] );
				echo '</div>';
				echo '</div>';

				echo '</div>'; // .item
			}

			echo '</div>'; // .accordion

			// Open/close behavior is handled by the document-level
			// event delegation in assets/js/frontend.js (shared with
			// the Icon Accordion widget) — see the matching note in
			// modules/icon-accordion/class-widget-icon-accordion.php
			// for why a per-instance <script> here would not reliably
			// run inside the Elementor editor.
		}

		/**
		 * Print a schema.org FAQPage JSON-LD block from the accordion
		 * items. HTML is stripped from each answer since Google's own
		 * guidance is for the `text` field to be plain text.
		 *
		 * @param array $items Repeater items.
		 */
		private function render_faq_schema( $items ) {
			$questions = array();

			foreach ( $items as $item ) {
				if ( empty( $item['novixa_item_heading'] ) || empty( $item['novixa_item_content'] ) ) {
					continue;
				}

				$questions[] = array(
					'@type'          => 'Question',
					'name'           => wp_strip_all_tags( $item['novixa_item_heading'] ),
					'acceptedAnswer' => array(
						'@type' => 'Answer',
						'text'  => wp_strip_all_tags( $item['novixa_item_content'] ),
					),
				);
			}

			if ( empty( $questions ) ) {
				return;
			}

			$schema = array(
				'@context'   => 'https://schema.org',
				'@type'      => 'FAQPage',
				'mainEntity' => $questions,
			);

			printf(
				'<script type="application/ld+json">%s</script>',
				wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_json_encode() output is safe JSON, not raw HTML.
			);
		}
	}
}
