<?php
/**
 * Registers/enqueues all CSS + JS. Every handle is prefixed with
 * `novixa-addons-` so it can never dequeue/override another plugin's
 * assets (a very common cause of admin-dashboard clones breaking).
 *
 * @package Novixa_Addons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Novixa_Addons_Assets' ) ) {

	/**
	 * Class Novixa_Addons_Assets
	 */
	class Novixa_Addons_Assets {

		/**
		 * Enqueue assets for our own admin dashboard screen only.
		 *
		 * @param string $hook Current admin page hook suffix.
		 */
		public function admin_assets( $hook ) {
			if ( false === strpos( $hook, 'novixa-addons' ) ) {
				return;
			}

			wp_enqueue_style( 'dashicons' );

			wp_enqueue_style(
				'novixa-addons-admin',
				novixa_addons_asset_url( 'css/admin.css' ),
				array(),
				novixa_addons_asset_version( 'css/admin.css' )
			);

			wp_enqueue_script(
				'novixa-addons-admin',
				novixa_addons_asset_url( 'js/admin.js' ),
				array( 'jquery', 'wp-util' ),
				novixa_addons_asset_version( 'js/admin.js' ),
				true
			);

			wp_localize_script(
				'novixa-addons-admin',
				'NovixaAddonsAdmin',
				array(
					'ajaxUrl' => admin_url( 'admin-ajax.php' ),
					'nonce'   => wp_create_nonce( 'novixa_addons_admin_nonce' ),
					'i18n'    => array(
						'saved' => __( 'Settings saved.', 'novixa-addons-for-elementor' ),
						'error' => __( 'Something went wrong. Please try again.', 'novixa-addons-for-elementor' ),
					),
				)
			);
		}

		/**
		 * Register (but do NOT enqueue) the shared front-end stylesheet.
		 *
		 * This must run on 'elementor/frontend/after_register_styles' -
		 * NOT 'after_enqueue_styles' - because each widget's
		 * get_style_depends() only works against handles that are
		 * *already registered* by the time Elementor resolves widget
		 * dependencies. Registering on the "enqueue" hook is too late:
		 * Elementor tries to enqueue our handle before it exists, so the
		 * dependency silently does nothing (this was the actual cause of
		 * widgets rendering unstyled in the editor canvas/preview iframe).
		 *
		 * Elementor itself takes care of actually loading it - and only
		 * on pages that use one of our widgets - via each widget's
		 * get_style_depends().
		 */
		public function register_frontend_styles() {
			wp_register_style(
				'novixa-addons-frontend',
				novixa_addons_asset_url( 'css/frontend.css' ),
				array(),
				novixa_addons_asset_version( 'css/frontend.css' )
			);
		}

		/**
		 * Register (but do NOT enqueue) the shared front-end script.
		 * See register_frontend_styles() above for why this has to be
		 * registered on the "after_register_scripts" hook.
		 */
		public function register_frontend_scripts() {
			wp_register_script(
				'novixa-addons-frontend',
				novixa_addons_asset_url( 'js/frontend.js' ),
				array( 'jquery' ),
				novixa_addons_asset_version( 'js/frontend.js' ),
				true
			);
		}

		/**
		 * Force-enqueue the already-registered frontend CSS + JS on every
		 * normal (non-editor) Elementor page.
		 *
		 * Each widget's get_style_depends()/get_script_depends() should
		 * enqueue these automatically once they're registered - but in
		 * practice that per-widget dependency resolution doesn't fire
		 * reliably on every Elementor version/setup for the live
		 * frontend (this is a known Elementor gotcha: "works in the
		 * editor preview, not on the actual page"). Elementor's own
		 * developer docs recommend this exact belt-and-suspenders
		 * pairing - register on "after_register_*", then explicitly
		 * enqueue on "after_enqueue_*" - so every page that goes through
		 * Elementor's frontend rendering is guaranteed to have both
		 * files, regardless of whether the dependency mechanism kicked
		 * in for this particular request.
		 */
		public function enqueue_frontend_assets() {
			wp_enqueue_style( 'novixa-addons-frontend' );
			wp_enqueue_script( 'novixa-addons-frontend' );
		}

		/**
		 * Force-enqueue the already-registered frontend CSS + JS inside
		 * the Elementor editor's preview iframe (the canvas). Same
		 * reasoning as enqueue_frontend_assets() above, just for the
		 * dedicated preview hooks instead of the live-page ones.
		 */
		public function preview_assets() {
			wp_enqueue_style( 'novixa-addons-frontend' );
			wp_enqueue_script( 'novixa-addons-frontend' );
		}

		/**
		 * Assets loaded only inside the Elementor editor iframe.
		 */
		public function editor_assets() {
			wp_enqueue_style(
				'novixa-addons-editor',
				novixa_addons_asset_url( 'css/editor.css' ),
				array(),
				novixa_addons_asset_version( 'css/editor.css' )
			);

			wp_enqueue_script(
				'novixa-addons-editor',
				novixa_addons_asset_url( 'js/editor.js' ),
				array( 'jquery' ),
				novixa_addons_asset_version( 'js/editor.js' ),
				true
			);

			// Experimental Nested Tabs widget only — registers it as a
			// Nested Element type so the editor knows each tab is a
			// real container drop target. See the note at the top of
			// modules/nested-tabs/class-widget-nested-tabs.php.
			wp_enqueue_script(
				'novixa-addons-nested-tabs-editor',
				novixa_addons_asset_url( 'js/editor-nested-tabs.js' ),
				array( 'jquery', 'elementor-common', 'elementor-editor' ),
				novixa_addons_asset_version( 'js/editor-nested-tabs.js' ),
				true
			);
		}
	}
}
