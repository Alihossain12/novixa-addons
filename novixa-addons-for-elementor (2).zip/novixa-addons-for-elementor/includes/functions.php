<?php
/**
 * Global procedural helpers.
 * Every function name is prefixed with novixa_addons_ to avoid any
 * collision with other plugins' global function namespaces.
 *
 * @package Novixa_Addons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'novixa_addons_get_settings' ) ) {
	/**
	 * Fetch the merged (saved + defaults) settings array.
	 *
	 * @return array
	 */
	function novixa_addons_get_settings() {
		return Novixa_Addons_Settings::get_settings();
	}
}

if ( ! function_exists( 'novixa_addons_is_widget_enabled' ) ) {
	/**
	 * Check whether a single widget/module is toggled on in the dashboard.
	 *
	 * @param string $slug Module slug, e.g. 'heading'.
	 * @return bool
	 */
	function novixa_addons_is_widget_enabled( $slug ) {
		return Novixa_Addons_Settings::is_widget_enabled( $slug );
	}
}

if ( ! function_exists( 'novixa_addons_get_option' ) ) {
	/**
	 * Read a single settings value with a fallback.
	 *
	 * @param string $key     Option key.
	 * @param mixed  $default Fallback value.
	 * @return mixed
	 */
	function novixa_addons_get_option( $key, $default = '' ) {
		$settings = novixa_addons_get_settings();
		return isset( $settings[ $key ] ) ? $settings[ $key ] : $default;
	}
}

if ( ! function_exists( 'novixa_addons_asset_url' ) ) {
	/**
	 * Build a URL inside this plugin's /assets/ folder.
	 *
	 * @param string $path Relative path, e.g. 'css/admin.css'.
	 * @return string
	 */
	function novixa_addons_asset_url( $path ) {
		return NOVIXA_ADDONS_ASSETS_URL . ltrim( $path, '/' );
	}
}

if ( ! function_exists( 'novixa_addons_asset_version' ) ) {
	/**
	 * Cache-busting value for one specific asset file.
	 *
	 * Every wp_enqueue_style()/wp_enqueue_script() call used to pass the
	 * plugin-wide NOVIXA_ADDONS_VERSION constant as its version string.
	 * That only busts the browser's cache when a human remembers to
	 * bump that constant on every single release - and in practice a
	 * CSS/JS edit has repeatedly shipped without the bump, so visitors
	 * (and the Elementor editor preview) kept being served the old,
	 * already-cached file under the same "?ver=" query string.
	 *
	 * Using this file's own filemtime() instead means the cache key
	 * changes automatically the moment the file's contents change -
	 * no manual version bump required, so this class of bug can't
	 * recur. Falls back to NOVIXA_ADDONS_VERSION if the file can't be
	 * found (e.g. inside a minified/build-only distribution).
	 *
	 * @param string $relative_path Path inside /assets/, e.g. 'js/frontend.js'.
	 * @return string
	 */
	function novixa_addons_asset_version( $relative_path ) {
		$file = NOVIXA_ADDONS_PATH . 'assets/' . ltrim( $relative_path, '/' );
		$time = file_exists( $file ) ? filemtime( $file ) : false;

		return $time ? (string) $time : NOVIXA_ADDONS_VERSION;
	}
}

if ( ! function_exists( 'novixa_addons_get_template' ) ) {
	/**
	 * Load an admin/template partial, isolated in its own scope.
	 *
	 * @param string $template_name File name inside /templates/ (no extension).
	 * @param array  $args          Variables extracted into the template scope.
	 */
	function novixa_addons_get_template( $template_name, $args = array() ) {
		$file = NOVIXA_ADDONS_PATH . 'templates/' . $template_name . '.php';

		if ( ! file_exists( $file ) ) {
			return;
		}

		if ( ! empty( $args ) && is_array( $args ) ) {
			extract( $args, EXTR_SKIP ); // phpcs:ignore WordPress.PHP.DontExtract
		}

		include $file;
	}
}

if ( ! function_exists( 'novixa_addons_widgets_registry' ) ) {
	/**
	 * Central registry describing every widget/module the plugin ships.
	 * Adding a new module later only means adding one row here plus
	 * its own modules/<slug>/ folder — nothing else has to change.
	 *
	 * @return array
	 */
	function novixa_addons_widgets_registry() {
		return array(
			'heading'     => array(
				'label'       => __( 'Heading', 'novixa-addons-for-elementor' ),
				'icon'        => 'eicon-t-letter',
				'description' => __( 'A flexible heading widget with highlighted-text and sub-title support.', 'novixa-addons-for-elementor' ),
				'category'    => __( 'Common', 'novixa-addons-for-elementor' ),
				'class_file'  => 'class-widget-heading.php',
				'class_name'  => 'Novixa_Addons_Widget_Heading',
			),
			'dual-color-heading' => array(
				'label'       => __( 'Dual Color Heading', 'novixa-addons-for-elementor' ),
				'icon'        => 'eicon-t-letter',
				'description' => __( 'A heading split into two text runs, each with its own independent color and typography.', 'novixa-addons-for-elementor' ),
				'category'    => __( 'Common', 'novixa-addons-for-elementor' ),
				'class_file'  => 'class-widget-dual-color-heading.php',
				'class_name'  => 'Novixa_Addons_Widget_Dual_Color_Heading',
			),
			'gradient-text-effect' => array(
				'label'       => __( 'Gradient Text Effect', 'novixa-addons-for-elementor' ),
				'icon'        => 'eicon-t-letter',
				'description' => __( 'A heading split into Beginning / Gradient / Ending text runs, with an adjustable two-color gradient clipped to the middle run.', 'novixa-addons-for-elementor' ),
				'category'    => __( 'Common', 'novixa-addons-for-elementor' ),
				'class_file'  => 'class-widget-gradient-text-effect.php',
				'class_name'  => 'Novixa_Addons_Widget_Gradient_Text_Effect',
			),
			'image-caption-card' => array(
				'label'       => __( 'Image Caption Card', 'novixa-addons-for-elementor' ),
				'icon'        => 'eicon-image-box',
				'description' => __( 'A background image with a caption overlaid on it, plus an optional accent bar underneath.', 'novixa-addons-for-elementor' ),
				'category'    => __( 'Common', 'novixa-addons-for-elementor' ),
				'class_file'  => 'class-widget-image-caption-card.php',
				'class_name'  => 'Novixa_Addons_Widget_Image_Caption_Card',
			),
			'content-reveal-hover' => array(
				'label'       => __( 'Content Reveal on Hover', 'novixa-addons-for-elementor' ),
				'icon'        => 'eicon-image-box',
				'description' => __( 'A background-image box whose title shifts and whose description/buttons/badge fade & slide into view on hover.', 'novixa-addons-for-elementor' ),
				'category'    => __( 'Common', 'novixa-addons-for-elementor' ),
				'class_file'  => 'class-widget-content-reveal-hover.php',
				'class_name'  => 'Novixa_Addons_Widget_Content_Reveal_Hover',
			),
			'text-editor' => array(
				'label'       => __( 'Text Editor', 'novixa-addons-for-elementor' ),
				'icon'        => 'eicon-text',
				'description' => __( 'A rich-text editor widget with drop-cap and column support.', 'novixa-addons-for-elementor' ),
				'category'    => __( 'Common', 'novixa-addons-for-elementor' ),
				'class_file'  => 'class-widget-text-editor.php',
				'class_name'  => 'Novixa_Addons_Widget_Text_Editor',
			),
			'icon-box'    => array(
				'label'       => __( 'Icon Box', 'novixa-addons-for-elementor' ),
				'icon'        => 'eicon-icon-box',
				'description' => __( 'A luxury icon box with shape, hover animation and box-shadow controls.', 'novixa-addons-for-elementor' ),
				'category'    => __( 'Common', 'novixa-addons-for-elementor' ),
				'class_file'  => 'class-widget-icon-box.php',
				'class_name'  => 'Novixa_Addons_Widget_Icon_Box',
			),
			'diamond-icon-box' => array(
				'label'       => __( 'Diamond Icon Box', 'novixa-addons-for-elementor' ),
				'icon'        => 'eicon-icon-box',
				'description' => __( 'An icon box with a rotated diamond-outline icon shape, ideal for feature-grid sections.', 'novixa-addons-for-elementor' ),
				'category'    => __( 'Common', 'novixa-addons-for-elementor' ),
				'class_file'  => 'class-widget-diamond-icon-box.php',
				'class_name'  => 'Novixa_Addons_Widget_Diamond_Icon_Box',
			),
			'image-box'   => array(
				'label'       => __( 'Image Box', 'novixa-addons-for-elementor' ),
				'icon'        => 'eicon-image-box',
				'description' => __( 'A luxury image box with hover zoom/grayscale effects and flexible layout.', 'novixa-addons-for-elementor' ),
				'category'    => __( 'Common', 'novixa-addons-for-elementor' ),
				'class_file'  => 'class-widget-image-box.php',
				'class_name'  => 'Novixa_Addons_Widget_Image_Box',
			),
			'button'      => array(
				'label'       => __( 'Button', 'novixa-addons-for-elementor' ),
				'icon'        => 'eicon-button',
				'description' => __( 'A button widget with a Uiverse.io-style blob hover effect.', 'novixa-addons-for-elementor' ),
				'category'    => __( 'Common', 'novixa-addons-for-elementor' ),
				'class_file'  => 'class-widget-button.php',
				'class_name'  => 'Novixa_Addons_Widget_Button',
			),
			'overlay-button' => array(
				'label'       => __( 'Overlay Button', 'novixa-addons-for-elementor' ),
				'icon'        => 'eicon-button',
				'description' => __( 'A button with a hover overlay effect — a small color chip expands to fill the button on hover.', 'novixa-addons-for-elementor' ),
				'category'    => __( 'Common', 'novixa-addons-for-elementor' ),
				'class_file'  => 'class-widget-overlay-button.php',
				'class_name'  => 'Novixa_Addons_Widget_Overlay_Button',
			),
			'icon-accordion' => array(
				'label'       => __( 'Icon Accordion', 'novixa-addons-for-elementor' ),
				'icon'        => 'eicon-accordion',
				'description' => __( 'Expandable panels, each with its own icon, heading, and content.', 'novixa-addons-for-elementor' ),
				'category'    => __( 'Common', 'novixa-addons-for-elementor' ),
				'class_file'  => 'class-widget-icon-accordion.php',
				'class_name'  => 'Novixa_Addons_Widget_Icon_Accordion',
			),
			'accordion' => array(
				'label'       => __( 'Accordion', 'novixa-addons-for-elementor' ),
				'icon'        => 'eicon-accordion',
				'description' => __( 'A simple plus/minus accordion, with optional FAQ schema (JSON-LD) output.', 'novixa-addons-for-elementor' ),
				'category'    => __( 'Common', 'novixa-addons-for-elementor' ),
				'class_file'  => 'class-widget-accordion.php',
				'class_name'  => 'Novixa_Addons_Widget_Accordion',
			),
			'tabs' => array(
				'label'       => __( 'Tabs', 'novixa-addons-for-elementor' ),
				'icon'        => 'eicon-tabs',
				'description' => __( 'A set of labeled tabs with Direction, Justify, and Align Title layout controls.', 'novixa-addons-for-elementor' ),
				'category'    => __( 'Common', 'novixa-addons-for-elementor' ),
				'class_file'  => 'class-widget-tabs.php',
				'class_name'  => 'Novixa_Addons_Widget_Tabs',
			),
			'nested-tabs' => array(
				'label'       => __( 'Tabs (Nested, Experimental)', 'novixa-addons-for-elementor' ),
				'icon'        => 'eicon-tabs',
				'description' => __( 'EXPERIMENTAL: tabs where each panel is a real Elementor container you can drag any widget into. Requires the "Container" and "Nested Elements" experiments to be active.', 'novixa-addons-for-elementor' ),
				'category'    => __( 'Common', 'novixa-addons-for-elementor' ),
				'class_file'  => 'class-widget-nested-tabs.php',
				'class_name'  => 'Novixa_Addons_Widget_Nested_Tabs',
			),
			'counter' => array(
				'label'       => __( 'Counter', 'novixa-addons-for-elementor' ),
				'icon'        => 'eicon-counter',
				'description' => __( 'A premium animated count-up number with an optional icon, prefix/suffix, and title — counts up when it scrolls into view.', 'novixa-addons-for-elementor' ),
				'category'    => __( 'Common', 'novixa-addons-for-elementor' ),
				'class_file'  => 'class-widget-counter.php',
				'class_name'  => 'Novixa_Addons_Widget_Counter',
			),
			'liquid-counter' => array(
				'label'       => __( 'Liquid Counter', 'novixa-addons-for-elementor' ),
				'icon'        => 'eicon-number-field',
				'description' => __( 'A circular stat badge with an animated gold "liquid fill" wave and a count-up number in the middle — great for a row of quick stats.', 'novixa-addons-for-elementor' ),
				'category'    => __( 'Common', 'novixa-addons-for-elementor' ),
				'class_file'  => 'class-widget-liquid-counter.php',
				'class_name'  => 'Novixa_Addons_Widget_Liquid_Counter',
			),
			'list-marquee' => array(
				'label'       => __( 'List Marquee', 'novixa-addons-for-elementor' ),
				'icon'        => 'eicon-post-list',
				'description' => __( 'An infinitely-scrolling horizontal ticker of short items — announcements, room rates, offers — separated by an icon and a bullet.', 'novixa-addons-for-elementor' ),
				'category'    => __( 'Common', 'novixa-addons-for-elementor' ),
				'class_file'  => 'class-widget-list-marquee.php',
				'class_name'  => 'Novixa_Addons_Widget_List_Marquee',
			),
			'logo-marquee' => array(
				'label'       => __( 'Logo Marquee', 'novixa-addons-for-elementor' ),
				'icon'        => 'eicon-slider-3d',
				'description' => __( 'An infinitely-scrolling horizontal row of logo cards — brands, clients, or partners — each with an optional link and caption.', 'novixa-addons-for-elementor' ),
				'category'    => __( 'Common', 'novixa-addons-for-elementor' ),
				'class_file'  => 'class-widget-logo-marquee.php',
				'class_name'  => 'Novixa_Addons_Widget_Logo_Marquee',
			),
			'images-marquee' => array(
				'label'       => __( 'Images Marquee', 'novixa-addons-for-elementor' ),
				'icon'        => 'eicon-gallery-grid',
				'description' => __( 'An infinitely-scrolling gallery strip of plain images — a photo wall, portfolio strip, or "as seen in" band — each with an optional link and caption.', 'novixa-addons-for-elementor' ),
				'category'    => __( 'Common', 'novixa-addons-for-elementor' ),
				'class_file'  => 'class-widget-images-marquee.php',
				'class_name'  => 'Novixa_Addons_Widget_Images_Marquee',
			),
			'feature-card' => array(
				'label'       => __( 'Feature Card', 'novixa-addons-for-elementor' ),
				'icon'        => 'eicon-icon-box',
				'description' => __( 'An icon-box style service/feature card with a title, description, and a CTA button that can overlap the card\'s bottom-right corner.', 'novixa-addons-for-elementor' ),
				'category'    => __( 'Common', 'novixa-addons-for-elementor' ),
				'class_file'  => 'class-widget-feature-card.php',
				'class_name'  => 'Novixa_Addons_Widget_Feature_Card',
			),
			'numbered-feature-box' => array(
				'label'       => __( 'Numbered Feature Box', 'novixa-addons-for-elementor' ),
				'icon'        => 'eicon-editor-list-ol',
				'description' => __( 'A dark card with a colored icon badge, a large faint step number, a title and a description - built for numbered feature/benefit grids.', 'novixa-addons-for-elementor' ),
				'category'    => __( 'Common', 'novixa-addons-for-elementor' ),
				'class_file'  => 'class-widget-numbered-feature-box.php',
				'class_name'  => 'Novixa_Addons_Widget_Numbered_Feature_Box',
			),
			'before-after' => array(
				'label'       => __( 'Before / After', 'novixa-addons-for-elementor' ),
				'icon'        => 'eicon-image-before-after',
				'description' => __( 'A draggable image-comparison slider - two images in one frame, revealed with a drag handle, with a Height control so the frame is always a consistent size.', 'novixa-addons-for-elementor' ),
				'category'    => __( 'Common', 'novixa-addons-for-elementor' ),
				'class_file'  => 'class-widget-before-after.php',
				'class_name'  => 'Novixa_Addons_Widget_Before_After',
			),
			'image-gallery' => array(
				'label'       => __( 'Image Gallery', 'novixa-addons-for-elementor' ),
				'icon'        => 'eicon-gallery-grid',
				'description' => __( 'A luxury filterable image gallery - Grid or Masonry layout, category filter bar, hover overlay, and a built-in lightbox with navigation, counter, and captions.', 'novixa-addons-for-elementor' ),
				'category'    => __( 'Common', 'novixa-addons-for-elementor' ),
				'class_file'  => 'class-widget-image-gallery.php',
				'class_name'  => 'Novixa_Addons_Widget_Image_Gallery',
			),
		);
	}
}
