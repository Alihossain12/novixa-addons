/**
 * Novixa Addons — Front-end widget behaviour.
 *
 * Button widget: the resting look AND the hover/active blob effect
 * are both handled with plain scoped CSS written directly by PHP in
 * render() (see modules/button/class-widget-button.php) — no JS is
 * needed for it, so it works instantly and identically in the
 * Elementor editor preview and on the live site.
 *
 * Accordion / Icon Accordion widgets: open/close is handled here with
 * DOCUMENT-LEVEL EVENT DELEGATION on purpose. Elementor re-renders a
 * widget's markup via AJAX every time a setting changes in the editor
 * (and whenever a widget is freshly dragged onto the canvas); that
 * markup is inserted with innerHTML-style DOM updates, and a <script>
 * tag inserted that way never auto-executes. Delegating every
 * listener to `document` sidesteps this completely — it doesn't
 * matter when or how an item was inserted into the page, the
 * listener is already there waiting for the click/hover to bubble up
 * to it.
 */
( function () {
	'use strict';

	// This file is intentionally plain JavaScript with no jQuery calls
	// anywhere in it. It used to be wrapped as `( function ( $ ) {...} )( jQuery )`
	// purely out of habit — but that meant the ENTIRE file (accordion
	// open/close AND tab switching, for every widget on the page) threw
	// a ReferenceError and silently failed to run if `jQuery` wasn't
	// defined at the exact moment this script executed (e.g. a timing
	// edge case inside Elementor's editor preview iframe). Since jQuery
	// was never actually used, removing the dependency on that global
	// removes that entire failure mode.

	var ITEM_SELECTOR    = '.novixa-addons-accordion__item, .novixa-addons-icon-accordion__item';
	var HEADER_SELECTOR  = '.novixa-addons-accordion__header, .novixa-addons-icon-accordion__header';
	var CONTENT_SELECTOR = '.novixa-addons-accordion__content, .novixa-addons-icon-accordion__content';
	var ROOT_SELECTOR    = '.novixa-addons-accordion, .novixa-addons-icon-accordion';
	var OPEN_CLASSES     = [ 'novixa-addons-accordion__item--open', 'novixa-addons-icon-accordion__item--open' ];

	function closest( el, selector ) {
		return el && el.closest ? el.closest( selector ) : null;
	}

	function isOpen( item ) {
		return OPEN_CLASSES.some( function ( cls ) {
			return item.classList.contains( cls );
		} );
	}

	function setOpen( item, open ) {
		var header  = item.querySelector( HEADER_SELECTOR );
		var content = item.querySelector( CONTENT_SELECTOR );

		if ( ! content ) {
			return;
		}

		content.style.maxHeight = open ? content.scrollHeight + 'px' : '0px';

		OPEN_CLASSES.forEach( function ( cls ) {
			item.classList.toggle( cls, open );
		} );

		if ( header ) {
			header.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
		}
	}

	function closeSiblings( root, except ) {
		root.querySelectorAll( ITEM_SELECTOR ).forEach( function ( item ) {
			// Only direct items of THIS root — a nested accordion inside
			// another accordion's content would otherwise get its
			// siblings closed too.
			if ( item !== except && closest( item.parentElement, ROOT_SELECTOR ) === root ) {
				setOpen( item, false );
			}
		} );
	}

	function findRoot( item ) {
		return closest( item.parentElement, ROOT_SELECTOR );
	}

	function refreshOpenHeight( item ) {
		var content = item.querySelector( CONTENT_SELECTOR );
		if ( content && isOpen( item ) ) {
			content.style.maxHeight = content.scrollHeight + 'px';
		}
	}

	document.addEventListener( 'click', function ( e ) {
		var header = closest( e.target, HEADER_SELECTOR );
		if ( ! header ) {
			return;
		}

		var item = closest( header, ITEM_SELECTOR );
		if ( ! item ) {
			return;
		}

		var root = findRoot( item );
		if ( ! root || 'hover' === root.getAttribute( 'data-trigger' ) ) {
			return;
		}

		var closeOthers = 'yes' === root.getAttribute( 'data-close-others' );
		var willOpen     = ! isOpen( item );

		if ( closeOthers ) {
			closeSiblings( root, item );
		}

		setOpen( item, willOpen );

		if ( willOpen && 'yes' === root.getAttribute( 'data-scroll-to-head' ) && header.scrollIntoView ) {
			header.scrollIntoView( { behavior: 'smooth', block: 'start' } );
		}
	} );

	document.addEventListener( 'keydown', function ( e ) {
		if ( 'Enter' !== e.key && ' ' !== e.key ) {
			return;
		}

		var header = closest( e.target, HEADER_SELECTOR );
		if ( ! header ) {
			return;
		}

		e.preventDefault();
		header.dispatchEvent( new MouseEvent( 'click', { bubbles: true } ) );
	} );

	document.addEventListener( 'mouseover', function ( e ) {
		var item = closest( e.target, '.novixa-addons-icon-accordion__item' );
		if ( ! item || ( e.relatedTarget && item.contains( e.relatedTarget ) ) ) {
			return;
		}

		var root = findRoot( item );
		if ( ! root || 'hover' !== root.getAttribute( 'data-trigger' ) ) {
			return;
		}

		if ( 'yes' === root.getAttribute( 'data-close-others' ) ) {
			closeSiblings( root, item );
		}

		setOpen( item, true );
	} );

	document.addEventListener( 'mouseout', function ( e ) {
		var item = closest( e.target, '.novixa-addons-icon-accordion__item' );
		if ( ! item || ( e.relatedTarget && item.contains( e.relatedTarget ) ) ) {
			return;
		}

		var root = findRoot( item );
		if ( ! root || 'hover' !== root.getAttribute( 'data-trigger' ) ) {
			return;
		}

		setOpen( item, false );
	} );

	// Items rendered already-open (e.g. the first item, by default) get
	// a deliberately generous inline max-height straight from PHP (see
	// each widget's render()) so they display fully with zero JS
	// dependency. Once this script is available, tighten that down to
	// the item's exact scrollHeight so the FIRST close animates
	// proportionally instead of animating from an arbitrary big number.
	function refreshAllOpenHeights() {
		document.querySelectorAll( ITEM_SELECTOR ).forEach( refreshOpenHeight );
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', refreshAllOpenHeights );
	} else {
		refreshAllOpenHeights();
	}

	window.addEventListener( 'resize', refreshAllOpenHeights );

	// Elementor re-renders a widget's markup via AJAX every time a
	// setting changes in the editor, or the moment a widget is first
	// dragged onto the canvas — re-measure right after so a freshly
	// (re)rendered open item gets its real height instead of relying
	// only on the generous PHP fallback.
	if ( window.elementorFrontend && window.elementorFrontend.hooks ) {
		window.elementorFrontend.hooks.addAction( 'frontend/element_ready/global', refreshAllOpenHeights );
	}

	/**
	 * Tabs widget — same document-level delegation approach: a
	 * <script> printed inside AJAX-rendered widget markup never
	 * auto-executes inside the Elementor editor, so switching tabs has
	 * to be driven by a listener that was already registered on
	 * `document` before that markup ever existed.
	 */
	var TABS_ROOT_SELECTOR     = '.novixa-addons-tabs, .novixa-addons-nested-tabs';
	var TABS_NAV_ITEM_SELECTOR = '.novixa-addons-tabs__nav-item, .novixa-addons-nested-tabs__nav-item';
	var TABS_NAV_ACTIVE_CLASS  = 'novixa-addons-tabs__nav-item--active';
	var TABS_NESTED_NAV_ACTIVE_CLASS = 'novixa-addons-nested-tabs__nav-item--active';
	var TABS_PANEL_SELECTOR    = '.novixa-addons-tabs__panel, .novixa-addons-nested-tabs__panel';
	var TABS_PANEL_ACTIVE_CLASS = 'novixa-addons-tabs__panel--active';
	var TABS_NESTED_PANEL_ACTIVE_CLASS = 'novixa-addons-nested-tabs__panel--active';

	function activateTab( root, index ) {
		root.querySelectorAll( TABS_NAV_ITEM_SELECTOR ).forEach( function ( navItem ) {
			var isActive = navItem.getAttribute( 'data-tab-index' ) === String( index );
			navItem.classList.toggle( TABS_NAV_ACTIVE_CLASS, isActive );
			navItem.classList.toggle( TABS_NESTED_NAV_ACTIVE_CLASS, isActive );
			navItem.setAttribute( 'aria-selected', isActive ? 'true' : 'false' );
		} );

		root.querySelectorAll( TABS_PANEL_SELECTOR ).forEach( function ( panel ) {
			var isActive = panel.getAttribute( 'data-tab-index' ) === String( index );
			panel.classList.toggle( TABS_PANEL_ACTIVE_CLASS, isActive );
			panel.classList.toggle( TABS_NESTED_PANEL_ACTIVE_CLASS, isActive );
			panel.style.display = isActive ? 'block' : 'none';
		} );

		// Elementor-editor-only case: while editing (before the page is
		// ever saved/rendered by our own render()), each Nested Tabs
		// panel is a real Elementor container placed directly inside
		// .novixa-addons-nested-tabs__panels by Widget_Nested_Base's own
		// NestedView (see assets/js/editor-nested-tabs.js) — it carries
		// a `data-tab-index` attribute but NOT our
		// `novixa-addons-nested-tabs__panel` class, so the loop above
		// never finds/toggles it and the canvas keeps showing Tab #1's
		// container no matter which nav button is active. Toggle those
		// raw containers here too so switching tabs in the editor
		// canvas matches the published front-end behaviour.
		var panelsWrap = root.querySelector( '.' + 'novixa-addons-nested-tabs__panels' );
		if ( panelsWrap ) {
			Array.prototype.forEach.call( panelsWrap.children, function ( child ) {
				if ( ! child.hasAttribute( 'data-tab-index' ) || child.classList.contains( 'novixa-addons-nested-tabs__panel' ) ) {
					return;
				}
				var isChildActive = child.getAttribute( 'data-tab-index' ) === String( index );
				child.style.display = isChildActive ? '' : 'none';
			} );
		}
	}

	document.addEventListener( 'click', function ( e ) {
		var navItem = closest( e.target, TABS_NAV_ITEM_SELECTOR );
		if ( ! navItem ) {
			return;
		}

		var root = closest( navItem, TABS_ROOT_SELECTOR );
		if ( ! root ) {
			return;
		}

		activateTab( root, navItem.getAttribute( 'data-tab-index' ) );
	} );

	/**
	 * Counter widget: count-up animation.
	 *
	 * The number only starts counting once it's actually scrolled into
	 * view (IntersectionObserver), and only ever runs once per element
	 * (marked with COUNTER_DONE_CLASS) so re-scrolling past it doesn't
	 * restart the animation. Because Elementor's editor replaces a
	 * widget's markup wholesale on every settings change (see the
	 * file-level comment at the top of this file), new counter
	 * elements can appear at any time — a MutationObserver on
	 * `document.body`, plus one initial scan on load, is what picks
	 * those up instead of a one-time querySelectorAll at script load.
	 */
	// Attribute-based rather than tied to one widget's BEM class, so
	// this same count-up logic works for both the plain Counter
	// widget's number span AND the Liquid Counter widget's number span
	// (see further down) without duplicating the animation code.
	var COUNTER_SELECTOR   = '[data-novixa-counter-end]';
	var COUNTER_DONE_CLASS = 'novixa-addons-counter__number--counted';

	function formatCounterValue( value, decimals, useSeparator ) {
		var fixed = value.toFixed( decimals );

		if ( ! useSeparator ) {
			return fixed;
		}

		var parts = fixed.split( '.' );
		parts[ 0 ] = parts[ 0 ].replace( /\B(?=(\d{3})+(?!\d))/g, ',' );
		return parts.join( '.' );
	}

	function runCounter( el ) {
		if ( ! el || el.classList.contains( COUNTER_DONE_CLASS ) ) {
			return;
		}
		el.classList.add( COUNTER_DONE_CLASS );

		var start        = parseFloat( el.getAttribute( 'data-novixa-counter-start' ) ) || 0;
		var end          = parseFloat( el.getAttribute( 'data-novixa-counter-end' ) );
		var decimals     = parseInt( el.getAttribute( 'data-novixa-counter-decimals' ), 10 ) || 0;
		var duration     = parseInt( el.getAttribute( 'data-novixa-counter-duration' ), 10 ) || 2000;
		var useSeparator = '1' === el.getAttribute( 'data-novixa-counter-separator' );

		if ( isNaN( end ) ) {
			return;
		}

		// Respect a visitor's OS-level "reduce motion" preference by
		// jumping straight to the end value instead of animating.
		if ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) {
			el.textContent = formatCounterValue( end, decimals, useSeparator );
			return;
		}

		var startTime = null;

		function step( timestamp ) {
			if ( null === startTime ) {
				startTime = timestamp;
			}

			var progress = Math.min( ( timestamp - startTime ) / duration, 1 );
			// easeOutCubic — quick start, gentle settle, reads as premium rather than mechanical.
			var eased    = 1 - Math.pow( 1 - progress, 3 );
			var current  = start + ( end - start ) * eased;

			el.textContent = formatCounterValue( current, decimals, useSeparator );

			if ( progress < 1 ) {
				window.requestAnimationFrame( step );
			}
		}

		window.requestAnimationFrame( step );
	}

	var counterObserver = ( 'IntersectionObserver' in window )
		? new IntersectionObserver(
			function ( entries ) {
				entries.forEach( function ( entry ) {
					if ( entry.isIntersecting ) {
						runCounter( entry.target );
						counterObserver.unobserve( entry.target );
					}
				} );
			},
			{ threshold: 0.3 }
		)
		: null;

	function observeNewCounters( root ) {
		var scope = root && root.querySelectorAll ? root : document;
		scope.querySelectorAll( COUNTER_SELECTOR ).forEach( function ( el ) {
			if ( el.classList.contains( COUNTER_DONE_CLASS ) ) {
				return;
			}
			if ( counterObserver ) {
				counterObserver.observe( el );
			} else {
				// No IntersectionObserver support: just run it immediately.
				runCounter( el );
			}
		} );
	}

	observeNewCounters( document );

	if ( 'MutationObserver' in window ) {
		new MutationObserver( function ( mutations ) {
			mutations.forEach( function ( mutation ) {
				mutation.addedNodes.forEach( function ( node ) {
					if ( 1 !== node.nodeType ) {
						return;
					}
					if ( node.matches && node.matches( COUNTER_SELECTOR ) ) {
						observeNewCounters( node.parentNode || document );
					} else if ( node.querySelectorAll ) {
						observeNewCounters( node );
					}
				} );
			} );
		} ).observe( document.body, { childList: true, subtree: true } );
	}

	/**
	 * Liquid Counter widget: gold "liquid" rises to its configured fill
	 * level, and the number inside counts up, together, the first time
	 * the circle scrolls into view. The count-up itself reuses
	 * runCounter()/formatCounterValue() above — this only adds the
	 * wave-rise half, using the exact same MutationObserver +
	 * IntersectionObserver pattern as the plain Counter widget so both
	 * survive Elementor re-rendering the widget's markup mid-edit.
	 */
	var LIQUID_CIRCLE_SELECTOR = '.novixa-addons-liquid-counter__circle';
	var LIQUID_DONE_CLASS      = 'novixa-addons-liquid-counter__circle--filled';
	var reduceMotionQuery      = window.matchMedia ? window.matchMedia( '(prefers-reduced-motion: reduce)' ) : null;

	function runLiquidFill( circle ) {
		if ( ! circle || circle.classList.contains( LIQUID_DONE_CLASS ) ) {
			return;
		}
		circle.classList.add( LIQUID_DONE_CLASS );

		var fill     = parseFloat( circle.getAttribute( 'data-novixa-liquid-fill' ) ) || 0;
		var waveWrap = circle.querySelector( '.novixa-addons-liquid-counter__wave-wrap' );
		var numberEl = circle.querySelector( COUNTER_SELECTOR );

		if ( waveWrap ) {
			if ( reduceMotionQuery && reduceMotionQuery.matches ) {
				waveWrap.style.transition = 'none';
			}
			// Read the 0% starting height before switching, so the
			// browser actually animates the transition instead of
			// jumping straight to the target (a same-frame style
			// change with no intervening paint won't transition).
			window.requestAnimationFrame( function () {
				waveWrap.style.height = fill + '%';
			} );
		}

		if ( numberEl ) {
			runCounter( numberEl );
		}
	}

	var liquidObserver = ( 'IntersectionObserver' in window )
		? new IntersectionObserver(
			function ( entries ) {
				entries.forEach( function ( entry ) {
					if ( entry.isIntersecting ) {
						runLiquidFill( entry.target );
						liquidObserver.unobserve( entry.target );
					}
				} );
			},
			{ threshold: 0.3 }
		)
		: null;

	function observeNewLiquidCircles( root ) {
		var scope = root && root.querySelectorAll ? root : document;
		scope.querySelectorAll( LIQUID_CIRCLE_SELECTOR ).forEach( function ( el ) {
			if ( el.classList.contains( LIQUID_DONE_CLASS ) ) {
				return;
			}
			if ( liquidObserver ) {
				liquidObserver.observe( el );
			} else {
				runLiquidFill( el );
			}
		} );
	}

	observeNewLiquidCircles( document );

	if ( 'MutationObserver' in window ) {
		new MutationObserver( function ( mutations ) {
			mutations.forEach( function ( mutation ) {
				mutation.addedNodes.forEach( function ( node ) {
					if ( 1 !== node.nodeType ) {
						return;
					}
					if ( node.matches && node.matches( LIQUID_CIRCLE_SELECTOR ) ) {
						observeNewLiquidCircles( node.parentNode || document );
					} else if ( node.querySelectorAll ) {
						observeNewLiquidCircles( node );
					}
				} );
			} );
		} ).observe( document.body, { childList: true, subtree: true } );
	}

	/**
	 * Before / After widget: drag (mouse/touch/pen via Pointer Events),
	 * click-to-jump, and arrow-key support for the comparison handle.
	 * Uses document-level delegation for the same reason as the
	 * accordion above — Elementor's editor re-renders this widget's
	 * markup via AJAX on every settings change, and a fresh element
	 * needs to work immediately without any per-instance init step.
	 */
	var BA_ROOT_SELECTOR   = '.novixa-addons-before-after';
	var BA_FRAME_SELECTOR  = '.novixa-addons-before-after__frame';
	var BA_HANDLE_SELECTOR = '.novixa-addons-before-after__handle';
	var baActiveFrame      = null;

	function baClamp( value ) {
		return Math.max( 0, Math.min( 100, value ) );
	}

	function baPercentFromEvent( frame, evt, orientation ) {
		var rect = frame.getBoundingClientRect();
		var pct;

		if ( 'vertical' === orientation ) {
			pct = rect.height ? ( ( evt.clientY - rect.top ) / rect.height ) * 100 : 50;
		} else {
			pct = rect.width ? ( ( evt.clientX - rect.left ) / rect.width ) * 100 : 50;
		}

		return baClamp( pct );
	}

	function baSetPosition( frame, pct ) {
		var root    = closest( frame, BA_ROOT_SELECTOR );
		var handle  = frame.querySelector( BA_HANDLE_SELECTOR );
		var rounded = Math.round( pct * 10 ) / 10;

		frame.style.setProperty( '--novixa-ba-pos', rounded + '%' );

		if ( handle ) {
			handle.setAttribute( 'aria-valuenow', Math.round( rounded ) );
		}

		if ( root && '1' === root.getAttribute( 'data-novixa-autohide-labels' ) ) {
			// The nearer the handle gets to a side, the less room that
			// side's sliver of image has - hide its label instantly (no
			// fade) once the handle enters the last 15% of travel toward
			// that side, so it never overlaps the shrinking edge.
			var fadeBand      = 15;
			var beforeOpacity = ( rounded <= fadeBand ) ? 0 : 1;
			var afterOpacity  = ( rounded >= ( 100 - fadeBand ) ) ? 0 : 1;

			frame.style.setProperty( '--novixa-ba-before-label-opacity', beforeOpacity );
			frame.style.setProperty( '--novixa-ba-after-label-opacity', afterOpacity );
		}
	}

	function baStopAutoplay( frame ) {
		if ( frame && frame.novixaBaAutoplayRaf ) {
			window.cancelAnimationFrame( frame.novixaBaAutoplayRaf );
			frame.novixaBaAutoplayRaf = null;
		}
		if ( frame ) {
			frame.novixaBaAutoplayStopped = true;
		}
	}

	/**
	 * Runs a one-way eased sweep from `fromPct` to `toPct` over
	 * `duration` ms, then invokes `onDone`. Used for both the
	 * "Reveal on Scroll" entrance and each leg of the autoplay
	 * back-and-forth loop, so both share one smooth, interruptible
	 * timing function instead of two separate implementations.
	 */
	function baTween( frame, fromPct, toPct, duration, onDone ) {
		var start = null;

		function easeInOutSine( t ) {
			return -( Math.cos( Math.PI * t ) - 1 ) / 2;
		}

		function step( timestamp ) {
			if ( frame.novixaBaAutoplayStopped ) {
				return;
			}
			if ( null === start ) {
				start = timestamp;
			}
			var elapsed = timestamp - start;
			var t       = duration > 0 ? Math.min( 1, elapsed / duration ) : 1;
			var eased   = easeInOutSine( t );

			baSetPosition( frame, fromPct + ( toPct - fromPct ) * eased );

			if ( t < 1 ) {
				frame.novixaBaAutoplayRaf = window.requestAnimationFrame( step );
			} else if ( onDone ) {
				onDone();
			}
		}

		frame.novixaBaAutoplayRaf = window.requestAnimationFrame( step );
	}

	function baStartAutoplayLoop( frame, speedSeconds ) {
		var duration = Math.max( 0.5, speedSeconds || 4 ) * 1000;

		function leg( toEdge ) {
			if ( frame.novixaBaAutoplayStopped ) {
				return;
			}
			var current = parseFloat( ( frame.style.getPropertyValue( '--novixa-ba-pos' ) || '50%' ) );
			baTween( frame, current, toEdge ? 82 : 18, duration, function () {
				leg( ! toEdge );
			} );
		}

		leg( true );
	}

	/**
	 * One-time setup per frame: runs the scroll-reveal sweep and/or
	 * kicks off the autoplay loop, exactly once, the first time the
	 * frame scrolls into view. Safe to call repeatedly (e.g. from the
	 * MutationObserver below) - already-initialised frames are
	 * skipped via the `novixaBaInited` flag.
	 */
	function baInitFrame( frame ) {
		if ( frame.novixaBaInited ) {
			return;
		}
		frame.novixaBaInited = true;

		var root = closest( frame, BA_ROOT_SELECTOR );
		if ( ! root ) {
			return;
		}

		// Sync label opacity to the initial position right away so
		// auto-hide is correct even before any interaction happens.
		var startPct = parseFloat( root.getAttribute( 'data-novixa-start' ) );
		baSetPosition( frame, isNaN( startPct ) ? 50 : startPct );

		var wantsReveal   = '1' === root.getAttribute( 'data-novixa-reveal-on-scroll' );
		var wantsAutoplay = '1' === root.getAttribute( 'data-novixa-autoplay' );

		if ( ! wantsReveal && ! wantsAutoplay ) {
			return;
		}

		var speed = parseFloat( root.getAttribute( 'data-novixa-autoplay-speed' ) ) || 4;

		function begin() {
			if ( frame.novixaBaAutoplayStopped ) {
				return;
			}
			if ( wantsReveal ) {
				baSetPosition( frame, 100 );
				baTween( frame, 100, isNaN( startPct ) ? 50 : startPct, 1100, function () {
					if ( wantsAutoplay ) {
						baStartAutoplayLoop( frame, speed );
					}
				} );
			} else if ( wantsAutoplay ) {
				baStartAutoplayLoop( frame, speed );
			}
		}

		if ( 'IntersectionObserver' in window ) {
			var observer = new IntersectionObserver( function ( entries ) {
				entries.forEach( function ( entry ) {
					if ( entry.isIntersecting ) {
						begin();
						observer.unobserve( entry.target );
					}
				} );
			}, { threshold: 0.4 } );
			observer.observe( frame );
		} else {
			begin();
		}
	}

	function baInitAllFrames( scope ) {
		var root = scope && scope.querySelectorAll ? scope : document;
		root.querySelectorAll( BA_FRAME_SELECTOR ).forEach( baInitFrame );
	}

	baInitAllFrames( document );

	if ( 'MutationObserver' in window ) {
		new MutationObserver( function ( mutations ) {
			mutations.forEach( function ( mutation ) {
				mutation.addedNodes.forEach( function ( node ) {
					if ( 1 !== node.nodeType ) {
						return;
					}
					if ( node.matches && node.matches( BA_FRAME_SELECTOR ) ) {
						baInitFrame( node );
					} else if ( node.querySelectorAll ) {
						baInitAllFrames( node );
					}
				} );
			} );
		} ).observe( document.body, { childList: true, subtree: true } );
	}

	document.addEventListener( 'pointerdown', function ( evt ) {
		var handle = closest( evt.target, BA_HANDLE_SELECTOR );
		var frame;

		if ( handle ) {
			frame = closest( handle, BA_FRAME_SELECTOR );
		} else {
			// Clicking anywhere else in the frame jumps the handle there.
			frame = closest( evt.target, BA_FRAME_SELECTOR );
		}

		if ( ! frame ) {
			return;
		}

		// A real visitor is now in control - permanently stand down
		// autoplay/reveal for this instance so it never fights them.
		baStopAutoplay( frame );

		var root        = closest( frame, BA_ROOT_SELECTOR );
		var orientation = root && 'vertical' === root.getAttribute( 'data-novixa-orientation' ) ? 'vertical' : 'horizontal';

		baActiveFrame = frame;
		baSetPosition( frame, baPercentFromEvent( frame, evt, orientation ) );

		var handleEl = frame.querySelector( BA_HANDLE_SELECTOR );
		if ( handleEl && handleEl.focus ) {
			handleEl.focus();
		}

		evt.preventDefault();
	} );

	document.addEventListener( 'pointermove', function ( evt ) {
		if ( ! baActiveFrame ) {
			var hoverRoot = closest( evt.target, BA_ROOT_SELECTOR );
			if ( ! hoverRoot || '1' !== hoverRoot.getAttribute( 'data-novixa-hover-move' ) ) {
				return;
			}
			var hoverFrame = hoverRoot.querySelector( BA_FRAME_SELECTOR );
			if ( ! hoverFrame ) {
				return;
			}
			baStopAutoplay( hoverFrame );
			var hoverOrientation = 'vertical' === hoverRoot.getAttribute( 'data-novixa-orientation' ) ? 'vertical' : 'horizontal';
			baSetPosition( hoverFrame, baPercentFromEvent( hoverFrame, evt, hoverOrientation ) );
			return;
		}

		var activeRoot        = closest( baActiveFrame, BA_ROOT_SELECTOR );
		var activeOrientation = activeRoot && 'vertical' === activeRoot.getAttribute( 'data-novixa-orientation' ) ? 'vertical' : 'horizontal';

		baSetPosition( baActiveFrame, baPercentFromEvent( baActiveFrame, evt, activeOrientation ) );
		evt.preventDefault();
	} );

	function baStopDrag() {
		baActiveFrame = null;
	}

	document.addEventListener( 'pointerup', baStopDrag );
	document.addEventListener( 'pointercancel', baStopDrag );

	document.addEventListener( 'keydown', function ( evt ) {
		var handle = closest( evt.target, BA_HANDLE_SELECTOR );
		if ( ! handle ) {
			return;
		}

		var frame = closest( handle, BA_FRAME_SELECTOR );
		if ( ! frame ) {
			return;
		}

		baStopAutoplay( frame );

		var root        = closest( frame, BA_ROOT_SELECTOR );
		var orientation = root && 'vertical' === root.getAttribute( 'data-novixa-orientation' ) ? 'vertical' : 'horizontal';
		var current     = parseFloat( handle.getAttribute( 'aria-valuenow' ) ) || 50;
		var step        = 2;
		var next        = null;

		if ( 'vertical' === orientation ) {
			if ( 'ArrowUp' === evt.key ) {
				next = current - step;
			} else if ( 'ArrowDown' === evt.key ) {
				next = current + step;
			}
		} else if ( 'ArrowLeft' === evt.key ) {
			next = current - step;
		} else if ( 'ArrowRight' === evt.key ) {
			next = current + step;
		}

		if ( null === next ) {
			return;
		}

		baSetPosition( frame, baClamp( next ) );
		evt.preventDefault();
	} );

	/**
	 * Image Gallery widget: category filter bar + a self-contained
	 * lightbox (no external library). Document-level delegation again,
	 * for the same AJAX-re-render reason explained at the top of this
	 * file. The lightbox element itself is created lazily, once per
	 * gallery instance, and inserted as a sibling right after that
	 * gallery's own wrapper (not document.body) so the Style tab's
	 * "{{WRAPPER}} .novixa-addons-gallery ~ .novixa-addons-gallery-lightbox"
	 * selectors can actually reach it.
	 */
	var GAL_ROOT_SELECTOR    = '.novixa-addons-gallery';
	var GAL_ITEM_SELECTOR    = '.novixa-addons-gallery__item';
	var GAL_FILTER_BTN       = '.novixa-addons-gallery__filter-btn';
	var GAL_TRIGGER_SELECTOR = '.novixa-addons-gallery__thumb[data-novixa-click-action="lightbox"]';
	var GAL_HIDDEN_CLASS     = 'novixa-addons-gallery__item--hidden';
	var GAL_LIGHTBOX_CLASS   = 'novixa-addons-gallery-lightbox';
	var GAL_FADE_MS          = 250;

	/**
	 * Masonry layout, done in JS instead of CSS multi-column.
	 *
	 * CSS `columns: N` (what "Masonry" used to rely on entirely) asks
	 * the browser to *balance* content across N columns by total height,
	 * which - especially with only a handful of items - can end up
	 * visually using fewer columns than N (e.g. "Columns" set to 3 but
	 * only 2 ever get anything in them). That's a real, well-known
	 * inconsistency in how browsers implement multi-column balancing,
	 * not something a single CSS tweak reliably fixes.
	 *
	 * Doing it in JS instead - each item goes into whichever column is
	 * currently shortest - always uses exactly the declared column
	 * count and matches what dedicated masonry libraries do.
	 */
	var GAL_MASONRY_GRID_SELECTOR = '.novixa-addons-gallery__grid--masonry';

	function galLayoutMasonryGrid( grid ) {
		var items = Array.prototype.filter.call(
			grid.querySelectorAll( GAL_ITEM_SELECTOR ),
			function ( item ) {
				return ! item.classList.contains( GAL_HIDDEN_CLASS );
			}
		);

		var gridStyles = window.getComputedStyle( grid );
		var gap        = parseFloat( gridStyles.getPropertyValue( '--novixa-gallery-gap' ) );
		if ( isNaN( gap ) ) {
			gap = 20;
		}

		if ( ! items.length ) {
			grid.style.height = '';
			return;
		}

		var columns = parseInt( gridStyles.getPropertyValue( '--novixa-gallery-columns' ), 10 );
		if ( ! columns || columns < 1 ) {
			columns = 1;
		}

		// One column: plain document flow already looks right (and is
		// cheaper on mobile), so undo any earlier absolute positioning.
		if ( 1 === columns || grid.clientWidth <= 0 ) {
			items.forEach( function ( item ) {
				item.style.position = '';
				item.style.width    = '';
				item.style.left     = '';
				item.style.top      = '';
			} );
			grid.style.height = '';
			return;
		}

		var colWidth   = ( grid.clientWidth - ( gap * ( columns - 1 ) ) ) / columns;
		var colHeights = new Array( columns ).fill( 0 );

		items.forEach( function ( item ) {
			var colIndex = 0;
			for ( var i = 1; i < columns; i++ ) {
				if ( colHeights[ i ] < colHeights[ colIndex ] ) {
					colIndex = i;
				}
			}

			item.style.position = 'absolute';
			item.style.width    = colWidth + 'px';
			item.style.left     = ( colIndex * ( colWidth + gap ) ) + 'px';
			item.style.top      = colHeights[ colIndex ] + 'px';

			colHeights[ colIndex ] += item.offsetHeight + gap;
		} );

		grid.style.height = ( Math.max.apply( Math, colHeights ) - gap ) + 'px';
	}

	var galMasonryRaf = null;

	function galLayoutAllMasonry() {
		if ( galMasonryRaf ) {
			window.cancelAnimationFrame( galMasonryRaf );
		}
		galMasonryRaf = window.requestAnimationFrame( function () {
			document.querySelectorAll( GAL_MASONRY_GRID_SELECTOR ).forEach( galLayoutMasonryGrid );
		} );
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', galLayoutAllMasonry );
	} else {
		galLayoutAllMasonry();
	}

	window.addEventListener( 'resize', galLayoutAllMasonry );

	if ( window.elementorFrontend && window.elementorFrontend.hooks ) {
		window.elementorFrontend.hooks.addAction( 'frontend/element_ready/global', galLayoutAllMasonry );
	}

	// Item heights depend on their images, which may still be loading
	// (lazy-loaded, or just slow) the first time galLayoutAllMasonry()
	// runs - re-run once each image finishes so the layout self-corrects
	// instead of leaving gaps sized from an unloaded image.
	document.addEventListener(
		'load',
		function ( evt ) {
			if ( evt.target && evt.target.matches && evt.target.matches( GAL_MASONRY_GRID_SELECTOR + ' img' ) ) {
				galLayoutAllMasonry();
			}
		},
		true
	);

	// Late-appearing galleries (Elementor's own AJAX re-render in the
	// editor, or content injected by another plugin after this script
	// already ran) - same MutationObserver pattern used elsewhere in
	// this file.
	if ( 'MutationObserver' in window ) {
		new MutationObserver( function ( mutations ) {
			var found = false;
			mutations.forEach( function ( mutation ) {
				mutation.addedNodes.forEach( function ( node ) {
					if ( node.nodeType !== 1 ) {
						return;
					}
					if ( node.matches && ( node.matches( GAL_MASONRY_GRID_SELECTOR ) || node.querySelector( GAL_MASONRY_GRID_SELECTOR ) ) ) {
						found = true;
					}
				} );
			} );
			if ( found ) {
				galLayoutAllMasonry();
			}
		} ).observe( document.body, { childList: true, subtree: true } );
	}

	/**
	 * Show/hide each item in `root` against the chosen filter value,
	 * with a short fade rather than an abrupt jump-cut.
	 */
	function galApplyFilter( root, value ) {
		root.querySelectorAll( GAL_ITEM_SELECTOR ).forEach( function ( item ) {
			var cats  = ( item.getAttribute( 'data-novixa-category' ) || '' ).split( ',' ).filter( Boolean );
			var match = ( 'all' === value ) || ( -1 !== cats.indexOf( value ) );

			if ( match ) {
				if ( item.classList.contains( GAL_HIDDEN_CLASS ) ) {
					item.classList.remove( GAL_HIDDEN_CLASS );
					item.style.opacity = '0';
					// eslint-disable-next-line no-unused-expressions -- forces a reflow so the opacity:0 above is committed before the fade-in below starts.
					item.offsetWidth;
					window.requestAnimationFrame( function () {
						item.style.opacity = '';
					} );
				}
			} else if ( ! item.classList.contains( GAL_HIDDEN_CLASS ) ) {
				item.style.opacity = '0';
				window.setTimeout( function () {
					item.classList.add( GAL_HIDDEN_CLASS );
					galLayoutAllMasonry();
				}, GAL_FADE_MS );
			}
		} );

		galLayoutAllMasonry();
	}

	document.addEventListener( 'click', function ( evt ) {
		var btn = closest( evt.target, GAL_FILTER_BTN );
		if ( ! btn ) {
			return;
		}

		var root = closest( btn, GAL_ROOT_SELECTOR );
		if ( ! root ) {
			return;
		}

		root.querySelectorAll( GAL_FILTER_BTN ).forEach( function ( sibling ) {
			sibling.classList.toggle( 'novixa-addons-gallery__filter-btn--active', sibling === btn );
		} );

		galApplyFilter( root, btn.getAttribute( 'data-novixa-filter' ) || 'all' );
	} );

	/**
	 * Build (once) the empty lightbox shell for a gallery instance and
	 * cache it on the root element for reuse across opens/closes.
	 */
	function galGetLightbox( root ) {
		if ( root.novixaLightbox ) {
			return root.novixaLightbox;
		}

		var el = document.createElement( 'div' );
		el.className   = GAL_LIGHTBOX_CLASS;
		el.setAttribute( 'role', 'dialog' );
		el.setAttribute( 'aria-modal', 'true' );
		el.innerHTML =
			'<button type="button" class="novixa-addons-gallery-lightbox__close novixa-addons-gallery-lightbox__nav" aria-label="Close">' +
				'<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>' +
			'</button>' +
			'<button type="button" class="novixa-addons-gallery-lightbox__nav novixa-addons-gallery-lightbox__nav--prev" aria-label="Previous image">' +
				'<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"></polyline></svg>' +
			'</button>' +
			'<button type="button" class="novixa-addons-gallery-lightbox__nav novixa-addons-gallery-lightbox__nav--next" aria-label="Next image">' +
				'<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>' +
			'</button>' +
			'<div class="novixa-addons-gallery-lightbox__inner">' +
				'<img class="novixa-addons-gallery-lightbox__image" alt="" />' +
				'<div class="novixa-addons-gallery-lightbox__meta">' +
					'<div class="novixa-addons-gallery-lightbox__caption"></div>' +
					'<div class="novixa-addons-gallery-lightbox__counter"></div>' +
				'</div>' +
			'</div>';

		root.insertAdjacentElement( 'afterend', el );
		root.novixaLightbox = el;

		return el;
	}

	/**
	 * Populate the lightbox with the item at `index` of its current
	 * `_items` array and (re)start the image's fade-in.
	 */
	function galRenderLightbox( el, index ) {
		var items = el._items || [];
		if ( ! items.length ) {
			return;
		}

		el._index = ( index + items.length ) % items.length;
		var item  = items[ el._index ];

		var img = el.querySelector( '.novixa-addons-gallery-lightbox__image' );
		img.classList.remove( 'novixa-addons-gallery-lightbox__image--visible' );

		var onLoad = function () {
			img.classList.add( 'novixa-addons-gallery-lightbox__image--visible' );
			img.removeEventListener( 'load', onLoad );
		};
		img.addEventListener( 'load', onLoad );
		img.src = item.full;
		img.alt = item.title || item.caption || '';

		var captionEl = el.querySelector( '.novixa-addons-gallery-lightbox__caption' );
		var textParts = [ item.title, item.caption ].filter( Boolean );
		if ( el._showCaption && textParts.length ) {
			captionEl.textContent   = textParts.join( ' — ' );
			captionEl.style.display = '';
		} else {
			captionEl.style.display = 'none';
		}

		var counterEl = el.querySelector( '.novixa-addons-gallery-lightbox__counter' );
		if ( el._showCounter && items.length > 1 ) {
			counterEl.textContent   = ( el._index + 1 ) + ' / ' + items.length;
			counterEl.style.display = '';
		} else {
			counterEl.style.display = 'none';
		}

		var showNav = el._showArrows && items.length > 1;
		el.querySelectorAll( '.novixa-addons-gallery-lightbox__nav--prev, .novixa-addons-gallery-lightbox__nav--next' ).forEach( function ( navBtn ) {
			navBtn.style.display = showNav ? '' : 'none';
		} );
	}

	function galOpenLightbox( root, trigger ) {
		var scope = root.querySelectorAll( GAL_ITEM_SELECTOR + ':not(.' + GAL_HIDDEN_CLASS + ') ' + GAL_TRIGGER_SELECTOR );
		var items = Array.prototype.map.call( scope, function ( node ) {
			return {
				full:    node.getAttribute( 'data-novixa-full' ),
				title:   node.getAttribute( 'data-novixa-title' ) || '',
				caption: node.getAttribute( 'data-novixa-caption' ) || '',
				node:    node,
			};
		} );

		var startIndex = Array.prototype.indexOf.call( scope, trigger );
		var el         = galGetLightbox( root );

		el._items       = items;
		el._trigger     = trigger;
		el._showCaption = '1' === root.getAttribute( 'data-novixa-show-caption' );
		el._showCounter = '1' === root.getAttribute( 'data-novixa-show-counter' );
		el._showArrows  = '1' === root.getAttribute( 'data-novixa-show-arrows' );

		galRenderLightbox( el, -1 === startIndex ? 0 : startIndex );

		el.classList.add( GAL_LIGHTBOX_CLASS + '--open' );
		document.body.classList.add( 'novixa-addons-gallery-lightbox-open' );

		var closeBtn = el.querySelector( '.novixa-addons-gallery-lightbox__close' );
		if ( closeBtn && closeBtn.focus ) {
			closeBtn.focus();
		}
	}

	function galCloseLightbox( el ) {
		el.classList.remove( GAL_LIGHTBOX_CLASS + '--open' );
		document.body.classList.remove( 'novixa-addons-gallery-lightbox-open' );

		if ( el._trigger && el._trigger.focus ) {
			el._trigger.focus();
		}
	}

	document.addEventListener( 'click', function ( evt ) {
		var trigger = closest( evt.target, GAL_TRIGGER_SELECTOR );
		if ( trigger ) {
			var root = closest( trigger, GAL_ROOT_SELECTOR );
			if ( root ) {
				evt.preventDefault();
				galOpenLightbox( root, trigger );
			}
			return;
		}

		var lightbox = closest( evt.target, '.' + GAL_LIGHTBOX_CLASS );
		if ( ! lightbox ) {
			return;
		}

		if ( closest( evt.target, '.novixa-addons-gallery-lightbox__close' ) || evt.target === lightbox ) {
			galCloseLightbox( lightbox );
		} else if ( closest( evt.target, '.novixa-addons-gallery-lightbox__nav--prev' ) ) {
			galRenderLightbox( lightbox, lightbox._index - 1 );
		} else if ( closest( evt.target, '.novixa-addons-gallery-lightbox__nav--next' ) ) {
			galRenderLightbox( lightbox, lightbox._index + 1 );
		}
	} );

	document.addEventListener( 'keydown', function ( evt ) {
		var openLightbox = document.querySelector( '.' + GAL_LIGHTBOX_CLASS + '--open' );
		if ( ! openLightbox ) {
			return;
		}

		if ( 'Escape' === evt.key ) {
			galCloseLightbox( openLightbox );
		} else if ( 'ArrowLeft' === evt.key ) {
			galRenderLightbox( openLightbox, openLightbox._index - 1 );
		} else if ( 'ArrowRight' === evt.key ) {
			galRenderLightbox( openLightbox, openLightbox._index + 1 );
		}
	} );

} )();
