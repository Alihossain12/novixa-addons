/**
 * Registers the "novixa-addons-nested-tabs" widget as a Nested Element
 * type so Elementor's editor knows each tab is a real drop target for
 * containers/widgets — not ordinary widget JS, this only runs inside
 * the Elementor editor iframe.
 *
 * EXPERIMENTAL: based on the closest known-working community pattern
 * for Widget_Nested_Base (see the long comment at the top of
 * modules/nested-tabs/class-widget-nested-tabs.php for the full
 * context and caveats). `getType()` below MUST exactly match the PHP
 * widget's get_name().
 */
( function () {
	'use strict';

	if ( ! window.elementor || ! window.elementorCommon || ! window.$e ) {
		return;
	}

	elementorCommon.elements.$window.on( 'elementor/nested-element-type-loaded', function () {
		if ( ! $e.components.get( 'nested-elements' ) ) {
			return;
		}

		var NestedView = $e.components.get( 'nested-elements' ).exports.NestedView;

		/**
		 * Editor-side view for each tab's nested container.
		 */
		class NovixaNestedTabsView extends NestedView {
			filter( child, index ) {
				child.attributes.dataTabIndex = index;
				return true;
			}

			onAddChild( childView ) {
				childView.$el.attr( 'data-tab-index', childView.model.get( 'dataTabIndex' ) );
				childView.$el.toggle( 0 === childView.model.get( 'dataTabIndex' ) );
			}

			/**
			 * Clicking a nav button inside the editor canvas only ever
			 * changed the button's own active/hover colour, because the
			 * generic document-level click delegation in frontend.js
			 * looks for panels carrying our own
			 * `novixa-addons-nested-tabs__panel` class — but in the
			 * editor, each tab's content is a real Elementor container
			 * rendered directly by THIS Marionette view (no such class
			 * exists on it here, only a `data-tab-index` attribute).
			 * Bind directly to this view's own child collection instead
			 * of guessing at DOM shape, so switching tabs in the canvas
			 * shows/hides the correct container reliably.
			 */
			onRender() {
				if ( NestedView.prototype.onRender ) {
					NestedView.prototype.onRender.apply( this, arguments );
				}

				var self = this;

				this.$el
					.off( 'click.novixaNestedTabs' )
					.on( 'click.novixaNestedTabs', '.novixa-addons-nested-tabs__nav-item', function ( event ) {
						event.preventDefault();

						var $clicked = jQuery( event.currentTarget );
						var index    = parseInt( $clicked.attr( 'data-tab-index' ), 10 );

						self.$el.find( '.novixa-addons-nested-tabs__nav-item' ).each( function () {
							var $navItem  = jQuery( this );
							var isActive  = parseInt( $navItem.attr( 'data-tab-index' ), 10 ) === index;
							$navItem
								.toggleClass( 'novixa-addons-nested-tabs__nav-item--active', isActive )
								.attr( 'aria-selected', isActive ? 'true' : 'false' );
						} );

						if ( self.children && 'function' === typeof self.children.each ) {
							self.children.each( function ( childView ) {
								childView.$el.toggle( childView.model.get( 'dataTabIndex' ) === index );
							} );
						}
					} );
			}
		}

		/**
		 * Element type descriptor Elementor's editor uses to know this
		 * widget supports nesting and how to render its children in
		 * the panel/canvas.
		 */
		class NovixaNestedTabsType extends elementor.modules.elements.types.NestedElementBase {
			getType() {
				return 'novixa-addons-nested-tabs';
			}

			getView() {
				return NovixaNestedTabsView;
			}
		}

		elementor.elementsManager.registerElementType( new NovixaNestedTabsType() );
	} );
} )();
