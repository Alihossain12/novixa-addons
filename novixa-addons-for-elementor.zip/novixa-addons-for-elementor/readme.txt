=== Novixa Addons for Elementor ===
Contributors: alihossainwpbd
Tags: elementor, addons, widgets, page builder, elementor widgets
Requires at least: 6.0
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

An independent, lightweight widget library and control panel for Elementor.

== Description ==

Novixa Addons is an independent collection of creative, lightweight widgets for Elementor, with a clean dashboard for enabling only the elements you need.

**Included in v1.0.0**

* Heading widget (Alignment, Typography, Text Stroke, Text Shadow, Blend Mode, Normal/Hover colors)
* Text Editor widget (Alignment, Typography, Text Shadow, Paragraph Spacing, Drop Cap, Columns, Normal/Hover colors)
* Icon Box widget (icon shape, hover lift, box shadow, Normal/Hover icon colors)
* Image Box widget (hover zoom / grayscale effects, flexible left/right/top layout)
* Button widget with 2 built-in skins — Modern Solid (gradient) and Modern Outline

All settings live under **Novixa Addons** in your wp-admin menu.

== Installation ==

1. Upload the `novixa-addons-for-elementor` folder to `/wp-content/plugins/`.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Make sure Elementor is installed and active.
4. Go to **Novixa Addons > Elements** to enable the widgets you want.

== Frequently Asked Questions ==

= Does this require Elementor? =

Yes, Elementor (free version) must be installed and active.

= Can I disable widgets I don't use? =

Yes, go to **Novixa Addons > Elements** and toggle any widget off. Disabled widgets are not loaded on the front end.

== Changelog ==

= 1.0.0 =
* Initial release: Heading and Text Editor widgets, dashboard, elements manager, settings screen.
